"""Run C++ syntax-only checks for bundled examples using local API stubs.

These stubs catch generated C++ syntax and adapter integration errors. They do
not replace Arduino CLI compilation against actual board cores and libraries.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STUBS = ROOT / "cpp_stubs"
EXAMPLES = ROOT / "examples"
COMPILER = shutil.which("g++") or shutil.which("clang++")

if not COMPILER:
    print("A C++ compiler (g++ or clang++) is required for this optional syntax check.")
    raise SystemExit(2)

sketches = sorted(EXAMPLES.glob("*.ino"))
if not sketches:
    print("No example .ino sketches were found.")
    raise SystemExit(1)

failures: list[str] = []
for sketch in sketches:
    project_file = sketch.with_suffix(".iotproj")
    if not project_file.exists():
        print(f"SKIP {sketch.name}: matching .iotproj file is missing")
        continue
    try:
        project = json.loads(project_file.read_text(encoding="utf-8"))
        board = project.get("board_id", "uno")
    except (OSError, json.JSONDecodeError) as exc:
        print(f"FAIL {sketch.name}: cannot read project model: {exc}")
        failures.append(sketch.name)
        continue

    command = [
        COMPILER,
        "-std=c++17",
        "-fsyntax-only",
        "-x", "c++",
        "-include", str(STUBS / "Arduino.h"),
        "-I", str(STUBS),
    ]
    if board == "esp32":
        command.append("-DARDUINO_ARCH_ESP32")
    elif board == "esp8266":
        command.append("-DARDUINO_ARCH_ESP8266")
    command.append(str(sketch))

    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"PASS {sketch.name} [{board}]")
    else:
        print(f"FAIL {sketch.name} [{board}]")
        print(result.stdout)
        print(result.stderr)
        failures.append(sketch.name)

print(f"\nChecked: {len(sketches)} | Failed: {len(failures)}")
raise SystemExit(1 if failures else 0)
