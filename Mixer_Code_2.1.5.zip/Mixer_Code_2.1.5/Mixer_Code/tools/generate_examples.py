"""Regenerate bundled Mixer Code Arduino examples from their project files."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from iot_studio.model import Project, Rule
from iot_studio.parser import parse_instruction
from iot_studio.codegen import generate_cpp

EXAMPLES = ROOT / "examples"

# Refresh all existing example sketches against the current code generator.
for project_path in sorted(EXAMPLES.glob("*.iotproj")):
    try:
        project = Project.load(str(project_path))
        # Persist migrations (schema v6) so each bundled example is a complete,
        # current-format project rather than merely generating from a migrated
        # in-memory copy.
        project.save(str(project_path))
        sketch_path = project_path.with_suffix(".ino")
        sketch_path.write_text(generate_cpp(project), encoding="utf-8")
    except Exception as exc:
        print(f"SKIP {project_path.name}: {exc}")

# ESP32 multi-service IoT gateway with automatic OLED sensor dashboard.
p = Project(name="ESP32 IoT Gateway", board_id="esp32")
p.add_component("ssd1306_oled", "Gateway OLED", {})
p.add_component("ldr", "Room Light", {"signal": "34"})
p.add_component("mq_gas", "MQ Gas Sensor", {"signal": "35"})
p.add_communication("wifi_sta", {"ssid": "LabNetwork", "password": "demo-wifi-password"})
p.add_communication("mqtt_client", {
    "host": "broker.hivemq.com", "port": "1883", "client_id": "MixerCodeGatewayDemo",
    "subscribe_topic": "mixercode/demo/in", "publish_topic": "mixercode/demo/out",
})
p.add_communication("web_server", {"port": "80"})
p.add_communication("udp_listener", {"listen_port": "4210"})
p.add_communication("ntp_sync", {"utc_offset_seconds": "19800", "daylight_offset_seconds": "0"})
p.add_communication("ota_update", {"hostname": "mixer-coder-gateway", "password": "demo-ota-password-change"})
p.save(str(EXAMPLES / "esp32_iot_gateway.iotproj"))
(EXAMPLES / "esp32_iot_gateway.ino").write_text(generate_cpp(p), encoding="utf-8")

# Plain HTTP REST demo showing POST payload generation. Replace the endpoint.
p = Project(name="ESP32 HTTP REST POST Demo", board_id="esp32")
p.add_communication("wifi_sta", {"ssid": "LabNetwork", "password": "demo-wifi-password"})
p.add_communication("http_get", {
    "method": "POST", "url": "http://192.168.1.100/api/telemetry",
    "payload": '{"device":"mixer-coder","value":42}', "interval_ms": "30000",
})
p.save(str(EXAMPLES / "esp32_http_rest_post.iotproj"))
(EXAMPLES / "esp32_http_rest_post.ino").write_text(generate_cpp(p), encoding="utf-8")

# RS-485 half-duplex MAX485 bridge for Uno. Tie DE and /RE together.
p = Project(name="Arduino Uno MAX485 RS-485 Bridge", board_id="uno")
p.add_communication("rs485_half_duplex", {
    "rx_pin": "8", "tx_pin": "9", "de_pin": "4", "baud": "9600",
})
p.save(str(EXAMPLES / "uno_max485_rs485_bridge.iotproj"))
(EXAMPLES / "uno_max485_rs485_bridge.ino").write_text(generate_cpp(p), encoding="utf-8")

# LoRa peer node. Use two matching nodes and replace the sample message as needed.
p = Project(name="Arduino Uno LoRa Peer Node", board_id="uno")
p.add_communication("lora_radio", {
    "cs_pin": "10", "reset_pin": "9", "dio0_pin": "2",
    "frequency_mhz": "866.0", "node_message": "MIXER_CODE_NODE_A", "interval_ms": "10000",
})
p.save(str(EXAMPLES / "uno_lora_peer_node.iotproj"))
(EXAMPLES / "uno_lora_peer_node.ino").write_text(generate_cpp(p), encoding="utf-8")

# ESP32 network scan is an isolated one-shot task, not mixed with station mode.
p = Project(name="ESP32 Wi-Fi Scanner", board_id="esp32")
p.add_communication("wifi_scan")
p.save(str(EXAMPLES / "esp32_wifi_scanner.iotproj"))
(EXAMPLES / "esp32_wifi_scanner.ino").write_text(generate_cpp(p), encoding="utf-8")

print("Examples regenerated.")

# Continuous monitoring: ultrasonic distance without any threshold rule.
p = Project(name="HC-SR04 Continuous Monitor", board_id="uno")
p.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
p.add_component("ssd1306_oled", "OLED", {})
p.set_sensor_monitor("ultrasonic", "continuous", 100)
p.save(str(EXAMPLES / "uno_ultrasonic_continuous_monitor.iotproj"))
(EXAMPLES / "uno_ultrasonic_continuous_monitor.ino").write_text(generate_cpp(p), encoding="utf-8")

# Continuous MQ analog telemetry to Serial and the automatic OLED dashboard.
p = Project(name="MQ Analog Continuous Monitor", board_id="uno")
p.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
p.add_component("ssd1306_oled", "OLED", {})
p.set_sensor_monitor("mq_gas", "continuous", 500)
p.save(str(EXAMPLES / "uno_mq_continuous_monitor.iotproj"))
(EXAMPLES / "uno_mq_continuous_monitor.ino").write_text(generate_cpp(p), encoding="utf-8")

# Both mode: live MQ values and a threshold-triggered LED.
p = Project(name="MQ Monitor Plus Threshold Alarm", board_id="uno")
sensor = p.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
led = p.add_component("led", "Warning LED", {"signal": "3"})
p.set_sensor_monitor(sensor.id, "both", 250)
p.add_rule(Rule(sensor.id, "ABOVE", 700, led.id, "GLOW"))
p.save(str(EXAMPLES / "uno_mq_monitor_and_threshold.iotproj"))
(EXAMPLES / "uno_mq_monitor_and_threshold.ino").write_text(generate_cpp(p), encoding="utf-8")

# Threshold-only mode remains the default and does not stream continuous values.
p = Project(name="Touch Sensor Threshold Only", board_id="uno")
sensor = p.add_component("touch_sensor", "Touch Sensor", {"signal": "2"})
led = p.add_component("led", "LED", {"signal": "3"})
p.set_sensor_monitor(sensor.id, "threshold", 250)
p.add_rule(Rule(sensor.id, "TRUE", None, led.id, "GLOW"))
p.save(str(EXAMPLES / "uno_touch_threshold_only.iotproj"))
(EXAMPLES / "uno_touch_threshold_only.ino").write_text(generate_cpp(p), encoding="utf-8")


# Digital input continuous telemetry with polarity-aware ACTIVE/INACTIVE states.
p = Project(name="Push Button Continuous Monitor", board_id="uno")
p.add_component("push_button", "Push Button", {"signal": "2"})
p.set_sensor_monitor("push_button", "continuous", 100)
p.save(str(EXAMPLES / "uno_pushbutton_continuous_monitor.iotproj"))
(EXAMPLES / "uno_pushbutton_continuous_monitor.ino").write_text(generate_cpp(p), encoding="utf-8")

print("Sensor monitoring examples generated.")


# Categorical ultrasonic presence rule: no ABOVE/BELOW numeric threshold is used.
p = Project(name="Ultrasonic Presence Detection", board_id="uno")
sonar = p.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
led = p.add_component("led", "Detected LED", {"signal": "4"})
buzzer = p.add_component("buzzer", "No Echo Buzzer", {"signal": "5"})
p.add_rule(Rule(sonar.id, "DETECTED", None, led.id, "GLOW"))
p.add_rule(Rule(sonar.id, "NOT_DETECTED", None, buzzer.id, "BEEP"))
p.save(str(EXAMPLES / "uno_ultrasonic_presence_detection.iotproj"))
(EXAMPLES / "uno_ultrasonic_presence_detection.ino").write_text(generate_cpp(p), encoding="utf-8")

# Additional analog and digital sensor modules use the generic input adapters.
p = Project(name="Multi Sensor Input Demo", board_id="uno")
p.add_component("rain_sensor_analog", "Rain Level", {"signal": "A0"})
p.add_component("water_level", "Water Level", {"signal": "A1"})
p.add_component("ir_obstacle", "IR Obstacle", {"signal": "2"})
p.add_component("vibration_sensor", "Vibration", {"signal": "3"})
led = p.add_component("led", "Status LED", {"signal": "4"})
p.add_rule(parse_instruction("WHEN IR Obstacle DETECTED THEN Status LED GLOW", p))
p.save(str(EXAMPLES / "uno_multi_sensor_input_demo.iotproj"))
(EXAMPLES / "uno_multi_sensor_input_demo.ino").write_text(generate_cpp(p), encoding="utf-8")

print("Presence-rule and expanded sensor examples generated.")
