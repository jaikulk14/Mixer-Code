import unittest

from iot_studio.catalog import COMPONENTS
from iot_studio.codegen import generate_cpp
from iot_studio.model import Project, Rule
from iot_studio.parser import parse_instruction, InstructionError


class PresenceRuleTests(unittest.TestCase):
    def setUp(self):
        self.project = Project(board_id="uno")
        self.sonar = self.project.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
        self.led = self.project.add_component("led", "Warning LED", {"signal": "4"})

    def test_parse_detected_without_numeric_threshold(self):
        rule = parse_instruction("WHEN Ultrasonic DETECTED THEN Warning LED GLOW", self.project)
        self.assertEqual(rule.condition, "DETECTED")
        self.assertIsNone(rule.threshold)
        self.project.add_rule(rule)
        self.assertEqual(self.project.validate(), [])

    def test_parse_two_word_not_detected_without_numeric_threshold(self):
        rule = parse_instruction("WHEN Ultrasonic NOT DETECTED THEN Warning LED OFF", self.project)
        self.assertEqual(rule.condition, "NOT_DETECTED")
        self.assertIsNone(rule.threshold)
        self.project.add_rule(rule)
        self.assertEqual(self.project.validate(), [])

    def test_parse_underscore_not_detected(self):
        rule = parse_instruction("WHEN Ultrasonic NOT_DETECTED THEN Warning LED OFF", self.project)
        self.assertEqual(rule.condition, "NOT_DETECTED")

    def test_parse_no_echo_alias(self):
        rule = parse_instruction("WHEN Ultrasonic NO_ECHO THEN Warning LED OFF", self.project)
        self.assertEqual(rule.condition, "NOT_DETECTED")

    def test_detected_rule_generates_boolean_state_not_threshold(self):
        self.project.add_rule(Rule(self.sonar.id, "DETECTED", None, self.led.id, "GLOW"))
        cpp = generate_cpp(self.project)
        self.assertIn("bool ultrasonic_detected = false;", cpp)
        self.assertIn("ultrasonic_detected = (ultrasonic_distance_cm >= 0.0f);", cpp)
        self.assertIn("if (ultrasonic_detected)", cpp)
        self.assertNotIn("ultrasonic_distance_cm > None", cpp)
        self.assertIn("digitalWrite(warning_led_pin, HIGH);", cpp)

    def test_not_detected_rule_generates_inverse_boolean_state(self):
        self.project.add_rule(Rule(self.sonar.id, "NOT_DETECTED", None, self.led.id, "GLOW"))
        cpp = generate_cpp(self.project)
        self.assertIn("if (!ultrasonic_detected)", cpp)

    def test_distance_threshold_rules_are_preserved(self):
        self.project.add_rule(Rule(self.sonar.id, "BELOW", 30, self.led.id, "GLOW"))
        cpp = generate_cpp(self.project)
        self.assertIn("ultrasonic_distance_cm >= 0 && ultrasonic_distance_cm < 30", cpp)

    def test_detected_state_updates_in_nonblocking_monitor_mode(self):
        self.project.set_sensor_monitor(self.sonar.id, "both", 100)
        self.project.add_rule(Rule(self.sonar.id, "DETECTED", None, self.led.id, "GLOW"))
        cpp = generate_cpp(self.project)
        self.assertIn("tick_sensor_monitor_ultrasonic()", cpp)
        self.assertIn("ultrasonic_detected = true;", cpp)
        self.assertIn("ultrasonic_detected = false;", cpp)
        self.assertIn("if (ultrasonic_detected)", cpp)
        self.assertNotIn("pulseIn(", cpp)

    def test_detected_state_updates_in_legacy_ultrasonic_task_mode(self):
        self.project.add_task("ultrasonic_monitor", self.sonar.id, interval_ms=100)
        self.project.add_rule(Rule(self.sonar.id, "NOT_DETECTED", None, self.led.id, "GLOW"))
        cpp = generate_cpp(self.project)
        self.assertIn("ultrasonic_detected = true;", cpp)
        self.assertIn("ultrasonic_detected = false;", cpp)
        self.assertIn("if (!ultrasonic_detected)", cpp)

    def test_state_event_cannot_carry_numeric_threshold(self):
        self.project.add_rule(Rule(self.sonar.id, "DETECTED", 25, self.led.id, "GLOW"))
        self.assertTrue(any("state/event condition" in error for error in self.project.validate()))

    def test_analog_sensors_still_require_thresholds(self):
        analog = self.project.add_component("lm35", "LM35", {"signal": "A0"})
        self.project.add_rule(Rule(analog.id, "ABOVE", None, self.led.id, "GLOW"))
        self.assertTrue(any("require a numeric threshold" in error for error in self.project.validate()))

    def test_digital_detection_aliases_map_to_existing_true_false_logic(self):
        digital = self.project.add_component("ir_obstacle", "IR Obstacle", {"signal": "5"})
        detected = parse_instruction("WHEN IR Obstacle DETECTED THEN Warning LED GLOW", self.project)
        not_detected = parse_instruction("WHEN IR Obstacle NOT DETECTED THEN Warning LED OFF", self.project)
        self.assertEqual(detected.condition, "DETECTED")
        self.assertEqual(not_detected.condition, "NOT_DETECTED")
        self.project.add_rule(detected)
        self.project.add_rule(not_detected)
        cpp = generate_cpp(self.project)
        self.assertIn("if (ir_obstacle_state)", cpp)
        self.assertIn("if (!ir_obstacle_state)", cpp)

    def test_new_sensor_profiles_use_existing_core_adapters(self):
        expected = {
            "rain_sensor_analog": "analog_input",
            "water_level": "analog_input",
            "lm35": "analog_input",
            "ntc_thermistor": "analog_input",
            "fsr": "analog_input",
            "flex_sensor": "analog_input",
            "voltage_sensor": "analog_input",
            "joystick_axis": "analog_input",
            "ir_obstacle": "digital_input",
            "line_tracking": "digital_input",
            "vibration_sensor": "digital_input",
            "tilt_switch": "digital_input",
            "reed_switch": "digital_input",
            "limit_switch": "digital_input",
            "rain_sensor_digital": "digital_input",
            "water_leak_sensor": "digital_input",
            "sound_sensor_digital": "digital_input",
        }
        for type_id, kind in expected.items():
            with self.subTest(type_id=type_id):
                self.assertIn(type_id, COMPONENTS)
                self.assertEqual(COMPONENTS[type_id].kind, kind)

    def test_existing_true_false_and_analog_rules_remain_supported(self):
        button = self.project.add_component("push_button", "Button", {"signal": "5"})
        analog = self.project.add_component("lm35", "Temperature", {"signal": "A0"})
        self.project.add_rule(Rule(button.id, "TRUE", None, self.led.id, "GLOW"))
        self.project.add_rule(Rule(analog.id, "ABOVE", 500, self.led.id, "GLOW"))
        self.assertEqual(self.project.validate(), [])
        cpp = generate_cpp(self.project)
        self.assertIn("if (button_state)", cpp)
        self.assertIn("temperature_value > 500", cpp)


if __name__ == "__main__":
    unittest.main()
