import unittest

from iot_studio.integration_import import extract_integration_document, normalize_pasted_text
from iot_studio.model import Project
from iot_studio.codegen import generate_cpp
from iot_studio.library_manager import classify_cpp_snippets


MPU6050_README = r"""\#include \<Wire.h>\
\#include \<MPU6050.h>\
\
MPU6050 mpu;\
\
void setup() {\
&#x20; Serial.begin(9600);\
&#x20; Wire.begin();\
&#x20; mpu.initialize();\
\
&#x20; if (mpu.testConnection()) {\
&#x20;   Serial.println("MPU6050 connection successful");\
&#x20; } else {\
&#x20;   Serial.println("MPU6050 connection failed");\
&#x20; }\
}\
\
void loop() {\
&#x20; int16_t ax, ay, az;\
&#x20; int16_t gx, gy, gz;\
\
&#x20; mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);\
\
&#x20; Serial.print("Accel: ");\
&#x20; Serial.print("X = "); Serial.print(ax);\
&#x20; Serial.print(" | Y = "); Serial.print(ay);\
&#x20; Serial.print(" | Z = "); Serial.println(az);\
\
&#x20; Serial.print("Gyro: ");\
&#x20; Serial.print("X = "); Serial.print(gx);\
&#x20; Serial.print(" | Y = "); Serial.print(gy);\
&#x20; Serial.print(" | Z = "); Serial.println(gz);\
\
&#x20; delay(500);\
}\
\
\
\# MPU6050 Module Integration with Arduino\
\
This repository provides a guide for connecting and coding the MPU6050 gyroscope and accelerometer module with an Arduino.\
\
\## Code\
\
\`\`\`cpp\
#include <Wire.h>\
#include <MPU6050.h>\
\
MPU6050 mpu;\
\
void setup() {\
  Serial.begin(9600);\
  Wire.begin();\
  mpu.initialize();\
  if (mpu.testConnection()) {\
    Serial.println("MPU6050 connection successful");\
  } else {\
    Serial.println("MPU6050 connection failed");\
  }\
}\
\
void loop() {\
  int16_t ax, ay, az;\
  int16_t gx, gy, gz;\
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);\
  Serial.print("Accel: ");\
  Serial.print("X = "); Serial.print(ax);\
  Serial.print(" | Y = "); Serial.print(ay);\
  Serial.print(" | Z = "); Serial.println(az);\
  Serial.print("Gyro: ");\
  Serial.print("X = "); Serial.print(gx);\
  Serial.print(" | Y = "); Serial.print(gy);\
  Serial.print(" | Z = "); Serial.println(gz);\
  delay(500);\
}\
\`\`\`\
"""


class IntegrationImportTests(unittest.TestCase):
    def test_full_readme_extracts_only_four_code_sections(self):
        result = extract_integration_document(MPU6050_README)
        self.assertEqual(result.title, "MPU6050")
        self.assertEqual(result.includes.splitlines(), ["#include <Wire.h>", "#include <MPU6050.h>"])
        self.assertEqual(result.declarations.strip(), "MPU6050 mpu;")
        self.assertIn("mpu.initialize();", result.setup_code)
        self.assertIn("mpu.testConnection()", result.setup_code)
        self.assertIn("mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);", result.loop_code)
        self.assertIn("delay(500);", result.loop_code)
        self.assertNotIn("repository provides", result.declarations)
        self.assertNotIn("Connections", result.declarations)
        self.assertNotIn("Table of Contents", result.declarations)
        self.assertEqual(result.candidate_count, 1)

    def test_single_sketch_is_split_and_codegen_does_not_overwrite_custom_baud(self):
        raw = """#include <Wire.h>
#include <MPU6050.h>
MPU6050 mpu;
void setup() { Serial.begin(9600); Wire.begin(); mpu.initialize(); }
void loop() { int16_t ax, ay, az, gx, gy, gz; mpu.getMotion6(&ax,&ay,&az,&gx,&gy,&gz); }
"""
        result = extract_integration_document(raw)
        project = Project(board_id="uno")
        project.add_custom_component(
            name=result.title,
            includes=result.includes,
            declarations=result.declarations,
            setup_code=result.setup_code,
            loop_code=result.loop_code,
        )
        cpp = generate_cpp(project)
        self.assertIn("#include <MPU6050.h>", cpp)
        self.assertIn("MPU6050 mpu;", cpp)
        self.assertIn("mpu.initialize();", cpp)
        self.assertIn("mpu.getMotion6", cpp)
        self.assertNotIn("Serial.begin(115200);", cpp)
        self.assertIn("Serial.begin(9600);", cpp)
        self.assertLess(cpp.index("#include <Wire.h>"), cpp.index("#include <MPU6050.h>"))
        self.assertNotIn("delay(20); // Small loop pause", cpp)
        self.assertEqual(project.validate(), [])

    def test_duplicate_setup_and_loop_wrappers_are_removed_from_globals(self):
        raw = """#include <Sensor.h>
Sensor sensor;
void setup() { sensor.begin(); }
void loop() { sensor.read(); }
void setup() { sensor.begin(); }
void loop() { sensor.read(); }
"""
        result = extract_integration_document(raw)
        self.assertEqual(result.declarations.strip(), "Sensor sensor;")
        self.assertEqual(result.setup_code, "sensor.begin();")
        self.assertEqual(result.loop_code, "sensor.read();")
        self.assertTrue(any("Repeated setup()/loop()" in warning for warning in result.warnings))

    def test_comments_and_string_literals_do_not_fake_function_wrappers(self):
        raw = '''#include <Sensor.h>
Sensor sensor; // void setup() { fake(); }
void setup() {
  Serial.println("text says void loop() { but it is not a function");
  sensor.begin();
}
void loop() { sensor.read(); }
'''
        result = extract_integration_document(raw)
        self.assertEqual(result.declarations.strip(), "Sensor sensor; // void setup() { fake(); }")
        self.assertIn("sensor.begin();", result.setup_code)
        self.assertEqual(result.loop_code, "sensor.read();")

    def test_delay_and_serial_baud_are_reported(self):
        raw = """#include <Thing.h>
Thing thing;
void setup(){ Serial.begin(9600); thing.begin(); }
void loop(){ thing.read(); delay(500); }
"""
        result = extract_integration_document(raw)
        joined = " ".join(result.warnings)
        self.assertIn("delay()", joined)
        self.assertIn("baud rate", joined)

    def test_filters_plain_readme_prose_after_raw_sketch(self):
        raw = """#include <Sensor.h>
Sensor sensor;
void setup() { sensor.begin(); }
void loop() { sensor.read(); }
This repository provides a guide for connecting the sensor to an Arduino board.
The module allows measurement of motion and temperature.
"""
        result = extract_integration_document(raw)
        self.assertEqual(result.declarations.strip(), "Sensor sensor;")
        self.assertNotIn("repository", result.declarations)
        self.assertNotIn("module allows", result.declarations)

    def test_combines_separate_setup_and_loop_fenced_blocks(self):
        raw = """# MPU Integration
```cpp
#include <Sensor.h>
Sensor sensor;
void setup() { sensor.begin(); }
```
Some README text between code blocks.
```cpp
void loop() { sensor.read(); }
```
"""
        result = extract_integration_document(raw)
        self.assertEqual(result.includes.strip(), "#include <Sensor.h>")
        self.assertEqual(result.declarations.strip(), "Sensor sensor;")
        self.assertEqual(result.setup_code, "sensor.begin();")
        self.assertEqual(result.loop_code, "sensor.read();")
        self.assertTrue(any("combined from separate code blocks" in warning for warning in result.warnings))

    def test_rejects_readme_without_arduino_code(self):
        with self.assertRaises(ValueError):
            extract_integration_document("# Sensor guide\nThis page explains wiring only.")

    def test_classifier_uses_shared_parser(self):
        snippet = "#include <DHT.h>\nDHT dht(2, DHT22);\nvoid setup(){ dht.begin(); }\nvoid loop(){ dht.readTemperature(); }"
        result = classify_cpp_snippets([snippet], "https://example.com/dht", "DHT guide")
        self.assertEqual(result["title"], "DHT guide")
        self.assertIn("#include <DHT.h>", result["includes"])
        self.assertIn("dht.begin();", result["setup_code"])
        self.assertIn("dht.readTemperature();", result["loop_code"])

    def test_normalizes_html_and_escaped_markdown(self):
        cleaned = normalize_pasted_text(r"\#include \<Wire.h>\
&#x20;Wire.begin();\
\`\`\`cpp")
        self.assertIn("#include <Wire.h>", cleaned)
        self.assertIn("Wire.begin();", cleaned)
        self.assertIn("```cpp", cleaned)


if __name__ == "__main__":
    unittest.main()
