import unittest

from iot_studio.model import Project, Rule
from iot_studio.codegen import generate_cpp


class SensorMonitorTests(unittest.TestCase):
    def test_default_sensor_behavior_remains_threshold_only(self):
        project = Project(board_id="uno")
        project.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
        sketch = generate_cpp(project)
        self.assertNotIn("MONITOR,mq_gas", sketch)
        self.assertIn("delay(20);", sketch)

    def test_explicit_threshold_mode_does_not_create_continuous_telemetry(self):
        project = Project(board_id="uno")
        sensor = project.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
        project.set_sensor_monitor(sensor.id, "threshold", 250)
        sketch = generate_cpp(project)
        self.assertNotIn("MONITOR,mq_gas", sketch)
        self.assertEqual(project.validate(), [])

    def test_analog_continuous_monitor_emits_sampled_adc_values(self):
        project = Project(board_id="uno")
        sensor = project.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
        project.set_sensor_monitor(sensor.id, "continuous", 250)
        self.assertEqual(project.validate(), [])
        sketch = generate_cpp(project)
        self.assertIn("analogRead(mq_gas_pin)", sketch)
        self.assertIn('Serial.print(F("MONITOR,mq_gas,ANALOG,"))', sketch)
        self.assertIn(">= 250UL", sketch)
        self.assertNotIn("delay(20);", sketch)

    def test_digital_continuous_monitor_reports_active_state(self):
        project = Project(board_id="uno")
        sensor = project.add_component("touch_sensor", "Touch Sensor", {"signal": "2"})
        project.set_sensor_monitor(sensor.id, "continuous", 100)
        sketch = generate_cpp(project)
        self.assertIn('Serial.print(F("MONITOR,touch_sensor,DIGITAL,"))', sketch)
        self.assertIn('F("ACTIVE") : F("INACTIVE")', sketch)
        self.assertNotIn("delay(20);", sketch)

    def test_ultrasonic_continuous_monitor_is_nonblocking_and_needs_no_threshold(self):
        project = Project(board_id="uno")
        sensor = project.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
        project.set_sensor_monitor(sensor.id, "continuous", 100)
        self.assertEqual(project.validate(), [])
        sketch = generate_cpp(project)
        self.assertIn("tick_sensor_monitor_ultrasonic()", sketch)
        self.assertIn('Serial.print(F("MONITOR,ultrasonic,DISTANCE_CM,"))', sketch)
        self.assertIn("micros()", sketch)
        self.assertNotIn("pulseIn(", sketch)
        self.assertNotIn("delay(20);", sketch)

    def test_ultrasonic_monitor_shows_live_distance_on_oled(self):
        project = Project(board_id="uno")
        sensor = project.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
        project.set_sensor_monitor(sensor.id, "continuous", 100)
        project.add_component("ssd1306_oled", "OLED", {})
        sketch = generate_cpp(project)
        self.assertIn('println(F("LIVE SENSOR MONITOR"))', sketch)
        self.assertIn('print(F("Ultrasonic: "))', sketch)
        self.assertIn("ultrasonic_distance_cm", sketch)

    def test_both_mode_streams_and_keeps_threshold_rules(self):
        project = Project(board_id="uno")
        sensor = project.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
        led = project.add_component("led", "LED", {"signal": "3"})
        project.set_sensor_monitor(sensor.id, "both", 200)
        project.add_rule(Rule(sensor.id, "ABOVE", 700, led.id, "GLOW"))
        self.assertEqual(project.validate(), [])
        sketch = generate_cpp(project)
        self.assertIn('Serial.print(F("MONITOR,mq_gas,ANALOG,"))', sketch)
        self.assertIn("mq_gas_value > 700", sketch)
        self.assertIn("digitalWrite(led_pin, HIGH)", sketch)

    def test_continuous_only_cannot_keep_threshold_rule(self):
        project = Project(board_id="uno")
        sensor = project.add_component("mq_gas", "MQ Gas", {"signal": "A0"})
        led = project.add_component("led", "LED", {"signal": "3"})
        project.add_rule(Rule(sensor.id, "ABOVE", 700, led.id, "GLOW"))
        project.set_sensor_monitor(sensor.id, "continuous", 250)
        self.assertTrue(any("Choose Both" in error for error in project.validate()))
        with self.assertRaises(ValueError):
            generate_cpp(project)

    def test_continuous_monitor_interval_validation(self):
        project = Project(board_id="uno")
        sonar = project.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
        project.set_sensor_monitor(sonar.id, "continuous", 50)
        self.assertTrue(any("at least 60 ms" in error for error in project.validate()))

    def test_sensor_monitor_project_round_trip_and_legacy_migration(self):
        project = Project(board_id="uno")
        sensor = project.add_component("ldr", "LDR", {"signal": "A0"})
        project.set_sensor_monitor(sensor.id, "both", 400)
        restored = Project.from_dict(project.to_dict())
        self.assertEqual(restored.version, 6)
        self.assertEqual(restored.sensor_monitor(sensor.id).mode, "both")
        self.assertEqual(restored.sensor_monitor(sensor.id).interval_ms, 400)
        legacy = project.to_dict()
        legacy["version"] = 5
        legacy.pop("sensor_monitors")
        migrated = Project.from_dict(legacy)
        self.assertEqual(migrated.version, 6)
        self.assertEqual(migrated.sensor_monitors, [])

    def test_removing_sensor_cleans_monitor_configuration(self):
        project = Project(board_id="uno")
        sensor = project.add_component("push_button", "Button", {"signal": "2"})
        project.set_sensor_monitor(sensor.id, "continuous", 100)
        project.remove_component(sensor.id)
        self.assertEqual(project.sensor_monitors, [])

    def test_only_sensor_inputs_can_be_monitored(self):
        project = Project(board_id="uno")
        led = project.add_component("led", "LED", {"signal": "3"})
        with self.assertRaises(ValueError):
            project.set_sensor_monitor(led.id, "continuous", 100)

    def test_generic_monitor_and_legacy_ultrasonic_task_cannot_duplicate(self):
        project = Project(board_id="uno")
        sonar = project.add_component("hc_sr04", "Ultrasonic", {"trig": "2", "echo": "3"})
        project.add_task("ultrasonic_monitor", sonar.id, interval_ms=100)
        project.set_sensor_monitor(sonar.id, "continuous", 100)
        self.assertTrue(any("remove the older Continuous ultrasonic monitor task" in error for error in project.validate()))


if __name__ == "__main__":
    unittest.main()
