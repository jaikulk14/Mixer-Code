import unittest

from iot_studio.model import Project
from iot_studio.codegen import generate_cpp
from iot_studio.connectivity import profile_defaults, profile_options


class Connectivity212Tests(unittest.TestCase):
    def test_profile_catalog_spans_iot_protocol_categories(self):
        categories = {spec["category"] for spec in __import__("iot_studio.connectivity", fromlist=["PROFILES"]).PROFILES.values()}
        for expected in ("Serial", "Serial & Industrial", "Bluetooth", "Wi-Fi & Network", "IoT Cloud & Messaging", "Hardware Buses", "Time & Storage", "Long-range Radio", "Device Management"):
            self.assertIn(expected, categories)
        self.assertGreaterEqual(len(profile_options("esp32")), 12)
        self.assertGreaterEqual(len(profile_options("uno")), 8)

    def test_max485_rs485_bridge_generation(self):
        project = Project(board_id="uno")
        project.add_communication("rs485_half_duplex", {"rx_pin": "8", "tx_pin": "9", "de_pin": "4", "baud": "19200"})
        self.assertEqual(project.validate(), [])
        cpp = generate_cpp(project)
        self.assertIn("SoftwareSerial mc_rs485_half_duplex_serial(8, 9);", cpp)
        self.assertIn("pinMode(4, OUTPUT);", cpp)
        self.assertIn("digitalWrite(4, LOW); // Receive mode", cpp)
        self.assertIn("digitalWrite(4, HIGH);", cpp)
        self.assertIn("mc_rs485_half_duplex_serial.flush()", cpp)

    def test_software_uart_rejects_excessive_baud_on_avr_boards(self):
        project = Project(board_id="uno")
        project.add_communication("hc05_bluetooth", {"baud": "230400"})
        self.assertTrue(any("115200" in e for e in project.validate()))
        esp = Project(board_id="esp32")
        esp.add_communication("hc05_bluetooth", {"baud": "230400"})
        self.assertEqual(esp.validate(), [])

    def test_max485_direction_pin_must_be_distinct_and_valid(self):
        project = Project(board_id="uno")
        project.add_communication("rs485_half_duplex", {"rx_pin": "8", "tx_pin": "9", "de_pin": "8"})
        self.assertTrue(any("three different pins" in e for e in project.validate()))
        invalid = Project(board_id="esp32")
        invalid.add_communication("rs485_half_duplex", {"rx_pin": "16", "tx_pin": "17", "de_pin": "34"})
        self.assertTrue(any("DE/RE direction pin" in e for e in invalid.validate()))

    def test_wifi_scan_codegen_for_esp32_and_esp8266(self):
        for board, header in (("esp32", "WiFi.h"), ("esp8266", "ESP8266WiFi.h")):
            with self.subTest(board=board):
                project = Project(board_id=board)
                project.add_communication("wifi_scan")
                self.assertEqual(project.validate(), [])
                cpp = generate_cpp(project)
                self.assertIn(f"#include <{header}>", cpp)
                self.assertIn("WiFi.scanNetworks()", cpp)
                self.assertIn("WiFi.RSSI(i)", cpp)
                self.assertIn("WiFi.scanDelete()", cpp)

    def test_wifi_scan_cannot_be_combined_with_station_service(self):
        project = Project(board_id="esp32")
        project.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
        project.add_communication("wifi_scan")
        self.assertTrue(any("cannot be combined" in e for e in project.validate()))

    def test_mqtt_username_password_overload_is_generated(self):
        project = Project(board_id="esp32")
        project.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
        project.add_communication("mqtt_client", {"username": "device-user", "password": "broker-pass"})
        cpp = generate_cpp(project)
        self.assertIn('mc_mqtt_client_mqtt.connect("MixerCodeDevice", "device-user", "broker-pass")', cpp)
        self.assertNotIn('connect("MixerCodeDevice", "", "")', cpp)

    def test_mqtt_anonymous_connection_uses_two_argument_overload(self):
        project = Project(board_id="esp32")
        project.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
        project.add_communication("mqtt_client", {})
        cpp = generate_cpp(project)
        self.assertIn('mc_mqtt_client_mqtt.connect("MixerCodeDevice")', cpp)

    def test_mqtt_password_without_username_is_rejected(self):
        project = Project(board_id="esp32")
        project.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
        project.add_communication("mqtt_client", {"password": "only-password"})
        self.assertTrue(any("password requires a username" in e for e in project.validate()))

    def test_http_rest_methods_generate_real_cpp_calls(self):
        for method, expected in (
            ("GET", "http.GET()"),
            ("POST", 'http.POST(String("{\\"value\\":42}"))'),
            ("PUT", 'http.sendRequest("PUT", (uint8_t*)body.c_str(), body.length())'),
            ("DELETE", 'http.sendRequest("DELETE", (uint8_t*)body.c_str(), body.length())'),
        ):
            with self.subTest(method=method):
                project = Project(board_id="esp32")
                project.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
                project.add_communication("http_get", {"method": method, "url": "http://example.com/api", "payload": '{"value":42}'})
                cpp = generate_cpp(project)
                self.assertIn(expected, cpp)
                self.assertNotIn(" if \\\"GET\\\" else ", cpp)

    def test_http_uses_explicit_wifi_client_on_both_supported_cores(self):
        for board in ("esp32", "esp8266"):
            with self.subTest(board=board):
                project = Project(board_id=board)
                project.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
                project.add_communication("http_get", {"url": "http://example.com/status"})
                cpp = generate_cpp(project)
                self.assertIn("#include <WiFiClient.h>", cpp)
                self.assertIn("WiFiClient mc_http_get_http_client;", cpp)
                self.assertIn('http.begin(mc_http_get_http_client, "http://example.com/status")', cpp)
                self.assertNotIn('http.begin("http://example.com/status")', cpp)

    def test_lora_uno_codegen_and_dependency(self):
        project = Project(board_id="uno")
        profile = project.add_communication("lora_radio")
        self.assertEqual(profile.settings["dio0_pin"], "2")
        self.assertEqual(project.validate(), [])
        self.assertIn("LoRa", [lib.name for lib in project.libraries])
        cpp = generate_cpp(project)
        self.assertIn("#include <LoRa.h>", cpp)
        self.assertIn("LoRa.setPins(10, 9, 2);", cpp)
        self.assertIn("LoRa.begin(866.000E6)", cpp)
        self.assertIn("LoRa.parsePacket()", cpp)
        self.assertIn("LoRa.onTxDone(mc_lora_radio_tx_done_callback)", cpp)
        self.assertIn("LoRa.endPacket(true)", cpp)
        self.assertIn("volatile bool mc_lora_radio_tx_ready = true;", cpp)

    def test_lora_esp32_uses_valid_safe_default_pins(self):
        project = Project(board_id="esp32")
        profile = project.add_communication("lora_radio")
        self.assertEqual(profile.settings["cs_pin"], "25")
        self.assertEqual(project.validate(), [])
        self.assertIn("LoRa.setPins(25, 14, 26);", generate_cpp(project))

    def test_lora_rejects_invalid_dio0_on_uno_and_frequency(self):
        project = Project(board_id="uno")
        project.add_communication("lora_radio", {"dio0_pin": "4", "frequency_mhz": "1200"})
        errors = project.validate()
        self.assertTrue(any("DIO0 must use external-interrupt pin" in e for e in errors))
        self.assertTrue(any("frequency must be between" in e for e in errors))

    def test_lora_dependency_is_removed_when_last_profile_is_removed(self):
        project = Project(board_id="uno")
        item = project.add_communication("lora_radio")
        self.assertIn("lora", project.required_builtin_library_names())
        project.remove_communication(item.id)
        self.assertNotIn("LoRa", [lib.name for lib in project.libraries])

    def test_esp8266_software_uart_cannot_overlap_i2c_bus(self):
        project = Project(board_id="esp8266")
        project.add_communication("i2c_scanner")
        project.add_communication("hc05_bluetooth", {"rx_pin": "4", "tx_pin": "5"})
        self.assertTrue(any("shared I2C SDA bus" in e or "shared I2C SCL bus" in e for e in project.validate()))

    def test_only_one_lora_radio_is_allowed(self):
        project = Project(board_id="uno")
        project.add_communication("lora_radio", {"cs_pin": "10", "reset_pin": "9", "dio0_pin": "2"})
        project.add_communication("lora_radio", {"cs_pin": "7", "reset_pin": "8", "dio0_pin": "3"})
        self.assertTrue(any("Only one LoRa radio instance" in e for e in project.validate()))

    def test_lora_is_rejected_on_esp8266(self):
        project = Project(board_id="esp8266")
        project.add_communication("lora_radio")
        self.assertTrue(any("not supported" in e for e in project.validate()))

    def test_i2c_scanner_reserves_default_i2c_pins(self):
        project = Project(board_id="uno")
        project.add_communication("i2c_scanner")
        project.add_component("led", "LED on SDA", {"signal": "A4"})
        self.assertTrue(any("A4" in e and "shared I2C SDA bus" in e for e in project.validate()))

    def test_software_serial_defaults_are_board_specific(self):
        self.assertEqual(profile_defaults("hc05_bluetooth", "uno")["rx_pin"], "10")
        self.assertEqual(profile_defaults("hc05_bluetooth", "esp8266")["rx_pin"], "4")
        self.assertEqual(profile_defaults("hc05_bluetooth", "esp32")["rx_pin"], "16")

    def test_ap_and_ota_insecure_placeholders_must_be_replaced(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_ap")
        self.assertTrue(any("do not keep the placeholder" in e for e in p.validate()))
        q = Project(board_id="esp32")
        q.add_communication("wifi_sta", {"ssid": "Lab", "password": "wifi-pass-123"})
        q.add_communication("ota_update")
        self.assertTrue(any("OTA password" in e and "placeholder" in e for e in q.validate()))


if __name__ == "__main__":
    unittest.main()
