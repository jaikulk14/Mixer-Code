import unittest

from iot_studio.model import Project, Rule
from iot_studio.parser import parse_instruction, InstructionError
from iot_studio.codegen import generate_cpp
from iot_studio.boards import BOARDS, validate_pin, PinError
from iot_studio.library_manager import classify_cpp_snippets
from iot_studio.connectivity import PROFILES, profile_defaults


def sample_project():
    p = Project(name="Touch LED Demo", board_id="uno")
    p.add_component("touch_sensor", "Touch Sensor 1", {"signal": "2"})
    p.add_component("led", "LED 1", {"signal": "3"})
    return p


class CoreTests(unittest.TestCase):
    def test_parse_keyword_instruction(self):
        p = sample_project()
        rule = parse_instruction("WHEN Touch Sensor 1 TRUE THEN LED 1 GLOW", p)
        self.assertEqual(rule.sensor_id, "touch_sensor_1")
        self.assertEqual(rule.target_id, "led_1")
        self.assertEqual(rule.condition, "TRUE")
        self.assertEqual(rule.action, "GLOW")

    def test_parse_compact_keyword_sequence_without_then(self):
        p = sample_project()
        rule = parse_instruction("WHEN TouchSensor TRUE LED GLOW", p)
        self.assertEqual(rule.condition, "TRUE")
        self.assertEqual(rule.action, "GLOW")

    def test_parse_analog_threshold(self):
        p = Project(board_id="uno")
        p.add_component("ldr", "LDR 1", {"signal": "A0"})
        p.add_component("led", "LED 1", {"signal": "3"})
        rule = parse_instruction("WHEN LDR 1 ABOVE 700 THEN LED 1 GLOW", p)
        self.assertEqual(rule.condition, "ABOVE")
        self.assertEqual(rule.threshold, 700)

    def test_generate_sketch_has_safe_default(self):
        p = sample_project()
        p.add_rule(parse_instruction("WHEN Touch Sensor 1 TRUE THEN LED 1 GLOW", p))
        cpp = generate_cpp(p)
        self.assertIn("bool touch_sensor_1_state = (digitalRead(touch_sensor_1_pin) == HIGH);", cpp)
        self.assertIn("digitalWrite(led_1_pin, HIGH);", cpp)
        self.assertIn("Safe default when no rule matches", cpp)

    def test_all_supported_adapters_generate(self):
        from iot_studio.catalog import COMPONENTS
        from iot_studio.boards import allocate_pin
        # Validate every catalog adapter in its own project. A single physical
        # ESP32 cannot expose enough unique ADC pins to connect every analog
        # sensor profile simultaneously, and the app should not imply otherwise.
        for type_id, spec in COMPONENTS.items():
            with self.subTest(type_id=type_id):
                p = Project(name="Adapter coverage", board_id="esp32")
                used = {"21", "22"}  # Reserve the default I2C bus.
                pins = {}
                for pin_role in spec.pins:
                    if spec.kind == "digital_input":
                        role = "input"
                    elif spec.kind == "analog_input":
                        role = "analog"
                    elif spec.kind == "digital_output":
                        role = "output"
                    elif spec.kind == "servo_output":
                        role = "servo"
                    elif spec.kind == "distance_input":
                        role = "output" if pin_role == "trig" else "input"
                    else:
                        role = "output"
                    pin = allocate_pin(BOARDS[p.board_id], role, used)
                    pins[pin_role] = pin
                    used.add(pin)
                p.add_component(type_id, spec.display_name, pins)
                self.assertEqual(p.validate(), [])
                cpp = generate_cpp(p)
                self.assertIn("void loop()", cpp)
                if spec.kind == "distance_input":
                    self.assertIn("readDistanceCm", cpp)
                if spec.kind == "servo_output":
                    self.assertIn("ESP32Servo.h", cpp)

    def test_active_low_relay_output(self):
        p = Project(board_id="uno")
        p.add_component("touch_sensor", "Touch", {"signal": "2"})
        relay = p.add_component("relay", "Relay", {"signal": "3"})
        relay.active_level = "LOW"
        p.add_rule(parse_instruction("WHEN Touch TRUE THEN Relay ACTIVATE", p))
        cpp = generate_cpp(p)
        self.assertIn("digitalWrite(relay_pin, HIGH);", cpp)  # inactive setup state
        self.assertIn("digitalWrite(relay_pin, LOW);", cpp)   # active relay state

    def test_servo_instruction(self):
        p = Project(board_id="uno")
        p.add_component("touch_sensor", "Touch Sensor 1", {"signal": "2"})
        p.add_component("servo", "Servo Motor 1", {"signal": "3"})
        rule = parse_instruction("WHEN Touch Sensor 1 TRUE Servo Motor 1 SET ANGLE 90", p)
        self.assertEqual(rule.action, "SET_ANGLE")
        self.assertEqual(rule.angle, 90)

    def test_pin_conflict_is_rejected(self):
        p = Project(board_id="uno")
        p.add_component("touch_sensor", "Touch", {"signal": "2"})
        p.add_component("led", "LED", {"signal": "2"})
        self.assertTrue(any("assigned to both" in error for error in p.validate()))

    def test_board_pin_restrictions(self):
        with self.assertRaises(PinError):
            validate_pin(BOARDS["esp32"], "34", "output")
        with self.assertRaises(PinError):
            validate_pin(BOARDS["uno"], "A6", "analog")

    def test_custom_component_code_is_inserted_into_correct_sections(self):
        p = Project(board_id="uno")
        p.add_custom_component(
            name="DHT22 Temperature Sensor",
            source_url="https://example.com/dht22-docs",
            includes="#include <DHT.h>",
            declarations="DHT dht(2, DHT22);\nconst int DHT_PIN = 2;",
            setup_code="dht.begin();",
            loop_code="float temperature = dht.readTemperature();\nSerial.println(temperature);",
        )
        cpp = generate_cpp(p)
        self.assertIn("#include <DHT.h>", cpp)
        self.assertIn("DHT dht(2, DHT22);", cpp)
        self.assertIn("  dht.begin();", cpp)
        self.assertIn("  float temperature = dht.readTemperature();", cpp)
        self.assertIn("// Documentation source: https://example.com/dht22-docs", cpp)
        self.assertLess(cpp.index("#include <DHT.h>"), cpp.index("void setup()"))
        self.assertLess(cpp.index("dht.begin();"), cpp.index("void loop()"))

    def test_custom_component_project_round_trip(self):
        p = Project(board_id="uno")
        p.add_custom_component(
            name="MAX30102",
            source_url="https://example.com/max30102",
            includes="#include <MAX30105.h>",
            declarations="MAX30105 particleSensor;",
            setup_code="particleSensor.begin();",
            loop_code="particleSensor.check();",
            notes="Use 3.3V logic.",
        )
        restored = Project.from_dict(p.to_dict())
        self.assertEqual(len(restored.custom_components), 1)
        self.assertEqual(restored.custom_components[0].name, "MAX30102")
        self.assertEqual(restored.custom_components[0].loop_code, "particleSensor.check();")
        self.assertEqual(restored.validate(), [])

    def test_legacy_v1_project_loads_without_custom_code(self):
        legacy = {"version": 1, "name": "Old Project", "board_id": "uno", "components": [], "rules": []}
        restored = Project.from_dict(legacy)
        self.assertEqual(restored.name, "Old Project")
        self.assertEqual(restored.custom_components, [])

    def test_bad_instruction_fails_clearly(self):
        p = sample_project()
        with self.assertRaises(InstructionError):
            parse_instruction("Touch Sensor 1 maybe LED 1 glow", p)


    def test_ssd1306_display_generates_i2c_driver_and_setup(self):
        p = Project(board_id="uno")
        p.add_component("ssd1306_oled", "OLED Display", {})
        cpp = generate_cpp(p)
        self.assertIn("#include <Wire.h>", cpp)
        self.assertIn("#include <Adafruit_SSD1306.h>", cpp)
        self.assertIn("Adafruit_SSD1306 oled_display_display(128, 64, &Wire, -1);", cpp)
        self.assertIn("oled_display_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)", cpp)
        self.assertIn("I2C pins: SDA=A4, SCL=A5", cpp)
        self.assertEqual(len(p.libraries), 2)

    def test_lcd1602_generates_library_and_address(self):
        p = Project(board_id="uno")
        p.add_component("lcd1602_i2c", "LCD 1", {}, settings={"address": "0x3F"})
        cpp = generate_cpp(p)
        self.assertIn("#include <hd44780ioClass/hd44780_I2Cexp.h>", cpp)
        self.assertIn("hd44780_I2Cexp lcd_1_display(0x3F);", cpp)
        self.assertIn("lcd_1_display.begin(16, 2)", cpp)
        self.assertEqual(p.libraries[0].name, "hd44780")

    def test_independent_servo_and_ultrasonic_tasks_are_nonblocking(self):
        p = Project(board_id="uno")
        servo = p.add_component("servo", "Radar Servo", {"signal": "5"})
        sonar = p.add_component("hc_sr04", "Radar Sonar", {"trig": "2", "echo": "3"})
        p.add_task("servo_sweep", servo.id, interval_ms=20, start_angle=0, end_angle=180, step_degrees=2)
        p.add_task("ultrasonic_monitor", sonar.id, interval_ms=60)
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("tick_servo_sweep_radar_servo()", cpp)
        self.assertIn("tick_ultrasonic_monitor_radar_sonar()", cpp)
        self.assertIn("micros()", cpp)
        self.assertIn("No blocking delay", cpp)
        self.assertNotIn("pulseIn(", cpp)
        self.assertNotIn("delay(20)", cpp)
        self.assertIn("float radar_sonar_distance_cm = -1.0f;", cpp)
        self.assertIn("int ultrasonic_monitor_radar_sonar_angle_at_ping = 0;", cpp)
        self.assertIn('Serial.print(F("RADAR,")); Serial.print(ultrasonic_monitor_radar_sonar_angle_at_ping);', cpp)
        self.assertIn('Serial.println(F(",-1"));', cpp)

    def test_independent_servo_task_round_trip(self):
        p = Project(board_id="uno")
        servo = p.add_component("servo", "Servo 1", {"signal": "5"})
        p.add_task("servo_sweep", servo.id, interval_ms=15, start_angle=10, end_angle=170, step_degrees=5)
        p.add_library("Servo", "#include <Servo.h>", version="1.2.2")
        restored = Project.from_dict(p.to_dict())
        self.assertEqual(restored.version, 6)
        self.assertEqual(restored.tasks[0].step_degrees, 5)
        self.assertEqual(restored.libraries[0].name, "Servo")
        self.assertEqual(restored.validate(), [])

    def test_documentation_scanner_classifies_code_blocks(self):
        cpp_snippet = """#include <DHT.h>
DHT dht(2, DHT22);
void setup() {
  dht.begin();
}
void loop() {
  float t = dht.readTemperature();
}"""
        result = classify_cpp_snippets([cpp_snippet], "https://example.com/dht", "DHT sample")
        self.assertIn("#include <DHT.h>", result["includes"])
        self.assertIn("DHT dht(2, DHT22);", result["declarations"])
        self.assertIn("dht.begin();", result["setup_code"])
        self.assertIn("dht.readTemperature()", result["loop_code"])

    def test_servo_sweep_and_rule_conflict_is_rejected(self):
        p = Project(board_id="uno")
        touch = p.add_component("touch_sensor", "Touch", {"signal": "2"})
        servo = p.add_component("servo", "Servo", {"signal": "5"})
        p.add_rule(Rule(touch.id, "TRUE", None, servo.id, "SET_ANGLE", 90))
        p.add_task("servo_sweep", servo.id)
        self.assertTrue(any("already controlled by an independent sweep" in e for e in p.validate()))


    def test_html_documentation_page_parser_extracts_sections(self):
        from iot_studio.library_manager import _SnippetHTMLParser
        html = """<html><head><title>Sensor docs</title></head><body>
        <pre><code>#include &lt;Sensor.h&gt;
Sensor sensor;
void setup() { sensor.begin(); }
void loop() { sensor.read(); }</code></pre>
        </body></html>"""
        parser = _SnippetHTMLParser()
        parser.feed(html)
        self.assertEqual("".join(parser.title_parts), "Sensor docs")
        self.assertEqual(len(parser.blocks), 1)
        result = classify_cpp_snippets(parser.blocks, "https://example.org/sensor", "Sensor docs")
        self.assertIn("#include <Sensor.h>", result["includes"])
        self.assertIn("sensor.begin();", result["setup_code"])
        self.assertIn("sensor.read();", result["loop_code"])

    def test_display_project_adds_expected_library_dependencies(self):
        p = Project(board_id="uno")
        p.add_component("ssd1306_oled", "OLED", {})
        names = {item.name for item in p.libraries}
        self.assertEqual(names, {"Adafruit GFX Library", "Adafruit SSD1306"})
        p.add_component("lcd1602_i2c", "LCD", {})
        self.assertIn("hd44780", {item.name for item in p.libraries})

    def test_display_updates_from_continuous_radar_tasks(self):
        p = Project(board_id="uno")
        p.add_component("ssd1306_oled", "OLED", {})
        servo = p.add_component("servo", "Radar Servo", {"signal": "5"})
        sonar = p.add_component("hc_sr04", "Radar Sonar", {"trig": "2", "echo": "3"})
        p.add_task("servo_sweep", servo.id, 20, 0, 180, 2)
        p.add_task("ultrasonic_monitor", sonar.id, 60)
        cpp = generate_cpp(p)
        self.assertIn("MIXER CODE RADAR", cpp)
        self.assertIn("Distance:", cpp)
        self.assertIn("Angle:", cpp)
        self.assertIn("oled_display.display()", cpp)


    def test_i2c_display_reserves_bus_pins(self):
        p = Project(board_id="uno")
        p.add_component("ssd1306_oled", "OLED", {})
        p.add_component("ldr", "Light Sensor", {"signal": "A4"})
        self.assertTrue(any("shared I2C SDA bus" in error for error in p.validate()))

    def test_component_removal_cleans_up_related_independent_tasks(self):
        p = Project(board_id="uno")
        servo = p.add_component("servo", "Servo", {"signal": "5"})
        p.add_task("servo_sweep", servo.id)
        p.remove_component(servo.id)
        self.assertEqual(p.tasks, [])
        self.assertEqual(p.validate(), [])

    def test_custom_offline_library_round_trip(self):
        import tempfile
        from unittest.mock import patch
        from pathlib import Path
        from iot_studio.model import CustomCodeComponent
        from iot_studio.custom_library import save_custom_definition, load_custom_definitions
        item = CustomCodeComponent("dht22", "DHT22", includes="#include <DHT.h>", setup_code="dht.begin();")
        with tempfile.TemporaryDirectory() as folder:
            with patch("iot_studio.custom_library.custom_library_dir", return_value=Path(folder)):
                save_custom_definition(item)
                loaded = load_custom_definitions()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].name, "DHT22")
        self.assertEqual(loaded[0].setup_code, "dht.begin();")


    def test_duplicate_i2c_display_addresses_are_rejected(self):
        p = Project(board_id="uno")
        p.add_component("ssd1306_oled", "OLED 1", {}, settings={"address": "0x3C"})
        p.add_component("ssd1306_oled", "OLED 2", {}, settings={"address": "0x3C"})
        self.assertTrue(any("I2C address 0x3C is already used" in error for error in p.validate()))

    def test_legacy_esp32_servo_project_restores_required_library_dependency(self):
        legacy = {
            "version": 2, "name": "Legacy ESP32 servo", "board_id": "esp32",
            "components": [{"id": "servo_1", "type_id": "servo", "name": "Servo 1",
                            "pins": {"signal": "18"}, "active_level": "HIGH"}],
            "rules": [],
        }
        restored = Project.from_dict(legacy)
        self.assertIn("esp32servo", {item.name.casefold() for item in restored.libraries})
        cpp = generate_cpp(restored)
        self.assertIn("#include <ESP32Servo.h>", cpp)

    def test_esp32_servo_dependency_does_not_duplicate_conditional_include(self):
        p = Project(board_id="esp32")
        p.add_component("servo", "Servo", {"signal": "18"})
        cpp = generate_cpp(p)
        self.assertEqual(cpp.count("#include <ESP32Servo.h>"), 1)
        self.assertIn("#if defined(ARDUINO_ARCH_ESP32)", cpp)

    def test_oled_dashboard_analog_single_value_generates_real_sensor_readout(self):
        p = Project(board_id="uno")
        oled = p.add_component("ssd1306_oled", "OLED Display", {})
        ldr = p.add_component("ldr", "Room Light", {"signal": "A0"})
        p.set_oled_screen(oled.id, "single_value", "ROOM LIGHT", [ldr.id], 250)
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("unsigned long oled_display_last_update_ms = 0;", cpp)
        self.assertIn("int room_light_value = analogRead(room_light_pin);", cpp)
        self.assertIn("millis() - oled_display_last_update_ms) >= 250UL", cpp)
        self.assertIn('oled_display_display.println(F("ROOM LIGHT"))', cpp)
        self.assertIn("oled_display_display.print(room_light_value)", cpp)
        self.assertIn("room_light_value * 124L / 1023L", cpp)
        self.assertNotIn("MIXER CODE RADAR", cpp)

    def test_oled_dashboard_supports_two_column_list_and_bar_graph_layouts(self):
        for layout, sensors, expected in (
            ("two_column", 2, "oled_display_display.setCursor(66, 20)"),
            ("list", 3, "oled_display_display.setCursor(98, 37)"),
            ("bar_graph", 3, "oled_display_display.drawRect(0, 54, 128, 7, SSD1306_WHITE)"),
        ):
            with self.subTest(layout=layout):
                p = Project(board_id="uno")
                oled = p.add_component("ssd1306_oled", "OLED Display", {})
                sensor_ids = []
                for index in range(sensors):
                    sensor = p.add_component("ldr", f"Light {index + 1}", {"signal": f"A{index}"})
                    sensor_ids.append(sensor.id)
                p.set_oled_screen(oled.id, layout, "SENSOR VIEW", sensor_ids, 300)
                self.assertEqual(p.validate(), [])
                cpp = generate_cpp(p)
                self.assertIn(expected, cpp)
                self.assertIn(".display();", cpp)

    def test_oled_auto_dashboard_works_without_saving_designer_layout(self):
        # Regression for projects like the user's MQ example: adding an OLED
        # and an analog sensor must produce a live reading without requiring
        # a prior visit to the OLED Designer tab.
        p = Project(board_id="uno")
        oled = p.add_component("ssd1306_oled", "SSD1306 OLED", {})
        mq = p.add_component("mq_gas", "MQ Gas Sensor 1", {"signal": "A0"})
        self.assertEqual(p.oled_screens, [])
        cpp = generate_cpp(p)
        self.assertIn("int mq_gas_sensor_1_value = analogRead(mq_gas_sensor_1_pin);", cpp)
        self.assertIn("Automatic OLED dashboard", cpp)
        self.assertIn('oled_display.println(F("SENSOR MONITOR"))', cpp)
        self.assertIn('oled_display.println(F("MQ Gas Sensor 1"))', cpp)
        self.assertIn("oled_display.print(mq_gas_sensor_1_value)", cpp)
        self.assertIn("oled_display.fillRect(2, 55", cpp)
        self.assertIn("millis() - ssd1306_oled_last_update_ms) >= 250UL", cpp)
        # Auto-layout is generated as a fallback, not silently written into
        # the user's project file.
        self.assertEqual(p.oled_screens, [])

    def test_oled_auto_dashboard_selects_layout_by_analog_sensor_count(self):
        cases = (
            (2, "two_column", "oled_display.setCursor(66, 20)"),
            (3, "bar_graph", "oled_display.drawRect(0, 54, 128, 7"),
            (4, "list", "oled_display.setCursor(98, 49)"),
        )
        for count, layout, expected in cases:
            with self.subTest(count=count):
                p = Project(board_id="uno")
                p.add_component("ssd1306_oled", "OLED", {})
                for index in range(count):
                    p.add_component("ldr", f"Analog {index + 1}", {"signal": f"A{index}"})
                cpp = generate_cpp(p)
                self.assertIn("Automatic OLED dashboard", cpp)
                self.assertIn(expected, cpp)

    def test_oled_auto_dashboard_limits_to_four_sensors_with_clear_warning(self):
        p = Project(board_id="esp32")
        p.add_component("ssd1306_oled", "OLED", {})
        sensors = []
        for index, pin in enumerate(("32", "33", "34", "35", "36")):
            sensors.append(p.add_component("ldr", f"Analog {index + 1}", {"signal": pin}))
        cpp = generate_cpp(p)
        self.assertIn("OLED automatic dashboard shows the first 4 analog inputs", cpp)
        self.assertIn("analog_4_value", cpp)
        self.assertIn("int analog_5_value = analogRead(analog_5_pin);", cpp)  # Sensor is still sampled.
        self.assertNotIn('F("Analog 5")', cpp)  # But the four-row default display cannot show it.

    def test_saved_oled_designer_layout_overrides_automatic_dashboard(self):
        p = Project(board_id="uno")
        oled = p.add_component("ssd1306_oled", "OLED", {})
        first = p.add_component("ldr", "LDR First", {"signal": "A0"})
        second = p.add_component("mq_gas", "MQ Second", {"signal": "A1"})
        p.set_oled_screen(oled.id, "single_value", "CUSTOM VIEW", [second.id], 500)
        cpp = generate_cpp(p)
        self.assertIn('oled_display.println(F("CUSTOM VIEW"))', cpp)
        self.assertIn("oled_display.print(mq_second_value)", cpp)
        self.assertNotIn("Automatic OLED dashboard", cpp)
        self.assertNotIn("oled_display.print(ldr_first_value)", cpp)

    def test_oled_dashboard_configuration_round_trip_and_legacy_v3_migration(self):
        p = Project(board_id="uno")
        oled = p.add_component("ssd1306_oled", "OLED", {})
        ldr = p.add_component("ldr", "LDR", {"signal": "A0"})
        p.set_oled_screen(oled.id, "bar_graph", "LIGHT LEVEL", [ldr.id], 400)
        restored = Project.from_dict(p.to_dict())
        self.assertEqual(restored.version, 6)
        self.assertEqual(restored.oled_screens[0].layout, "bar_graph")
        self.assertEqual(restored.oled_screens[0].sensor_ids, [ldr.id])
        legacy = p.to_dict()
        legacy["version"] = 3
        legacy.pop("oled_screens")
        migrated = Project.from_dict(legacy)
        self.assertEqual(migrated.version, 6)
        self.assertEqual(migrated.oled_screens, [])

    def test_oled_dashboard_rejects_non_analog_sensor_and_too_many_channels(self):
        p = Project(board_id="uno")
        oled = p.add_component("ssd1306_oled", "OLED", {})
        button = p.add_component("push_button", "Button", {"signal": "2"})
        p.set_oled_screen(oled.id, "single_value", "INPUT", [button.id], 200)
        self.assertTrue(any("not an analog input sensor" in error for error in p.validate()))

        q = Project(board_id="uno")
        oled2 = q.add_component("ssd1306_oled", "OLED", {})
        ids = []
        for index in range(2):
            sensor = q.add_component("ldr", f"LDR {index + 1}", {"signal": f"A{index}"})
            ids.append(sensor.id)
        q.set_oled_screen(oled2.id, "single_value", "TOO MANY", ids, 200)
        self.assertTrue(any("supports at most 1 sensor" in error for error in q.validate()))

    def test_removing_oled_or_selected_sensor_cleans_screen_configuration(self):
        p = Project(board_id="uno")
        oled = p.add_component("ssd1306_oled", "OLED", {})
        sensor = p.add_component("ldr", "LDR", {"signal": "A0"})
        p.set_oled_screen(oled.id, "single_value", "LIGHT", [sensor.id], 200)
        p.remove_component(sensor.id)
        self.assertEqual(p.oled_screens, [])
        p.remove_component(oled.id)
        self.assertEqual(p.oled_screens, [])


    def test_communication_project_round_trip_and_legacy_migration(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_sta", {"ssid": "TestNet", "password": "secret123"})
        p.add_communication("mqtt_client", {"host": "192.168.1.20", "port": "1883"})
        restored = Project.from_dict(p.to_dict())
        self.assertEqual(restored.version, 6)
        self.assertEqual([item.profile_type for item in restored.communications], ["wifi_sta", "mqtt_client"])
        self.assertIn("pubsubclient", restored.required_builtin_library_names())
        old = Project.from_dict({"version": 4, "name": "Legacy", "board_id": "uno", "components": [], "rules": []})
        self.assertEqual(old.version, 6)
        self.assertEqual(old.communications, [])

    def test_esp32_wifi_mqtt_and_web_codegen(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_sta", {"ssid": "lab-network", "password": "password123"})
        p.add_communication("mqtt_client", {"host": "broker.example.com", "subscribe_topic": "lab/in", "publish_topic": "lab/out"})
        p.add_communication("web_server", {"port": "8080"})
        p.add_communication("http_get", {"url": "http://example.com/api", "interval_ms": "15000"})
        p.add_communication("udp_listener", {"listen_port": "4210"})
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        for expected in ("#include <WiFi.h>", "#include <PubSubClient.h>", "#include <WebServer.h>", "#include <HTTPClient.h>", "#include <WiFiUdp.h>", "WiFi.begin", "PubSubClient", "subscribe", "handleClient", "http.GET()", "parsePacket"):
            self.assertIn(expected, cpp)
        self.assertIn("void setup()", cpp)
        self.assertIn("void loop()", cpp)

    def test_wifi_access_point_configuration(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_ap", {"ssid": "Workshop", "password": "safe-pass-123"})
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("WiFi.mode(WIFI_AP)", cpp)
        self.assertIn("WiFi.softAP", cpp)
        self.assertIn("WiFi.softAPIP()", cpp)

    def test_mqtt_requires_station_mode_and_valid_port(self):
        p = Project(board_id="esp32")
        p.add_communication("mqtt_client", {"port": "70000"})
        errors = p.validate()
        self.assertTrue(any("requires Wi-Fi Station" in e for e in errors))
        self.assertTrue(any("MQTT port" in e for e in errors))

    def test_wifi_credentials_must_be_configured(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_sta")
        self.assertTrue(any("replace the Wi-Fi SSID placeholder" in e for e in p.validate()))

    def test_hc05_and_hm10_use_uart_adapter(self):
        for profile, rx, tx, symbol in (("hc05_bluetooth", "8", "9", "hc05_bluetooth"), ("hm10_ble_uart", "6", "7", "hm10_ble_uart")):
            with self.subTest(profile=profile):
                p = Project(board_id="uno")
                p.add_communication(profile, {"rx_pin": rx, "tx_pin": tx})
                self.assertEqual(p.validate(), [])
                cpp = generate_cpp(p)
                self.assertIn("#include <SoftwareSerial.h>", cpp)
                self.assertIn(f"SoftwareSerial mc_{symbol}_serial({rx}, {tx});", cpp)
                self.assertIn("while (Serial.available())", cpp)

    def test_multiple_software_uart_modules_are_rejected_on_uno(self):
        p = Project(board_id="uno")
        p.add_communication("hc05_bluetooth", {"rx_pin": "8", "tx_pin": "9"})
        p.add_communication("hm10_ble_uart", {"rx_pin": "6", "tx_pin": "7"})
        self.assertTrue(any("one serial port" in error for error in p.validate()))

    def test_esp32_bluetooth_classic_profile(self):
        p = Project(board_id="esp32")
        p.add_communication("esp32_bt_spp", {"device_name": "LabDevice"})
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("#include <BluetoothSerial.h>", cpp)
        self.assertIn('mc_esp32_bt_spp_bt.begin("LabDevice")', cpp)

    def test_bluetooth_classic_is_rejected_on_esp8266(self):
        p = Project(board_id="esp8266")
        p.add_communication("esp32_bt_spp")
        self.assertTrue(any("not supported" in e for e in p.validate()))

    def test_esp8266_native_wifi_generation_and_board_pins(self):
        p = Project(board_id="esp8266")
        p.add_communication("wifi_sta", {"ssid": "LabNet", "password": "secret123"})
        p.add_communication("web_server")
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("#include <ESP8266WiFi.h>", cpp)
        self.assertIn("#include <ESP8266WebServer.h>", cpp)
        self.assertIn("WiFi.begin", cpp)

    def test_esp8266_at_modem_uses_software_serial(self):
        p = Project(board_id="uno")
        p.add_communication("esp8266_at_wifi", {"rx_pin": "8", "tx_pin": "9", "ssid": "LabNet", "password": "pass1234"})
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("SoftwareSerial mc_esp8266_at_wifi_modem(8, 9);", cpp)
        self.assertIn("AT+CWMODE=1", cpp)
        self.assertIn("AT+CWJAP", cpp)
        self.assertNotIn("#include <WiFi.h>", cpp)

    def test_uart_pin_conflict_is_rejected(self):
        p = Project(board_id="uno")
        p.add_component("led", "LED", {"signal": "8"})
        p.add_communication("hc05_bluetooth", {"rx_pin": "8", "tx_pin": "9"})
        self.assertTrue(any("already assigned" in e for e in p.validate()))

    def test_spi_bus_pins_are_reserved(self):
        p = Project(board_id="uno")
        p.add_component("led", "LED", {"signal": "11"})
        p.add_communication("spi_transfer", {"cs_pin": "10"})
        self.assertTrue(any("hardware SPI bus" in e for e in p.validate()))

    def test_spi_transfer_and_sd_logger_codegen(self):
        p = Project(board_id="uno")
        p.add_communication("spi_transfer", {"cs_pin": "10", "tx_byte": "165", "clock_hz": "1000000"})
        p.add_communication("sd_logger", {"cs_pin": "4", "file_name": "telemetry.csv"})
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("#include <SPI.h>", cpp)
        self.assertIn("#include <SD.h>", cpp)
        self.assertIn("SPI.transfer(value)", cpp)
        self.assertIn('SD.open("telemetry.csv", FILE_WRITE)', cpp)

    def test_i2c_scanner_starts_wire_on_its_own(self):
        p = Project(board_id="uno")
        p.add_communication("i2c_scanner")
        cpp = generate_cpp(p)
        self.assertIn("#include <Wire.h>", cpp)
        self.assertIn("Wire.begin();", cpp)
        self.assertIn("I2C scan complete", cpp)

    def test_ntp_profile_generates_time_support(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_sta", {"ssid": "LabNet", "password": "secret123"})
        p.add_communication("ntp_sync")
        cpp = generate_cpp(p)
        self.assertIn("#include <time.h>", cpp)
        self.assertIn("configTime(19800, 0", cpp)
        self.assertIn("time(nullptr)", cpp)

    def test_ota_requires_password_and_starts_after_wifi(self):
        p = Project(board_id="esp32")
        p.add_communication("wifi_sta", {"ssid": "LabNet", "password": "secret123"})
        p.add_communication("ota_update", {"password": "short"})
        self.assertTrue(any("OTA password" in e for e in p.validate()))
        p.communications[-1].settings["password"] = "secure-pass-123"
        self.assertEqual(p.validate(), [])
        cpp = generate_cpp(p)
        self.assertIn("ArduinoOTA.setPassword", cpp)
        self.assertIn("!mc_ota_update_started", cpp)

    def test_communication_dependencies_removed_when_mqtt_removed(self):
        p = Project(board_id="esp32")
        p.add_communication("mqtt_client", {"host": "broker.local"})
        self.assertIn("PubSubClient", [lib.name for lib in p.libraries])
        p.remove_communication("mqtt_client")
        self.assertNotIn("PubSubClient", [lib.name for lib in p.libraries])



if __name__ == "__main__":
    unittest.main()
