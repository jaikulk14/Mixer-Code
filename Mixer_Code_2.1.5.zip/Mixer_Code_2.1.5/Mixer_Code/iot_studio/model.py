"""Project data model and validation."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any
import json
import re

from .catalog import COMPONENTS
from .boards import BOARDS, validate_pin, PinError
from .connectivity import validate_communications, required_connectivity_libraries, PROFILES


@dataclass
class Component:
    id: str
    type_id: str
    name: str
    pins: dict[str, str]
    active_level: str = "HIGH"
    settings: dict[str, Any] = field(default_factory=dict)


@dataclass
class Rule:
    sensor_id: str
    condition: str
    threshold: int | None
    target_id: str
    action: str
    angle: int | None = None


@dataclass
class CustomCodeComponent:
    """User-supplied adapter snippets copied from component documentation.

    Snippets are inserted into their matching Arduino sketch sections. The
    application does not interpret or validate arbitrary C++ pasted here.
    """
    id: str
    name: str
    source_url: str = ""
    includes: str = ""
    declarations: str = ""
    setup_code: str = ""
    loop_code: str = ""
    notes: str = ""


@dataclass
class LibraryDependency:
    id: str
    name: str
    includes: str = ""
    version: str = ""
    source_url: str = ""
    notes: str = ""


@dataclass
class IndependentTask:
    id: str
    name: str
    task_type: str
    component_id: str
    interval_ms: int = 20
    start_angle: int = 0
    end_angle: int = 180
    step_degrees: int = 1
    enabled: bool = True


@dataclass
class CommunicationProfile:
    id: str
    profile_type: str
    name: str
    settings: dict[str, Any] = field(default_factory=dict)


@dataclass
class SensorMonitor:
    """Continuous telemetry configuration for one project sensor.

    mode values:
      - threshold: preserve the normal WHEN/THEN rule behavior only
      - continuous: stream readings without evaluating threshold rules
      - both: stream readings and also evaluate WHEN/THEN rules
    """
    component_id: str
    mode: str = "threshold"
    interval_ms: int = 250


@dataclass
class OLEDScreenConfig:
    """Saved 128x64 SSD1306 dashboard layout for one OLED."""
    display_id: str
    layout: str = "single_value"
    title: str = "SENSOR DASHBOARD"
    sensor_ids: list[str] = field(default_factory=list)
    refresh_ms: int = 200


@dataclass
class Project:
    name: str = "My IoT Project"
    board_id: str = "uno"
    components: list[Component] = field(default_factory=list)
    rules: list[Rule] = field(default_factory=list)
    custom_components: list[CustomCodeComponent] = field(default_factory=list)
    libraries: list[LibraryDependency] = field(default_factory=list)
    tasks: list[IndependentTask] = field(default_factory=list)
    oled_screens: list[OLEDScreenConfig] = field(default_factory=list)
    communications: list[CommunicationProfile] = field(default_factory=list)
    sensor_monitors: list[SensorMonitor] = field(default_factory=list)
    version: int = 6

    def component(self, component_id: str) -> Component:
        for item in self.components:
            if item.id == component_id:
                return item
        raise KeyError(f"Component not found: {component_id}")

    def add_component(self, type_id: str, name: str, pins: dict[str, str], active_level: str | None = None, settings: dict[str, Any] | None = None) -> Component:
        if type_id not in COMPONENTS:
            raise ValueError(f"Unknown component type: {type_id}")
        base = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") or type_id
        candidate, n = base, 2
        existing = {x.id for x in self.components}
        while candidate in existing:
            candidate = f"{base}_{n}"
            n += 1
        spec = COMPONENTS[type_id]
        defaults = {"address": "0x3C"} if type_id == "ssd1306_oled" else {"address": "0x27"} if type_id == "lcd1602_i2c" else {}
        defaults.update(settings or {})
        component = Component(candidate, type_id, name, dict(pins), active_level or spec.default_active_level, defaults)
        self.components.append(component)
        # Known driver dependencies are recorded with the project so they can
        # be checked/installed through Arduino CLI later.
        self.ensure_builtin_dependencies()
        return component

    def ensure_builtin_dependencies(self) -> None:
        """Keep project dependency metadata in sync with built-in adapters."""
        component_types = {component.type_id for component in self.components}
        if "ssd1306_oled" in component_types:
            self._add_library_if_missing("Adafruit GFX Library", "#include <Adafruit_GFX.h>", "https://github.com/adafruit/Adafruit-GFX-Library")
            self._add_library_if_missing("Adafruit SSD1306", "#include <Adafruit_SSD1306.h>", "https://github.com/adafruit/Adafruit_SSD1306")
        if "lcd1602_i2c" in component_types:
            self._add_library_if_missing("hd44780", "#include <hd44780.h>\n#include <hd44780ioClass/hd44780_I2Cexp.h>", "https://github.com/duinoWitchery/hd44780", notes="Uses hd44780_I2Cexp for common PCF8574 I2C backpacks.")
        if self.board_id == "esp32" and "servo" in component_types:
            self._add_library_if_missing("ESP32Servo", "#include <ESP32Servo.h>", "https://github.com/madhephaestus/ESP32Servo")
        for name, includes, source_url, notes in required_connectivity_libraries(self):
            self._add_library_if_missing(name, includes, source_url, notes=notes)

    def required_builtin_library_names(self) -> set[str]:
        """Names that remain necessary while the matching built-in adapter exists."""
        required: set[str] = set()
        component_types = {component.type_id for component in self.components}
        if "ssd1306_oled" in component_types:
            required.update({"adafruit gfx library", "adafruit ssd1306"})
        if "lcd1602_i2c" in component_types:
            required.add("hd44780")
        if self.board_id == "esp32" and "servo" in component_types:
            required.add("esp32servo")
        required.update(name.casefold() for name, _includes, _url, _notes in required_connectivity_libraries(self))
        return required

    def _add_library_if_missing(self, name: str, includes: str, source_url: str, notes: str = "") -> None:
        if not any(item.name.casefold() == name.casefold() for item in self.libraries):
            self.add_library(name, includes, source_url=source_url, notes=notes)

    def remove_component(self, component_id: str) -> None:
        self.components = [c for c in self.components if c.id != component_id]
        self.rules = [r for r in self.rules if r.sensor_id != component_id and r.target_id != component_id]
        self.tasks = [task for task in self.tasks if task.component_id != component_id]
        self.sensor_monitors = [item for item in self.sensor_monitors if item.component_id != component_id]
        self.oled_screens = [screen for screen in self.oled_screens if screen.display_id != component_id]
        for screen in self.oled_screens:
            screen.sensor_ids = [sensor_id for sensor_id in screen.sensor_ids if any(c.id == sensor_id for c in self.components)]
        self.oled_screens = [screen for screen in self.oled_screens if screen.sensor_ids]

    def oled_screen(self, display_id: str) -> OLEDScreenConfig | None:
        return next((screen for screen in self.oled_screens if screen.display_id == display_id), None)

    def default_oled_screen(self, display_id: str) -> OLEDScreenConfig | None:
        """Return an automatic, non-persisted OLED dashboard when analog sensors exist.

        This fallback is shared by the UI preview and C++ generator so both
        show the same default layout. A saved designer configuration always
        takes precedence and this method never mutates the project.
        """
        try:
            display = self.component(display_id)
        except KeyError:
            return None
        if display.type_id != "ssd1306_oled":
            return None
        sensors = [item for item in self.components if COMPONENTS[item.type_id].kind == "analog_input"]
        if not sensors:
            return None
        count = min(len(sensors), 4)
        if count == 1:
            layout = "single_value"
        elif count == 2:
            layout = "two_column"
        elif count == 3:
            layout = "bar_graph"
        else:
            layout = "list"
        return OLEDScreenConfig(
            display_id=display_id,
            layout=layout,
            title="SENSOR MONITOR",
            sensor_ids=[sensor.id for sensor in sensors[:4]],
            refresh_ms=250,
        )

    def set_oled_screen(
        self,
        display_id: str,
        layout: str,
        title: str,
        sensor_ids: list[str],
        refresh_ms: int = 200,
    ) -> OLEDScreenConfig:
        config = self.oled_screen(display_id)
        if config is None:
            config = OLEDScreenConfig(display_id=display_id)
            self.oled_screens.append(config)
        config.layout = layout
        config.title = title.strip() or "SENSOR DASHBOARD"
        config.sensor_ids = list(dict.fromkeys(sensor_ids))
        config.refresh_ms = int(refresh_ms)
        return config

    def add_communication(self, profile_type: str, settings: dict[str, Any] | None = None, name: str | None = None) -> CommunicationProfile:
        if profile_type not in PROFILES:
            raise ValueError(f"Unknown connectivity profile: {profile_type}")
        from .connectivity import profile_defaults
        merged = profile_defaults(profile_type, self.board_id)
        merged.update({str(k): str(v) for k, v in (settings or {}).items()})
        base = re.sub(r"[^a-z0-9]+", "_", (name or profile_type).lower()).strip("_") or "communication"
        candidate, n = base, 2
        existing = {item.id for item in self.communications}
        while candidate in existing:
            candidate = f"{base}_{n}"
            n += 1
        item = CommunicationProfile(candidate, profile_type, name or PROFILES[profile_type]["name"], merged)
        self.communications.append(item)
        self.ensure_builtin_dependencies()
        return item

    def remove_communication(self, communication_id: str) -> None:
        self.communications = [item for item in self.communications if item.id != communication_id]
        # Remove automatically-managed dependencies only when no active adapter
        # still requires them. User-added dependencies are otherwise preserved.
        still_required = self.required_builtin_library_names()
        managed_names = {"pubsubclient", "lora"}
        self.libraries = [
            lib for lib in self.libraries
            if lib.name.casefold() not in managed_names or lib.name.casefold() in still_required
        ]

    def add_rule(self, rule: Rule) -> None:
        self.rules.append(rule)

    def add_custom_component(
        self,
        name: str,
        source_url: str = "",
        includes: str = "",
        declarations: str = "",
        setup_code: str = "",
        loop_code: str = "",
        notes: str = "",
    ) -> CustomCodeComponent:
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("Custom component name cannot be empty.")
        base = re.sub(r"[^a-z0-9]+", "_", clean_name.lower()).strip("_") or "custom_component"
        candidate, n = base, 2
        existing = {item.id for item in self.custom_components}
        while candidate in existing:
            candidate = f"{base}_{n}"
            n += 1
        component = CustomCodeComponent(
            id=candidate,
            name=clean_name,
            source_url=source_url.strip(),
            includes=includes,
            declarations=declarations,
            setup_code=setup_code,
            loop_code=loop_code,
            notes=notes,
        )
        self.custom_components.append(component)
        return component

    def remove_custom_component(self, component_id: str) -> None:
        self.custom_components = [item for item in self.custom_components if item.id != component_id]


    def add_library(self, name: str, includes: str = "", version: str = "", source_url: str = "", notes: str = "") -> LibraryDependency:
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("Library name cannot be empty.")
        base = re.sub(r"[^a-z0-9]+", "_", clean_name.lower()).strip("_") or "library"
        candidate, n = base, 2
        existing = {item.id for item in self.libraries}
        while candidate in existing:
            candidate = f"{base}_{n}"
            n += 1
        item = LibraryDependency(candidate, clean_name, includes.strip(), version.strip(), source_url.strip(), notes.strip())
        self.libraries.append(item)
        return item

    def remove_library(self, library_id: str) -> None:
        self.libraries = [item for item in self.libraries if item.id != library_id]

    def add_task(self, task_type: str, component_id: str, interval_ms: int = 20,
                 start_angle: int = 0, end_angle: int = 180, step_degrees: int = 1,
                 name: str | None = None) -> IndependentTask:
        component = self.component(component_id)
        base = re.sub(r"[^a-z0-9]+", "_", (name or f"{task_type}_{component.name}").lower()).strip("_") or "task"
        candidate, n = base, 2
        existing = {item.id for item in self.tasks}
        while candidate in existing:
            candidate = f"{base}_{n}"
            n += 1
        task = IndependentTask(candidate, name or f"{task_type.replace('_', ' ').title()} - {component.name}",
                               task_type, component_id, int(interval_ms), int(start_angle), int(end_angle), int(step_degrees))
        self.tasks.append(task)
        return task

    def remove_task(self, task_id: str) -> None:
        self.tasks = [item for item in self.tasks if item.id != task_id]

    def sensor_monitor(self, component_id: str) -> SensorMonitor | None:
        return next((item for item in self.sensor_monitors if item.component_id == component_id), None)

    def set_sensor_monitor(self, component_id: str, mode: str, interval_ms: int = 250) -> SensorMonitor:
        component = self.component(component_id)
        if COMPONENTS[component.type_id].kind not in ("analog_input", "digital_input", "distance_input"):
            raise ValueError(f"{component.name} is not a supported sensor input.")
        if mode not in ("threshold", "continuous", "both"):
            raise ValueError(f"Unsupported sensor monitoring mode: {mode}.")
        config = self.sensor_monitor(component_id)
        if config is None:
            config = SensorMonitor(component_id=component_id)
            self.sensor_monitors.append(config)
        config.mode = mode
        config.interval_ms = int(interval_ms)
        return config

    def remove_sensor_monitor(self, component_id: str) -> None:
        self.sensor_monitors = [item for item in self.sensor_monitors if item.component_id != component_id]

    def validate(self) -> list[str]:
        errors: list[str] = []
        board = BOARDS.get(self.board_id)
        if board is None:
            return [f"Unknown board profile: {self.board_id}"]
        used_pins: dict[str, str] = {}
        i2c_addresses: dict[int, str] = {}
        uses_i2c = any(COMPONENTS.get(c.type_id) and COMPONENTS[c.type_id].kind == "display_output" for c in self.components) or any(
            getattr(item, "profile_type", "") == "i2c_scanner" for item in self.communications
        )
        if uses_i2c:
            if self.board_id in ("uno", "nano"):
                used_pins.update({"A4": "shared I2C SDA bus", "A5": "shared I2C SCL bus"})
            elif self.board_id == "esp32":
                used_pins.update({"21": "shared I2C SDA bus", "22": "shared I2C SCL bus"})
            elif self.board_id == "esp8266":
                used_pins.update({"4": "shared I2C SDA bus", "5": "shared I2C SCL bus"})
        for c in self.components:
            spec = COMPONENTS.get(c.type_id)
            if spec is None:
                errors.append(f"{c.name}: unknown component type {c.type_id}.")
                continue
            if set(c.pins) != set(spec.pins):
                errors.append(f"{c.name}: expected pin fields {', '.join(spec.pins)}.")
                continue
            for pin_role, pin in c.pins.items():
                role = "input" if spec.kind == "digital_input" else "analog" if spec.kind == "analog_input" else "output" if spec.kind == "digital_output" else "servo" if spec.kind == "servo_output" else "output" if spec.kind == "distance_input" and pin_role == "trig" else "input"
                try:
                    validate_pin(board, pin, role)
                except PinError as exc:
                    errors.append(f"{c.name}: {exc}")
                normalized = pin.upper()
                if normalized in used_pins:
                    errors.append(f"Pin {pin} is assigned to both {used_pins[normalized]} and {c.name}.")
                else:
                    used_pins[normalized] = c.name
            if spec.kind != "display_output" and c.active_level not in ("HIGH", "LOW"):
                errors.append(f"{c.name}: active level must be HIGH or LOW.")
            if c.type_id in ("ssd1306_oled", "lcd1602_i2c"):
                address = str(c.settings.get("address", "0x3C" if c.type_id == "ssd1306_oled" else "0x27"))
                valid_format = re.fullmatch(r"(?:0[xX][0-9a-fA-F]{1,2}|[0-9]{1,3})", address)
                try:
                    numeric_address = int(address, 16) if address.lower().startswith("0x") else int(address)
                except ValueError:
                    numeric_address = -1
                if not valid_format or not 0x03 <= numeric_address <= 0x77:
                    errors.append(f"{c.name}: invalid 7-bit I2C address {address!r}. Use a value such as 0x3C or 0x27.")
                elif numeric_address in i2c_addresses:
                    errors.append(f"{c.name}: I2C address {address} is already used by {i2c_addresses[numeric_address]}.")
                else:
                    i2c_addresses[numeric_address] = c.name
        task_targets: set[tuple[str, str]] = set()
        display_ids: set[str] = set()
        valid_oled_layouts = {"single_value", "two_column", "list", "bar_graph"}
        max_sensors_by_layout = {"single_value": 1, "two_column": 2, "list": 4, "bar_graph": 3}
        for index, screen in enumerate(self.oled_screens, start=1):
            if screen.display_id in display_ids:
                errors.append(f"OLED screen {index}: duplicate screen configuration for display {screen.display_id}.")
            display_ids.add(screen.display_id)
            try:
                display = self.component(screen.display_id)
            except KeyError:
                errors.append(f"OLED screen {index}: display component {screen.display_id} does not exist.")
                continue
            if display.type_id != "ssd1306_oled":
                errors.append(f"OLED screen {index}: screen designer requires an SSD1306 OLED display.")
            if screen.layout not in valid_oled_layouts:
                errors.append(f"OLED screen {index}: unsupported layout {screen.layout!r}.")
            if not 100 <= screen.refresh_ms <= 5000:
                errors.append(f"OLED screen {index}: refresh interval must be 100 to 5000 ms.")
            if not screen.title.strip():
                errors.append(f"OLED screen {index}: title cannot be empty.")
            if len(screen.title) > 20:
                errors.append(f"OLED screen {index}: title must be 20 characters or fewer for the preview header.")
            if len(screen.sensor_ids) != len(set(screen.sensor_ids)):
                errors.append(f"OLED screen {index}: the same analog sensor cannot be added more than once.")
            maximum = max_sensors_by_layout.get(screen.layout, 0)
            if maximum and len(screen.sensor_ids) > maximum:
                errors.append(f"OLED screen {index}: {screen.layout.replace('_', ' ')} supports at most {maximum} sensor(s).")
            if not screen.sensor_ids:
                errors.append(f"OLED screen {index}: add at least one analog sensor to the screen.")
            for sensor_id in screen.sensor_ids:
                try:
                    sensor = self.component(sensor_id)
                except KeyError:
                    errors.append(f"OLED screen {index}: selected sensor {sensor_id} does not exist.")
                    continue
                if COMPONENTS[sensor.type_id].kind != "analog_input":
                    errors.append(f"OLED screen {index}: {sensor.name} is not an analog input sensor.")
        for index, library in enumerate(self.libraries, start=1):
            if not library.name.strip():
                errors.append(f"Library {index}: name cannot be empty.")
            if library.source_url and not library.source_url.lower().startswith(("https://", "http://")):
                errors.append(f"Library {library.name}: source URL must start with http:// or https://.")
        for index, task in enumerate(self.tasks, start=1):
            try:
                target = self.component(task.component_id)
            except KeyError as exc:
                errors.append(f"Independent task {index}: {exc}")
                continue
            if not task.enabled:
                continue
            if not 1 <= task.interval_ms <= 60000:
                errors.append(f"Independent task {task.name}: interval must be 1 to 60000 ms.")
            kind = COMPONENTS[target.type_id].kind
            target_key = (task.task_type, task.component_id)
            if target_key in task_targets:
                errors.append(f"Independent task {task.name}: duplicate {task.task_type} task for {target.name}.")
            task_targets.add(target_key)
            if task.task_type == "servo_sweep":
                if kind != "servo_output":
                    errors.append(f"Independent task {task.name}: servo sweep requires a servo motor.")
                if task.interval_ms < 10:
                    errors.append(f"Independent task {task.name}: servo sweep interval must be at least 10 ms.")
                if not (0 <= task.start_angle < task.end_angle <= 180):
                    errors.append(f"Independent task {task.name}: sweep requires 0 <= start < end <= 180 degrees.")
                if not 1 <= task.step_degrees <= 45:
                    errors.append(f"Independent task {task.name}: step must be between 1 and 45 degrees.")
            elif task.task_type == "ultrasonic_monitor":
                if kind != "distance_input":
                    errors.append(f"Independent task {task.name}: continuous distance monitor requires an ultrasonic sensor.")
                if task.interval_ms < 60:
                    errors.append(f"Independent task {task.name}: HC-SR04 ping interval must be at least 60 ms.")
            else:
                errors.append(f"Independent task {task.name}: unsupported task type {task.task_type}.")
        seen_monitor_ids: set[str] = set()
        legacy_distance_task_ids = {task.component_id for task in self.tasks if task.enabled and task.task_type == "ultrasonic_monitor"}
        for index, monitor in enumerate(self.sensor_monitors, start=1):
            if monitor.component_id in seen_monitor_ids:
                errors.append(f"Sensor monitor {index}: duplicate monitor configuration for {monitor.component_id}.")
            seen_monitor_ids.add(monitor.component_id)
            try:
                sensor = self.component(monitor.component_id)
            except KeyError:
                errors.append(f"Sensor monitor {index}: component {monitor.component_id} does not exist.")
                continue
            kind = COMPONENTS[sensor.type_id].kind
            if kind not in ("analog_input", "digital_input", "distance_input"):
                errors.append(f"Sensor monitor {index}: {sensor.name} is not a supported sensor input.")
            if monitor.mode not in ("threshold", "continuous", "both"):
                errors.append(f"Sensor monitor {sensor.name}: mode must be threshold, continuous or both.")
            if not 10 <= monitor.interval_ms <= 60000:
                errors.append(f"Sensor monitor {sensor.name}: interval must be 10 to 60000 ms.")
            if kind == "distance_input" and monitor.interval_ms < 60:
                errors.append(f"Sensor monitor {sensor.name}: HC-SR04 monitoring interval must be at least 60 ms.")
            if kind == "distance_input" and monitor.mode in ("continuous", "both") and monitor.component_id in legacy_distance_task_ids:
                errors.append(f"Sensor monitor {sensor.name}: remove the older Continuous ultrasonic monitor task or use this monitor mode, not both.")
            if monitor.mode == "continuous" and any(rule.sensor_id == monitor.component_id for rule in self.rules):
                errors.append(f"Sensor monitor {sensor.name}: continuous-only mode cannot also have threshold rules. Choose Both to use both behaviors.")
        sweeping_servos = {task.component_id for task in self.tasks if task.enabled and task.task_type == "servo_sweep"}
        for index, rule in enumerate(self.rules, start=1):
            if rule.target_id in sweeping_servos:
                errors.append(f"Rule {index}: servo {self.component(rule.target_id).name} is already controlled by an independent sweep task. Remove one control source to avoid conflicts.")
        for index, custom in enumerate(self.custom_components, start=1):
            if not custom.name.strip():
                errors.append(f"Custom component {index}: name cannot be empty.")
            if custom.source_url and not custom.source_url.lower().startswith(("https://", "http://")):
                errors.append(f"Custom component {custom.name or index}: source URL must start with http:// or https://.")
        for index, rule in enumerate(self.rules, start=1):
            try:
                source = self.component(rule.sensor_id)
                target = self.component(rule.target_id)
            except KeyError as exc:
                errors.append(f"Rule {index}: {exc}")
                continue
            source_kind = COMPONENTS[source.type_id].kind
            target_kind = COMPONENTS[target.type_id].kind
            allowed_conditions = (
                {"TRUE", "FALSE", "DETECTED", "NOT_DETECTED"} if source_kind == "digital_input"
                else {"ABOVE", "BELOW"} if source_kind == "analog_input"
                else {"BELOW", "ABOVE", "DETECTED", "NOT_DETECTED"} if source_kind == "distance_input"
                else set()
            )
            if rule.condition not in allowed_conditions:
                errors.append(f"Rule {index}: condition {rule.condition} is not valid for {source.name}.")
            needs_numeric_threshold = source_kind in ("analog_input", "distance_input") and rule.condition in ("ABOVE", "BELOW")
            if needs_numeric_threshold and rule.threshold is None:
                errors.append(f"Rule {index}: ABOVE and BELOW require a numeric threshold.")
            if not needs_numeric_threshold and rule.threshold is not None:
                errors.append(f"Rule {index}: {rule.condition} is a state/event condition and must not have a numeric threshold.")
            if source_kind == "analog_input" and rule.threshold is not None and not (0 <= rule.threshold <= board.adc_max):
                errors.append(f"Rule {index}: analog threshold must be between 0 and {board.adc_max} for this board.")
            if source_kind == "distance_input" and rule.threshold is not None and not (1 <= rule.threshold <= 400):
                errors.append(f"Rule {index}: ultrasonic threshold must be between 1 and 400 cm.")
            if target_kind not in ("digital_output", "servo_output"):
                errors.append(f"Rule {index}: {target.name} is not an output component.")
                continue
            if target_kind == "digital_output":
                valid_actions_by_type = {
                    "led": {"GLOW", "ON", "OFF"},
                    "buzzer": {"BEEP", "SILENCE", "ON", "OFF"},
                    "relay": {"ACTIVATE", "DEACTIVATE", "ON", "OFF"},
                }
                valid_actions = valid_actions_by_type.get(target.type_id, {"ON", "OFF"})
            else:
                valid_actions = {"SET_ANGLE"}
            if rule.action not in valid_actions:
                errors.append(f"Rule {index}: action {rule.action} is not supported by {target.name}. Allowed: {', '.join(sorted(valid_actions))}.")
            if rule.action == "SET_ANGLE" and (rule.angle is None or not 0 <= rule.angle <= 180):
                errors.append(f"Rule {index}: servo angle must be between 0 and 180 degrees.")
        errors.extend(validate_communications(self))
        return errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "name": self.name,
            "board_id": self.board_id,
            "components": [asdict(c) for c in self.components],
            "rules": [asdict(r) for r in self.rules],
            "custom_components": [asdict(c) for c in self.custom_components],
            "libraries": [asdict(item) for item in self.libraries],
            "tasks": [asdict(item) for item in self.tasks],
            "oled_screens": [asdict(item) for item in self.oled_screens],
            "communications": [asdict(item) for item in self.communications],
            "sensor_monitors": [asdict(item) for item in self.sensor_monitors],
        }

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Project":
        saved_version = data.get("version", 1)
        if saved_version not in (1, 2, 3, 4, 5, 6):
            raise ValueError(f"Unsupported project version: {saved_version}")
        project = cls(name=str(data.get("name", "My IoT Project")), board_id=str(data.get("board_id", "uno")))
        project.components = [Component(**item) for item in data.get("components", [])]
        project.rules = [Rule(**item) for item in data.get("rules", [])]
        project.custom_components = [CustomCodeComponent(**item) for item in data.get("custom_components", [])]
        project.libraries = [LibraryDependency(**item) for item in data.get("libraries", [])]
        project.tasks = [IndependentTask(**item) for item in data.get("tasks", [])]
        project.oled_screens = [OLEDScreenConfig(**item) for item in data.get("oled_screens", [])]
        project.communications = [CommunicationProfile(**item) for item in data.get("communications", [])]
        project.sensor_monitors = [SensorMonitor(**item) for item in data.get("sensor_monitors", [])]
        project.version = 6
        project.ensure_builtin_dependencies()
        return project

    @classmethod
    def load(cls, path: str) -> "Project":
        with open(path, "r", encoding="utf-8") as f:
            return cls.from_dict(json.load(f))
