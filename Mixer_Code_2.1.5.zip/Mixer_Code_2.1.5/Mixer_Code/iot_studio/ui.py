"""Tkinter desktop interface for Mixer Code."""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from pathlib import Path
import threading
import re

from .boards import BOARDS, allocate_pin, PinError, validate_pin
from .catalog import COMPONENTS, PLANNED_COMPONENTS
from .model import Project, Rule, CustomCodeComponent
from .parser import parse_instruction, InstructionError
from .codegen import generate_cpp
from .library_manager import scan_documentation_url, DocumentationImportError, list_installed_libraries, install_library
from .custom_library import save_custom_definition, load_custom_definitions, custom_library_dir
from .integration_import import extract_integration_document, IntegrationExtraction
from .connectivity import PROFILES, profile_options, profile_defaults


class IoTCodeStudio:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Mixer Code 2.1.5")
        self.root.geometry("1240x860")
        self.root.minsize(1020, 700)
        self.project = Project()
        self.current_project_path: str | None = None
        self.code_text: tk.Text | None = None
        self._configure_style()
        self._build_shell()
        self._refresh_all()

    def _configure_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("Brand.TFrame", background="#071126")
        style.configure("Brand.TLabel", background="#071126", foreground="#f4f7ff")
        style.configure("BrandSub.TLabel", background="#071126", foreground="#a9c7e8")
        style.configure("Sub.TLabel", foreground="#526071")
        style.configure("Keyword.TLabel", foreground="#183153", background="#eaf2fb", padding=(9, 7), font=("Segoe UI", 9, "bold"))
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 7))
        style.configure("Treeview", rowheight=27)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def _build_shell(self):
        header = ttk.Frame(self.root, padding=(16, 8), style="Brand.TFrame")
        header.pack(fill="x")
        title_area = ttk.Frame(header, style="Brand.TFrame")
        title_area.pack(side="left", fill="x", expand=True)

        # ASCII wordmark: self-contained, crisp on every Windows install and offline.
        ascii_wordmark = "\n".join((
            '#   #  #####  #   #  #####  ####        ####   ####  ####   #####',
            '## ##    #     # #   #      #   #      #      #   #  #   #  #    ',
            '# # #    #      #    ####   ####       #      #   #  #   #  #### ',
            '#   #    #     # #   #      # #        #      #   #  #   #  #    ',
            '#   #  #####  #   #  #####  #  ##       ####   ####  ####   #####',
        ))
        ttk.Label(
            title_area,
            text=ascii_wordmark,
            style="Brand.TLabel",
            font=("Consolas", 10, "bold"),
            justify="center",
        ).pack(anchor="center", pady=(2, 0))
        ttk.Label(
            title_area,
            text="M I X E R   C O D E   |   I O T   P R O J E C T   B U I L D E R",
            style="BrandSub.TLabel",
            font=("Segoe UI", 8, "bold"),
        ).pack(anchor="center", pady=(1, 5))

        actions = ttk.Frame(header, style="Brand.TFrame")
        actions.pack(side="right", anchor="e")
        ttk.Button(actions, text="New", command=self.new_project).pack(side="left", padx=3)
        ttk.Button(actions, text="Open", command=self.open_project).pack(side="left", padx=3)
        ttk.Button(actions, text="Save", command=self.save_project).pack(side="left", padx=3)

        project_bar = ttk.Frame(self.root, padding=(16, 0, 16, 10))
        project_bar.pack(fill="x")
        ttk.Label(project_bar, text="Project name").pack(side="left")
        self.project_name_var = tk.StringVar(value=self.project.name)
        name_entry = ttk.Entry(project_bar, textvariable=self.project_name_var, width=32)
        name_entry.pack(side="left", padx=(8, 22))
        name_entry.bind("<FocusOut>", lambda _e: self._sync_project_name())
        ttk.Label(project_bar, text="Target board").pack(side="left")
        self.board_var = tk.StringVar(value=BOARDS[self.project.board_id].display_name)
        board_box = ttk.Combobox(project_bar, textvariable=self.board_var, state="readonly", width=27, values=[b.display_name for b in BOARDS.values()])
        board_box.pack(side="left", padx=8)
        board_box.bind("<<ComboboxSelected>>", self._board_changed)
        self.board_note = ttk.Label(project_bar, text=BOARDS[self.project.board_id].notes, style="Sub.TLabel")
        self.board_note.pack(side="left", padx=(10, 0), fill="x", expand=True)

        keyword_bar = ttk.LabelFrame(self.root, text="Keyword reference", padding=(10, 5))
        keyword_bar.pack(fill="x", padx=16, pady=(0, 8))
        keyword_text = (
            "FLOW: WHEN, THEN    |    CONDITIONS: TRUE, FALSE, DETECTED, NOT_DETECTED, ABOVE, BELOW    |    "
            "ACTIONS: GLOW, ON, OFF, BEEP, SILENCE, ACTIVATE, DEACTIVATE, SET ANGLE"
        )
        ttk.Label(keyword_bar, text=keyword_text, style="Keyword.TLabel", wraplength=1160, justify="left").pack(fill="x")

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        self.components_tab = ttk.Frame(self.notebook, padding=12)
        self.logic_tab = ttk.Frame(self.notebook, padding=12)
        self.code_tab = ttk.Frame(self.notebook, padding=12)
        self.custom_tab = ttk.Frame(self.notebook, padding=12)
        self.tasks_tab = ttk.Frame(self.notebook, padding=12)
        self.library_tab = ttk.Frame(self.notebook, padding=12)
        self.oled_tab = ttk.Frame(self.notebook, padding=12)
        self.connectivity_tab = ttk.Frame(self.notebook, padding=12)
        self.monitor_tab = ttk.Frame(self.notebook, padding=12)
        self.notebook.add(self.components_tab, text="  1. Components  ")
        self.notebook.add(self.logic_tab, text="  2. Logic Builder  ")
        self.notebook.add(self.tasks_tab, text="  3. Independent Tasks  ")
        self.notebook.add(self.code_tab, text="  4. C++ Code  ")
        self.notebook.add(self.custom_tab, text="  5. Custom Components  ")
        self.notebook.add(self.library_tab, text="  6. Libraries & URL Import  ")
        self.notebook.add(self.oled_tab, text="  7. OLED Designer  ")
        self.notebook.add(self.connectivity_tab, text="  8. Connectivity & Protocols  ")
        self.notebook.add(self.monitor_tab, text="  9. Sensor Monitor  ")
        self._build_components_tab()
        self._build_logic_tab()
        self._build_tasks_tab()
        self._build_code_tab()
        self._build_custom_tab()
        self._build_library_tab()
        self._build_oled_tab()
        self._build_connectivity_tab()
        self._build_sensor_monitor_tab()

        footer = ttk.Frame(self.root, padding=(16, 5, 16, 10))
        footer.pack(fill="x")
        self.status_var = tk.StringVar(value="Ready. Add components, create rules, then generate the sketch.")
        ttk.Label(footer, textvariable=self.status_var, style="Sub.TLabel").pack(side="left", fill="x", expand=True)
        ttk.Button(footer, text="Validate Project", command=self.validate_project).pack(side="right", padx=(6, 0))
        ttk.Button(footer, text="Generate C++", style="Primary.TButton", command=self.generate_code).pack(side="right")

    def _build_components_tab(self):
        self.components_tab.columnconfigure(0, weight=1)
        self.components_tab.columnconfigure(1, weight=2)
        self.components_tab.rowconfigure(0, weight=1)
        library = ttk.LabelFrame(self.components_tab, text="Component library", padding=10)
        library.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        library.columnconfigure(0, weight=1)
        library.rowconfigure(2, weight=1)
        ttk.Label(library, text="Choose a category").grid(row=0, column=0, sticky="w")
        self.category_var = tk.StringVar(value="All supported")
        self.category_box = ttk.Combobox(library, textvariable=self.category_var, state="readonly", values=self._categories(), width=24)
        self.category_box.grid(row=1, column=0, sticky="ew", pady=(4, 8))
        self.category_box.bind("<<ComboboxSelected>>", lambda _e: self._refresh_catalog())
        self.catalog_list = tk.Listbox(library, height=15, exportselection=False, activestyle="dotbox")
        self.catalog_list.grid(row=2, column=0, sticky="nsew")
        self.catalog_list.bind("<<ListboxSelect>>", self._show_component_description)
        self.catalog_list.bind("<Double-Button-1>", lambda _e: self.add_component())
        self.catalog_description = tk.StringVar(value="Select a component to see what it does.")
        ttk.Label(library, textvariable=self.catalog_description, wraplength=260, justify="left", style="Sub.TLabel").grid(row=3, column=0, sticky="ew", pady=(8, 8))
        ttk.Button(library, text="Add selected component", style="Primary.TButton", command=self.add_component).grid(row=4, column=0, sticky="ew")

        right = ttk.LabelFrame(self.components_tab, text="Project wiring", padding=10)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(0, weight=1)
        self.component_tree = ttk.Treeview(right, columns=("type", "pins", "active"), show="headings", selectmode="browse")
        self.component_tree.heading("type", text="Component")
        self.component_tree.heading("pins", text="Pin assignment")
        self.component_tree.heading("active", text="Active level / polarity")
        self.component_tree.column("type", width=210)
        self.component_tree.column("pins", width=220)
        self.component_tree.column("active", width=100, anchor="center")
        self.component_tree.grid(row=0, column=0, sticky="nsew")
        self.component_tree.bind("<Double-Button-1>", lambda _e: self.edit_selected_pins())
        scroll = ttk.Scrollbar(right, orient="vertical", command=self.component_tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.component_tree.configure(yscrollcommand=scroll.set)
        row = ttk.Frame(right)
        row.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        ttk.Button(row, text="Edit pins", command=self.edit_selected_pins).pack(side="left")
        ttk.Button(row, text="Remove selected", command=self.remove_component).pack(side="left", padx=8)
        ttk.Button(row, text="Change active level", command=self.change_active_level).pack(side="left")
        ttk.Label(right, text="Pins are assigned automatically from the selected board profile. Adding an I2C display reserves the board's SDA/SCL pins; multiple I2C devices share that bus.", style="Sub.TLabel", wraplength=580).grid(row=2, column=0, sticky="w", pady=(10, 0))

        planned = ttk.LabelFrame(self.components_tab, text="Display and future adapters", padding=8)
        planned.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Label(planned, text="Built-in displays: SSD1306 OLED 128x64 (I2C) and LCD 16x2 (I2C).\nOther devices such as DHT, MPU6050, MAX30102, SH1106 and HX711 can be added with Custom Components or the URL importer.", style="Sub.TLabel", justify="left").pack(anchor="w")

    def _build_logic_tab(self):
        self.logic_tab.columnconfigure(0, weight=1)
        self.logic_tab.rowconfigure(2, weight=1)
        command_box = ttk.LabelFrame(self.logic_tab, text="Write a rule using keywords", padding=10)
        command_box.grid(row=0, column=0, sticky="ew")
        command_box.columnconfigure(0, weight=1)
        ttk.Label(command_box, text="Examples: WHEN Touch Sensor TRUE THEN LED GLOW  |  WHEN Ultrasonic DETECTED THEN Buzzer BEEP", style="Sub.TLabel").grid(row=0, column=0, sticky="w")
        command_row = ttk.Frame(command_box)
        command_row.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        command_row.columnconfigure(0, weight=1)
        self.command_var = tk.StringVar()
        command_entry = ttk.Entry(command_row, textvariable=self.command_var)
        command_entry.grid(row=0, column=0, sticky="ew")
        command_entry.bind("<Return>", lambda _e: self.add_instruction())
        ttk.Button(command_row, text="Parse and add", style="Primary.TButton", command=self.add_instruction).grid(row=0, column=1, padx=(8, 0))

        builder = ttk.LabelFrame(self.logic_tab, text="Or build a rule with selections", padding=10)
        builder.grid(row=1, column=0, sticky="ew", pady=(10, 10))
        for col in (1, 3, 5, 7):
            builder.columnconfigure(col, weight=1)
        ttk.Label(builder, text="WHEN").grid(row=0, column=0, sticky="w")
        self.source_var = tk.StringVar()
        self.source_box = ttk.Combobox(builder, textvariable=self.source_var, state="readonly", width=19)
        self.source_box.grid(row=0, column=1, sticky="ew", padx=(5, 10))
        self.source_box.bind("<<ComboboxSelected>>", self._update_conditions)
        self.condition_var = tk.StringVar(value="TRUE")
        self.condition_box = ttk.Combobox(builder, textvariable=self.condition_var, state="readonly", values=("TRUE", "FALSE"), width=14)
        self.condition_box.grid(row=0, column=2, sticky="ew", padx=(0, 10))
        self.condition_box.bind("<<ComboboxSelected>>", self._update_conditions)
        self.threshold_var = tk.StringVar(value="500")
        self.threshold_entry = ttk.Entry(builder, textvariable=self.threshold_var, width=8)
        self.threshold_entry.grid(row=0, column=3, sticky="ew", padx=(0, 10))
        ttk.Label(builder, text="THEN").grid(row=0, column=4, sticky="w")
        self.target_var = tk.StringVar()
        self.target_box = ttk.Combobox(builder, textvariable=self.target_var, state="readonly", width=16)
        self.target_box.grid(row=0, column=5, sticky="ew", padx=(5, 10))
        self.target_box.bind("<<ComboboxSelected>>", self._update_actions)
        self.action_var = tk.StringVar(value="GLOW")
        self.action_box = ttk.Combobox(builder, textvariable=self.action_var, state="readonly", values=("GLOW", "ON", "OFF", "BEEP", "SILENCE", "ACTIVATE", "DEACTIVATE", "SET ANGLE"), width=13)
        self.action_box.grid(row=0, column=6, sticky="ew", padx=(0, 8))
        self.angle_var = tk.StringVar(value="90")
        self.angle_entry = ttk.Entry(builder, textvariable=self.angle_var, width=5)
        self.angle_entry.grid(row=0, column=7, sticky="ew", padx=(0, 8))
        ttk.Button(builder, text="Add rule", command=self.add_structured_rule).grid(row=0, column=8)
        ttk.Label(builder, text="DETECTED / NOT_DETECTED need no numeric value. ABOVE / BELOW use a threshold. For HC-SR04, DETECTED means a valid echo was received.", style="Sub.TLabel").grid(row=1, column=0, columnspan=9, sticky="w", pady=(8, 0))

        rules_frame = ttk.LabelFrame(self.logic_tab, text="Current logic", padding=10)
        rules_frame.grid(row=2, column=0, sticky="nsew")
        rules_frame.rowconfigure(0, weight=1)
        rules_frame.columnconfigure(0, weight=1)
        self.rule_tree = ttk.Treeview(rules_frame, columns=("when", "then"), show="headings")
        self.rule_tree.heading("when", text="Condition")
        self.rule_tree.heading("then", text="Action")
        self.rule_tree.column("when", width=390)
        self.rule_tree.column("then", width=390)
        self.rule_tree.grid(row=0, column=0, sticky="nsew")
        ttk.Button(rules_frame, text="Remove selected rule", command=self.remove_rule).grid(row=1, column=0, sticky="w", pady=(8, 0))

    def _build_tasks_tab(self):
        self.tasks_tab.columnconfigure(0, weight=1)
        self.tasks_tab.rowconfigure(1, weight=1)
        intro = ttk.LabelFrame(self.tasks_tab, text="Run independent behaviours", padding=10)
        intro.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(intro, text=(
            "Independent tasks run on their own millis()/micros() schedules on every pass through loop(). "
            "They do not wait for another sensor condition. This is cooperative, non-blocking scheduling, "
            "not true parallel threads."
        ), style="Sub.TLabel", wraplength=1060, justify="left").grid(row=0, column=0, columnspan=10, sticky="w", pady=(0, 8))
        ttk.Label(intro, text="Task").grid(row=1, column=0, sticky="w")
        self.task_type_var = tk.StringVar(value="Servo sweep")
        self.task_type_box = ttk.Combobox(intro, textvariable=self.task_type_var, state="readonly", width=30, values=("Servo sweep", "Continuous ultrasonic monitor"))
        self.task_type_box.grid(row=1, column=1, sticky="w", padx=6)
        self.task_type_box.bind("<<ComboboxSelected>>", self._refresh_task_component_choices)
        ttk.Label(intro, text="Component").grid(row=1, column=2, sticky="w")
        self.task_component_var = tk.StringVar()
        self.task_component_box = ttk.Combobox(intro, textvariable=self.task_component_var, state="readonly", width=28)
        self.task_component_box.grid(row=1, column=3, sticky="w", padx=6)
        ttk.Label(intro, text="Interval (ms)").grid(row=1, column=4, sticky="w")
        self.task_interval_var = tk.StringVar(value="20")
        ttk.Entry(intro, textvariable=self.task_interval_var, width=7).grid(row=1, column=5, sticky="w", padx=5)
        ttk.Label(intro, text="Start").grid(row=2, column=0, sticky="w", pady=(8, 0))
        self.task_start_var = tk.StringVar(value="0")
        ttk.Entry(intro, textvariable=self.task_start_var, width=6).grid(row=2, column=1, sticky="w", padx=6, pady=(8, 0))
        ttk.Label(intro, text="End").grid(row=2, column=2, sticky="w", pady=(8, 0))
        self.task_end_var = tk.StringVar(value="180")
        ttk.Entry(intro, textvariable=self.task_end_var, width=6).grid(row=2, column=3, sticky="w", padx=6, pady=(8, 0))
        ttk.Label(intro, text="Step (degrees)").grid(row=2, column=4, sticky="w", pady=(8, 0))
        self.task_step_var = tk.StringVar(value="2")
        ttk.Entry(intro, textvariable=self.task_step_var, width=6).grid(row=2, column=5, sticky="w", padx=5, pady=(8, 0))
        ttk.Button(intro, text="Add independent task", style="Primary.TButton", command=self.add_independent_task).grid(row=1, column=6, rowspan=2, padx=(14, 0), sticky="ns")
        task_frame = ttk.LabelFrame(self.tasks_tab, text="Scheduled tasks in this project", padding=10)
        task_frame.grid(row=1, column=0, sticky="nsew")
        task_frame.rowconfigure(0, weight=1)
        task_frame.columnconfigure(0, weight=1)
        self.task_tree = ttk.Treeview(task_frame, columns=("type", "component", "interval", "config"), show="headings", height=12)
        for col, label, width in (("type", "Task", 230), ("component", "Component", 230), ("interval", "Interval", 100), ("config", "Configuration", 260)):
            self.task_tree.heading(col, text=label)
            self.task_tree.column(col, width=width)
        self.task_tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(task_frame, orient="vertical", command=self.task_tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.task_tree.configure(yscrollcommand=scroll.set)
        ttk.Button(task_frame, text="Remove selected task", command=self.remove_independent_task).grid(row=1, column=0, sticky="w", pady=(8, 0))
        self._refresh_task_component_choices()

    def _build_sensor_monitor_tab(self):
        self.monitor_tab.columnconfigure(0, weight=1)
        self.monitor_tab.rowconfigure(2, weight=1)
        intro = ttk.LabelFrame(self.monitor_tab, text="Choose how each sensor behaves", padding=12)
        intro.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(
            intro,
            text=(
                "Threshold rules react only when a WHEN/THEN condition matches. Continuous monitoring "
                "samples the sensor at a fixed interval and prints every reading to Serial Monitor, "
                "without requiring ABOVE/BELOW values. Both runs telemetry and threshold rules together."
            ),
            style="Sub.TLabel", wraplength=1080, justify="left"
        ).grid(row=0, column=0, columnspan=8, sticky="w", pady=(0, 10))
        ttk.Label(intro, text="Sensor").grid(row=1, column=0, sticky="w")
        self.monitor_sensor_var = tk.StringVar()
        self.monitor_sensor_box = ttk.Combobox(intro, textvariable=self.monitor_sensor_var, state="readonly", width=28)
        self.monitor_sensor_box.grid(row=1, column=1, sticky="w", padx=6)
        self.monitor_sensor_box.bind("<<ComboboxSelected>>", self._load_sensor_monitor_selection)
        ttk.Label(intro, text="Behavior").grid(row=1, column=2, sticky="w", padx=(10, 0))
        self.monitor_mode_var = tk.StringVar(value="Threshold rules only")
        self.monitor_mode_box = ttk.Combobox(
            intro, textvariable=self.monitor_mode_var, state="readonly", width=30,
            values=("Threshold rules only", "Continuous monitor only", "Continuous + threshold rules")
        )
        self.monitor_mode_box.grid(row=1, column=3, sticky="w", padx=6)
        ttk.Label(intro, text="Interval (ms)").grid(row=1, column=4, sticky="w", padx=(10, 0))
        self.monitor_interval_var = tk.StringVar(value="250")
        ttk.Entry(intro, textvariable=self.monitor_interval_var, width=8).grid(row=1, column=5, sticky="w", padx=6)
        ttk.Button(intro, text="Apply mode", style="Primary.TButton", command=self.apply_sensor_monitor_mode).grid(row=1, column=6, padx=(12, 4))
        ttk.Button(intro, text="Reset to threshold", command=self.reset_sensor_monitor_mode).grid(row=1, column=7, padx=4)
        ttk.Label(
            self.monitor_tab,
            text=(
                "Output format: MONITOR,<component_id>,<type>,<value>. Analog sensors report ADC values; "
                "digital sensors report ACTIVE/INACTIVE; HC-SR04 reports distance in cm or -1 when no echo is received. "
                "HC-SR04 intervals must be at least 60 ms. Continuous-only mode cannot keep threshold rules for the same sensor."
            ),
            style="Sub.TLabel", wraplength=1080, justify="left"
        ).grid(row=1, column=0, sticky="ew", pady=(0, 10))
        frame = ttk.LabelFrame(self.monitor_tab, text="Sensor behavior configuration", padding=10)
        frame.grid(row=2, column=0, sticky="nsew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.monitor_tree = ttk.Treeview(frame, columns=("mode", "interval", "output"), show="headings", height=12)
        for col, label, width in (("mode", "Behavior", 300), ("interval", "Interval", 110), ("output", "Output", 230)):
            self.monitor_tree.heading(col, text=label)
            self.monitor_tree.column(col, width=width)
        self.monitor_tree.grid(row=0, column=0, sticky="nsew")
        self.monitor_tree.bind("<<TreeviewSelect>>", self._select_sensor_monitor_row)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.monitor_tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.monitor_tree.configure(yscrollcommand=scroll.set)
        ttk.Label(
            frame,
            text="A sensor with no saved entry uses the original threshold-rule behavior. Continuous monitoring is cooperative and non-blocking; it does not create a separate processor thread.",
            style="Sub.TLabel", wraplength=1000, justify="left"
        ).grid(row=1, column=0, sticky="w", pady=(8, 0))
        self._refresh_sensor_monitor_controls()

    def _refresh_sensor_monitor_controls(self):
        if not hasattr(self, "monitor_sensor_box"):
            return
        sensors = [c for c in self.project.components if COMPONENTS[c.type_id].kind in ("analog_input", "digital_input", "distance_input")]
        self._monitor_sensor_map = {c.name: c.id for c in sensors}
        self.monitor_sensor_box["values"] = list(self._monitor_sensor_map)
        if self.monitor_sensor_var.get() not in self._monitor_sensor_map:
            self.monitor_sensor_var.set(next(iter(self._monitor_sensor_map), ""))
        self._refresh_sensor_monitor_tree()
        self._load_sensor_monitor_selection()

    def _refresh_sensor_monitor_tree(self):
        if not hasattr(self, "monitor_tree"):
            return
        for row in self.monitor_tree.get_children():
            self.monitor_tree.delete(row)
        for component in self.project.components:
            if COMPONENTS[component.type_id].kind not in ("analog_input", "digital_input", "distance_input"):
                continue
            config = self.project.sensor_monitor(component.id)
            mode = config.mode if config else "threshold"
            interval = config.interval_ms if config else 250
            label = {
                "threshold": "Threshold rules only",
                "continuous": "Continuous monitor only",
                "both": "Continuous + threshold rules",
            }.get(mode, mode)
            output = "Serial Monitor" if mode in ("continuous", "both") else "WHEN/THEN rules"
            self.monitor_tree.insert("", "end", iid=component.id, values=(label, f"{interval} ms", output))

    def _load_sensor_monitor_selection(self, _event=None):
        component_id = getattr(self, "_monitor_sensor_map", {}).get(self.monitor_sensor_var.get())
        if not component_id:
            self.monitor_mode_var.set("Threshold rules only")
            self.monitor_interval_var.set("250")
            return
        config = self.project.sensor_monitor(component_id)
        mode = config.mode if config else "threshold"
        self.monitor_mode_var.set({
            "threshold": "Threshold rules only",
            "continuous": "Continuous monitor only",
            "both": "Continuous + threshold rules",
        }.get(mode, "Threshold rules only"))
        self.monitor_interval_var.set(str(config.interval_ms if config else 250))

    def _select_sensor_monitor_row(self, _event=None):
        selected = self.monitor_tree.selection()
        if not selected:
            return
        component_id = selected[0]
        component = self.project.component(component_id)
        self.monitor_sensor_var.set(component.name)
        self._load_sensor_monitor_selection()

    def apply_sensor_monitor_mode(self):
        component_id = getattr(self, "_monitor_sensor_map", {}).get(self.monitor_sensor_var.get())
        if not component_id:
            messagebox.showinfo("Select a sensor", "Add an analog, digital or ultrasonic sensor in the Components tab first.")
            return
        mode = {
            "Threshold rules only": "threshold",
            "Continuous monitor only": "continuous",
            "Continuous + threshold rules": "both",
        }.get(self.monitor_mode_var.get())
        if not mode:
            messagebox.showerror("Choose a behavior", "Select a valid sensor behavior.")
            return
        try:
            interval = int(self.monitor_interval_var.get())
        except ValueError:
            messagebox.showerror("Invalid interval", "Enter a whole-number interval in milliseconds.")
            return
        candidate = Project.from_dict(self.project.to_dict())
        try:
            candidate.set_sensor_monitor(component_id, mode, interval)
        except (ValueError, KeyError) as exc:
            messagebox.showerror("Monitor mode not applied", str(exc))
            return
        errors = [e for e in candidate.validate() if e.startswith("Sensor monitor")]
        if errors:
            messagebox.showerror("Monitor configuration invalid", "\n".join(errors))
            return
        self.project.sensor_monitors = candidate.sensor_monitors
        self._refresh_sensor_monitor_tree()
        self.status_var.set(f"Updated monitoring behavior for {self.project.component(component_id).name}.")

    def reset_sensor_monitor_mode(self):
        component_id = getattr(self, "_monitor_sensor_map", {}).get(self.monitor_sensor_var.get())
        if not component_id:
            return
        self.project.remove_sensor_monitor(component_id)
        self._refresh_sensor_monitor_controls()
        self.status_var.set("Sensor reset to threshold rules only (default behavior).")

    def _build_code_tab(self):
        self.code_tab.rowconfigure(1, weight=1)
        self.code_tab.columnconfigure(0, weight=1)
        bar = ttk.Frame(self.code_tab)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(bar, text="Generate preview", style="Primary.TButton", command=self.generate_code).pack(side="left")
        ttk.Button(bar, text="Save .ino sketch", command=self.save_sketch).pack(side="left", padx=8)
        ttk.Button(bar, text="Copy code", command=self.copy_code).pack(side="left")
        self.code_text = tk.Text(self.code_tab, wrap="none", font=("Consolas", 10), undo=False, padx=10, pady=10, background="#111827", foreground="#e5e7eb", insertbackground="#ffffff")
        self.code_text.grid(row=1, column=0, sticky="nsew")
        yscroll = ttk.Scrollbar(self.code_tab, orient="vertical", command=self.code_text.yview)
        yscroll.grid(row=1, column=1, sticky="ns")
        xscroll = ttk.Scrollbar(self.code_tab, orient="horizontal", command=self.code_text.xview)
        xscroll.grid(row=2, column=0, sticky="ew")
        self.code_text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.code_text.insert("1.0", "// Your generated Arduino C++ sketch will appear here.\n")

    def _build_custom_tab(self):
        self.custom_tab.columnconfigure(0, weight=0)
        self.custom_tab.columnconfigure(1, weight=1)
        self.custom_tab.rowconfigure(1, weight=1)

        intro = ttk.Label(
            self.custom_tab,
            text=(
                "For a component missing from the built-in library, either import one complete Arduino sketch / README "
                "and let Mixer Code split it automatically, or paste snippets into the four sections below. "
                "Review the extracted code before saving. Arbitrary custom C++ is not automatically pin-checked "
                "or connected to the WHEN/THEN rule system."
            ),
            style="Sub.TLabel", wraplength=1100, justify="left",
        )
        intro.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 10))

        left = ttk.LabelFrame(self.custom_tab, text="Custom components in this project", padding=8)
        left.grid(row=1, column=0, sticky="nsw", padx=(0, 10))
        left.rowconfigure(0, weight=1)
        self.custom_tree = ttk.Treeview(left, columns=("source",), show="tree headings", height=18, selectmode="browse")
        self.custom_tree.heading("#0", text="Component")
        self.custom_tree.heading("source", text="Source")
        self.custom_tree.column("#0", width=190)
        self.custom_tree.column("source", width=90)
        self.custom_tree.grid(row=0, column=0, columnspan=2, sticky="nsew")
        self.custom_tree.bind("<<TreeviewSelect>>", self.load_custom_component)
        ttk.Button(left, text="New custom component", command=self.new_custom_component).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 4))
        ttk.Button(left, text="Remove selected", command=self.remove_custom_component).grid(row=2, column=0, columnspan=2, sticky="ew")

        editor = ttk.LabelFrame(self.custom_tab, text="Paste code from official documentation", padding=10)
        editor.grid(row=1, column=1, sticky="nsew")
        editor.columnconfigure(1, weight=1)
        editor.rowconfigure(3, weight=1)

        ttk.Label(editor, text="Component name").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        self.custom_name_var = tk.StringVar()
        ttk.Entry(editor, textvariable=self.custom_name_var).grid(row=0, column=1, sticky="ew", pady=4)
        ttk.Label(editor, text="Official source URL").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        self.custom_url_var = tk.StringVar()
        ttk.Entry(editor, textvariable=self.custom_url_var).grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Label(editor, text="Optional notes / wiring").grid(row=2, column=0, sticky="w", padx=(0, 8), pady=4)
        self.custom_notes_var = tk.StringVar()
        ttk.Entry(editor, textvariable=self.custom_notes_var).grid(row=2, column=1, sticky="ew", pady=4)

        sections = ttk.Notebook(editor)
        sections.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(8, 6))
        self.custom_code_widgets: dict[str, tk.Text] = {}
        section_specs = [
            ("includes", "1. Includes", "#include <SomeSensorLibrary.h>"),
            ("declarations", "2. Globals / functions", "SomeSensor sensor;\nconst int SENSOR_PIN = 2;\n// Add global objects, constants and helper functions here."),
            ("setup_code", "3. setup() body", "sensor.begin();\npinMode(SENSOR_PIN, INPUT);"),
            ("loop_code", "4. loop() body", "int reading = sensor.read();\nSerial.println(reading);"),
        ]
        for key, title, hint in section_specs:
            page = ttk.Frame(sections, padding=6)
            page.rowconfigure(0, weight=1)
            page.columnconfigure(0, weight=1)
            widget = tk.Text(page, wrap="none", font=("Consolas", 10), undo=True, padx=8, pady=8)
            widget.grid(row=0, column=0, sticky="nsew")
            scroll_y = ttk.Scrollbar(page, orient="vertical", command=widget.yview)
            scroll_y.grid(row=0, column=1, sticky="ns")
            widget.configure(yscrollcommand=scroll_y.set)
            # Keep code boxes empty so example identifiers can never leak into a generated sketch.
            self.custom_code_widgets[key] = widget
            sections.add(page, text=title)

        button_row = ttk.Frame(editor)
        button_row.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(4, 0))
        ttk.Button(button_row, text="Import full sketch / README…", command=self.open_integration_import_dialog).pack(side="left")
        ttk.Button(button_row, text="Save to project", style="Primary.TButton", command=self.save_custom_component).pack(side="left", padx=(8, 0))
        ttk.Button(button_row, text="Save to offline library", command=self.save_custom_to_local_library).pack(side="left", padx=8)
        ttk.Button(button_row, text="Load offline component", command=self.load_from_local_library).pack(side="left")
        ttk.Button(button_row, text="Clear editor", command=self.new_custom_component).pack(side="left", padx=8)
        ttk.Label(
            editor,
            text=(
                "Tip: use Import full sketch / README to paste one complete integration. Mixer Code extracts "
                "includes, globals, setup() and loop(), then drops the function wrappers and README prose. "
                "Review the preview and warnings. Custom C++ is not sandboxed or fully pin-validated; only use "
                "code you trust and compile it for your actual board before uploading."
            ),
            style="Sub.TLabel", wraplength=850, justify="left",
        ).grid(row=5, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        self._custom_edit_id: str | None = None

    def _build_library_tab(self):
        self.library_tab.columnconfigure(0, weight=1)
        self.library_tab.rowconfigure(2, weight=1)
        scan = ttk.LabelFrame(self.library_tab, text="Import Arduino code from one documentation URL (online)", padding=10)
        scan.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        scan.columnconfigure(0, weight=1)
        ttk.Label(scan, text="Paste an official documentation page, raw .ino/.cpp file, or GitHub raw URL. The importer scans code blocks for #include, global declarations, setup() and loop(). Review the result before saving.", style="Sub.TLabel", wraplength=1050).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        self.import_url_var = tk.StringVar()
        ttk.Entry(scan, textvariable=self.import_url_var).grid(row=1, column=0, sticky="ew", padx=(0, 8))
        self.scan_url_button = ttk.Button(scan, text="Scan URL", style="Primary.TButton", command=self.scan_documentation)
        self.scan_url_button.grid(row=1, column=1, sticky="e")
        self.import_status_var = tk.StringVar(value="Offline mode: paste code manually in the Custom Components tab. Saved definitions are available locally.")
        ttk.Label(scan, textvariable=self.import_status_var, style="Sub.TLabel", wraplength=1050).grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))

        libs = ttk.LabelFrame(self.library_tab, text="Arduino library dependencies", padding=10)
        libs.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        libs.columnconfigure(1, weight=1)
        ttk.Label(libs, text="Library name").grid(row=0, column=0, sticky="w")
        self.library_name_var = tk.StringVar()
        ttk.Entry(libs, textvariable=self.library_name_var, width=28).grid(row=0, column=1, sticky="ew", padx=5)
        ttk.Label(libs, text="Header include(s)").grid(row=0, column=2, sticky="w")
        self.library_includes_var = tk.StringVar()
        ttk.Entry(libs, textvariable=self.library_includes_var, width=32).grid(row=0, column=3, sticky="ew", padx=5)
        ttk.Label(libs, text="Version").grid(row=1, column=0, sticky="w", pady=(7, 0))
        self.library_version_var = tk.StringVar()
        ttk.Entry(libs, textvariable=self.library_version_var, width=14).grid(row=1, column=1, sticky="w", padx=5, pady=(7, 0))
        ttk.Label(libs, text="Library page URL").grid(row=1, column=2, sticky="w", pady=(7, 0))
        self.library_url_var = tk.StringVar()
        ttk.Entry(libs, textvariable=self.library_url_var).grid(row=1, column=3, sticky="ew", padx=5, pady=(7, 0))
        lib_buttons = ttk.Frame(libs)
        lib_buttons.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        ttk.Button(lib_buttons, text="Add dependency", command=self.add_library_dependency).pack(side="left")
        ttk.Button(lib_buttons, text="Remove selected", command=self.remove_library_dependency).pack(side="left", padx=6)
        ttk.Button(lib_buttons, text="Check Arduino CLI libraries", command=self.check_libraries).pack(side="left", padx=6)
        ttk.Button(lib_buttons, text="Install selected via CLI", command=self.install_selected_library).pack(side="left")

        dep = ttk.LabelFrame(self.library_tab, text="Libraries included by this project", padding=10)
        dep.grid(row=2, column=0, sticky="nsew")
        dep.rowconfigure(0, weight=1)
        dep.columnconfigure(0, weight=1)
        self.library_tree = ttk.Treeview(dep, columns=("includes", "version", "source"), show="tree headings", height=8)
        self.library_tree.heading("#0", text="Library")
        self.library_tree.heading("includes", text="Header")
        self.library_tree.heading("version", text="Version")
        self.library_tree.heading("source", text="Source")
        self.library_tree.column("#0", width=240)
        self.library_tree.column("includes", width=250)
        self.library_tree.column("version", width=100)
        self.library_tree.column("source", width=300)
        self.library_tree.grid(row=0, column=0, sticky="nsew")
        lib_scroll = ttk.Scrollbar(dep, orient="vertical", command=self.library_tree.yview)
        lib_scroll.grid(row=0, column=1, sticky="ns")
        self.library_tree.configure(yscrollcommand=lib_scroll.set)
        ttk.Label(dep, text="Mixer Code adds saved include lines to the sketch. Arduino CLI can install libraries by package name when it is installed and available on PATH. The URL scanner never executes downloaded code.", style="Sub.TLabel", wraplength=1050).grid(row=1, column=0, sticky="w", pady=(8, 0))

    def _build_connectivity_tab(self):
        self.connectivity_tab.columnconfigure(0, weight=1)
        self.connectivity_tab.rowconfigure(2, weight=1)
        intro = ttk.LabelFrame(self.connectivity_tab, text="Add an IoT communication or system profile", padding=10)
        intro.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        intro.columnconfigure(1, weight=1)
        ttk.Label(intro, text="Profile").grid(row=0, column=0, sticky="w")
        self.comm_profile_var = tk.StringVar()
        self.comm_profile_box = ttk.Combobox(intro, textvariable=self.comm_profile_var, state="readonly", width=42)
        self.comm_profile_box.grid(row=0, column=1, sticky="w", padx=8)
        self.comm_profile_box.bind("<<ComboboxSelected>>", self._connectivity_profile_changed)
        self.comm_description_var = tk.StringVar(value="Choose a profile to see its hardware requirements.")
        ttk.Label(intro, textvariable=self.comm_description_var, style="Sub.TLabel", wraplength=1000, justify="left").grid(row=1, column=0, columnspan=3, sticky="w", pady=(8, 8))
        self.comm_fields_frame = ttk.Frame(intro)
        self.comm_fields_frame.grid(row=2, column=0, columnspan=3, sticky="ew")
        self.comm_fields_frame.columnconfigure(1, weight=1)
        button_row = ttk.Frame(intro)
        button_row.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(10, 0))
        ttk.Button(button_row, text="Add connectivity profile", style="Primary.TButton", command=self.add_communication_profile).pack(side="left")
        ttk.Button(button_row, text="Refresh profiles for board", command=self._refresh_connectivity_options).pack(side="left", padx=8)

        active = ttk.LabelFrame(self.connectivity_tab, text="Connectivity and system services in this project", padding=10)
        active.grid(row=2, column=0, sticky="nsew")
        active.rowconfigure(0, weight=1)
        active.columnconfigure(0, weight=1)
        self.comm_tree = ttk.Treeview(active, columns=("category", "details"), show="tree headings", height=10)
        self.comm_tree.heading("#0", text="Profile")
        self.comm_tree.heading("category", text="Category")
        self.comm_tree.heading("details", text="Configuration")
        self.comm_tree.column("#0", width=300)
        self.comm_tree.column("category", width=150)
        self.comm_tree.column("details", width=560)
        self.comm_tree.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(active, orient="vertical", command=self.comm_tree.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.comm_tree.configure(yscrollcommand=scroll.set)
        ttk.Button(active, text="Remove selected profile", command=self.remove_communication_profile).grid(row=1, column=0, sticky="w", pady=(8, 0))

        info = ttk.LabelFrame(self.connectivity_tab, text="Hardware and security notes", padding=10)
        info.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        ttk.Label(info, text=(
            "Uno/Nano: use external HC-05/HC-06, HM-10 or ESP8266 AT modules. ESP32/ESP8266 boards can use native Wi-Fi. "
            "ESP32 Bluetooth Classic SPP is only for SoCs that support Classic Bluetooth; the original ESP32 Dev Module profile is targeted. "
            "Wi-Fi passwords and broker settings are saved in the .iotproj JSON and generated sketch as plain text. Do not commit real credentials to public repositories. "
            "MQTT uses PubSubClient. HTTP polling is a blocking request with a short timeout; avoid very short intervals. TLS/HTTPS certificate validation is not generated by the basic HTTP profile."
        ), style="Sub.TLabel", wraplength=1080, justify="left").pack(anchor="w")
        self._refresh_connectivity_options()

    def _refresh_connectivity_options(self):
        options = profile_options(self.project.board_id)
        self._comm_label_to_type = {label: profile_type for profile_type, label in options}
        labels = [label for _profile_type, label in options]
        self.comm_profile_box.configure(values=labels)
        if labels:
            if self.comm_profile_var.get() not in labels:
                self.comm_profile_var.set(labels[0])
            self._connectivity_profile_changed()
        else:
            self.comm_profile_var.set("")

    def _connectivity_profile_changed(self, _event=None):
        for child in self.comm_fields_frame.winfo_children():
            child.destroy()
        profile_type = self._comm_label_to_type.get(self.comm_profile_var.get())
        if not profile_type:
            return
        spec = PROFILES[profile_type]
        self.comm_description_var.set(spec["description"])
        defaults = profile_defaults(profile_type, self.project.board_id)
        self._comm_field_vars = {}
        for row, (key, field) in enumerate(spec["fields"].items()):
            ttk.Label(self.comm_fields_frame, text=field["label"]).grid(row=row, column=0, sticky="w", pady=3)
            variable = tk.StringVar(value=defaults.get(key, ""))
            show = "*" if field.get("kind") == "password" else ""
            entry = ttk.Entry(self.comm_fields_frame, textvariable=variable, show=show, width=48)
            entry.grid(row=row, column=1, sticky="ew", padx=(10, 0), pady=3)
            if field.get("help"):
                ttk.Label(self.comm_fields_frame, text=field["help"], style="Sub.TLabel").grid(row=row, column=2, sticky="w", padx=8)
            self._comm_field_vars[key] = variable

    def add_communication_profile(self):
        profile_type = self._comm_label_to_type.get(self.comm_profile_var.get())
        if not profile_type:
            messagebox.showinfo("Choose a profile", "Select a connectivity profile first.")
            return
        settings = {key: variable.get().strip() for key, variable in self._comm_field_vars.items()}
        try:
            item = self.project.add_communication(profile_type, settings)
            errors = self.project.validate()
            if errors:
                self.project.remove_communication(item.id)
                self._refresh_library_tree()
                messagebox.showerror("Connectivity profile not added", "Fix these items first:\n\n" + "\n".join(errors))
                return
        except Exception as exc:
            messagebox.showerror("Connectivity profile failed", str(exc))
            return
        self._refresh_connectivity_tree()
        self._refresh_library_tree()
        self.status_var.set(f"Added connectivity profile: {item.name}")

    def remove_communication_profile(self):
        selected = self.comm_tree.selection()
        if not selected:
            messagebox.showinfo("Select a profile", "Select a connectivity profile first.")
            return
        self.project.remove_communication(selected[0])
        self._refresh_connectivity_tree()
        self._refresh_library_tree()
        self.status_var.set("Removed connectivity profile.")

    def _refresh_connectivity_tree(self):
        if not hasattr(self, "comm_tree"):
            return
        self.comm_tree.delete(*self.comm_tree.get_children())
        for item in self.project.communications:
            spec = PROFILES.get(item.profile_type, {})
            summary = ", ".join(f"{key}={value}" for key, value in item.settings.items() if key not in ("password",))
            if any(key == "password" for key in item.settings):
                summary += (", " if summary else "") + "password=••••••••"
            self.comm_tree.insert("", "end", iid=item.id, text=item.name, values=(spec.get("category", "Other"), summary))

    def _build_oled_tab(self):
        """Build the 128x64 SSD1306 screen layout editor and live mock preview."""
        self.oled_tab.columnconfigure(0, weight=1)
        self.oled_tab.columnconfigure(1, weight=1)
        self.oled_tab.rowconfigure(1, weight=1)
        ttk.Label(
            self.oled_tab,
            text=(
                "Design what your SSD1306 OLED shows. Add analog sensors from the project, choose a layout, "
                "and preview a 128x64 screen. Without a saved layout, the generator uses an automatic sensor dashboard."
            ),
            style="Sub.TLabel", wraplength=1050, justify="left",
        ).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 10))

        controls = ttk.LabelFrame(self.oled_tab, text="OLED screen configuration", padding=10)
        controls.grid(row=1, column=0, sticky="nsew", padx=(0, 10))
        controls.columnconfigure(1, weight=1)

        ttk.Label(controls, text="OLED display").grid(row=0, column=0, sticky="w", pady=4)
        self.oled_display_var = tk.StringVar()
        self.oled_display_box = ttk.Combobox(controls, textvariable=self.oled_display_var, state="readonly", width=34)
        self.oled_display_box.grid(row=0, column=1, sticky="ew", padx=(8, 0), pady=4)
        self.oled_display_box.bind("<<ComboboxSelected>>", self._oled_display_changed)

        ttk.Label(controls, text="Screen title (max 20 chars)").grid(row=1, column=0, sticky="w", pady=4)
        self.oled_title_var = tk.StringVar(value="SENSOR DASHBOARD")
        title_entry = ttk.Entry(controls, textvariable=self.oled_title_var)
        title_entry.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=4)
        self.oled_title_var.trace_add("write", lambda *_: self._draw_oled_preview())

        ttk.Label(controls, text="Layout").grid(row=2, column=0, sticky="w", pady=4)
        self.oled_layout_var = tk.StringVar(value="Single value")
        self.oled_layout_box = ttk.Combobox(
            controls, textvariable=self.oled_layout_var, state="readonly", width=34,
            values=("Single value", "Two columns", "List", "Bar graph"),
        )
        self.oled_layout_box.grid(row=2, column=1, sticky="ew", padx=(8, 0), pady=4)
        self.oled_layout_box.bind("<<ComboboxSelected>>", lambda _e: self._draw_oled_preview())

        ttk.Label(controls, text="Refresh interval (ms)").grid(row=3, column=0, sticky="w", pady=4)
        self.oled_refresh_var = tk.StringVar(value="200")
        ttk.Entry(controls, textvariable=self.oled_refresh_var, width=10).grid(row=3, column=1, sticky="w", padx=(8, 0), pady=4)

        sensor_box = ttk.LabelFrame(controls, text="Analog sensor values to display", padding=8)
        sensor_box.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=(12, 0))
        sensor_box.columnconfigure(0, weight=1)
        ttk.Label(sensor_box, text="Available analog sensors").grid(row=0, column=0, sticky="w")
        self.oled_sensor_var = tk.StringVar()
        self.oled_sensor_box = ttk.Combobox(sensor_box, textvariable=self.oled_sensor_var, state="readonly")
        self.oled_sensor_box.grid(row=1, column=0, sticky="ew", pady=(4, 6))
        sensor_buttons = ttk.Frame(sensor_box)
        sensor_buttons.grid(row=1, column=1, padx=(6, 0))
        ttk.Button(sensor_buttons, text="Add", command=self._oled_add_sensor).pack(side="left")
        ttk.Button(sensor_buttons, text="Remove", command=self._oled_remove_sensor).pack(side="left", padx=(5, 0))
        self.oled_sensor_tree = ttk.Treeview(sensor_box, columns=("pin",), show="tree headings", height=6, selectmode="browse")
        self.oled_sensor_tree.heading("#0", text="Selected sensor")
        self.oled_sensor_tree.heading("pin", text="Analog pin")
        self.oled_sensor_tree.column("#0", width=220)
        self.oled_sensor_tree.column("pin", width=90, anchor="center")
        self.oled_sensor_tree.grid(row=2, column=0, columnspan=2, sticky="nsew")
        sensor_box.rowconfigure(2, weight=1)
        ttk.Label(
            sensor_box,
            text="Analog readings are raw ADC values (Uno/Nano: 0-1023; ESP32 profile: board ADC range). Add the sensor in Components first.",
            style="Sub.TLabel", wraplength=470, justify="left",
        ).grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))

        actions = ttk.Frame(controls)
        actions.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Button(actions, text="Save OLED layout to project", style="Primary.TButton", command=self._save_oled_screen).pack(side="left")
        ttk.Button(actions, text="Reset layout", command=self._reset_oled_screen).pack(side="left", padx=8)

        preview_frame = ttk.LabelFrame(self.oled_tab, text="128 x 64 OLED preview", padding=10)
        preview_frame.grid(row=1, column=1, sticky="nsew")
        preview_frame.columnconfigure(0, weight=1)
        self.oled_preview = tk.Canvas(
            preview_frame, width=430, height=230, background="#111827",
            highlightthickness=0,
        )
        self.oled_preview.grid(row=0, column=0, sticky="n", pady=(8, 12))
        self.oled_preview_note = tk.StringVar(value="Preview uses example readings. Generated code reads the real sensors.")
        ttk.Label(preview_frame, textvariable=self.oled_preview_note, style="Sub.TLabel", wraplength=450).grid(row=1, column=0, sticky="ew")
        self._oled_display_map: dict[str, str] = {}
        self._oled_sensor_map: dict[str, str] = {}
        self._draw_oled_preview()

    def _oled_layout_id(self) -> str:
        return {
            "Single value": "single_value",
            "Two columns": "two_column",
            "List": "list",
            "Bar graph": "bar_graph",
        }.get(self.oled_layout_var.get(), "single_value")

    def _oled_layout_label(self, layout_id: str) -> str:
        return {
            "single_value": "Single value",
            "two_column": "Two columns",
            "list": "List",
            "bar_graph": "Bar graph",
        }.get(layout_id, "Single value")

    def _refresh_oled_controls(self, load_selected: bool = False):
        if not hasattr(self, "oled_display_box"):
            return
        displays = [c for c in self.project.components if c.type_id == "ssd1306_oled"]
        self._oled_display_map = {c.name: c.id for c in displays}
        self.oled_display_box["values"] = list(self._oled_display_map)
        if self.oled_display_var.get() not in self._oled_display_map:
            self.oled_display_var.set(next(iter(self._oled_display_map), ""))
            load_selected = True
        sensors = [c for c in self.project.components if COMPONENTS[c.type_id].kind == "analog_input"]
        self._oled_sensor_map = {f"{c.name} ({c.pins.get('signal', '?')})": c.id for c in sensors}
        self.oled_sensor_box["values"] = list(self._oled_sensor_map)
        if self.oled_sensor_var.get() not in self._oled_sensor_map:
            self.oled_sensor_var.set(next(iter(self._oled_sensor_map), ""))
        if load_selected:
            self._load_oled_screen_config()
        else:
            self._refresh_oled_sensor_tree()
            self._draw_oled_preview()

    def _oled_display_changed(self, _event=None):
        self._load_oled_screen_config()

    def _load_oled_screen_config(self):
        display_id = self._oled_display_map.get(self.oled_display_var.get())
        config = self.project.oled_screen(display_id) if display_id else None
        automatic = config is None and display_id is not None
        if automatic:
            config = self.project.default_oled_screen(display_id)
        self.oled_title_var.set(config.title if config else "SENSOR DASHBOARD")
        self.oled_layout_var.set(self._oled_layout_label(config.layout) if config else "Single value")
        self.oled_refresh_var.set(str(config.refresh_ms if config else 200))
        self._refresh_oled_sensor_tree(config.sensor_ids if config else [])
        if automatic and config is not None:
            self.oled_preview_note.set("Automatic default preview. Save a layout to customize it; generated code reads the real sensors.")
        elif config is not None:
            self.oled_preview_note.set("Saved layout preview. Generated code reads the real sensors.")
        self._draw_oled_preview()

    def _refresh_oled_sensor_tree(self, sensor_ids: list[str] | None = None):
        if not hasattr(self, "oled_sensor_tree"):
            return
        for row in self.oled_sensor_tree.get_children():
            self.oled_sensor_tree.delete(row)
        if sensor_ids is None:
            selected = getattr(self, "_oled_selected_sensor_ids", [])
        else:
            selected = list(sensor_ids)
            self._oled_selected_sensor_ids = selected
        for sensor_id in selected:
            sensor = next((c for c in self.project.components if c.id == sensor_id), None)
            if sensor and COMPONENTS[sensor.type_id].kind == "analog_input":
                self.oled_sensor_tree.insert("", "end", iid=sensor.id, text=sensor.name, values=(sensor.pins.get("signal", "?"),))
        self._draw_oled_preview()

    def _oled_add_sensor(self):
        sensor_id = self._oled_sensor_map.get(self.oled_sensor_var.get())
        if not sensor_id:
            messagebox.showinfo("No analog sensor", "Add an analog input sensor in the Components tab first.")
            return
        current = list(getattr(self, "_oled_selected_sensor_ids", []))
        if sensor_id in current:
            return
        max_items = {"single_value": 1, "two_column": 2, "list": 4, "bar_graph": 3}[self._oled_layout_id()]
        if len(current) >= max_items:
            messagebox.showinfo("Layout is full", f"{self.oled_layout_var.get()} supports up to {max_items} sensor(s). Change the layout to show more.")
            return
        current.append(sensor_id)
        self._refresh_oled_sensor_tree(current)

    def _oled_remove_sensor(self):
        selected = self.oled_sensor_tree.selection()
        if not selected:
            return
        remove_id = selected[0]
        current = [item for item in getattr(self, "_oled_selected_sensor_ids", []) if item != remove_id]
        self._refresh_oled_sensor_tree(current)

    def _save_oled_screen(self):
        display_id = self._oled_display_map.get(self.oled_display_var.get())
        if not display_id:
            messagebox.showerror("OLED display required", "Add an SSD1306 OLED in the Components tab first.")
            return
        title = self.oled_title_var.get().strip()
        sensors = list(getattr(self, "_oled_selected_sensor_ids", []))
        try:
            refresh_ms = int(self.oled_refresh_var.get())
        except ValueError:
            messagebox.showerror("Invalid refresh interval", "Enter a whole number from 100 to 5000 milliseconds.")
            return
        layout = self._oled_layout_id()
        sensor_limits = {"single_value": 1, "two_column": 2, "list": 4, "bar_graph": 3}
        if not title or len(title) > 20:
            messagebox.showerror("Invalid screen title", "Enter a title containing 1 to 20 characters.")
            return
        if not 100 <= refresh_ms <= 5000:
            messagebox.showerror("Invalid refresh interval", "Refresh interval must be from 100 to 5000 milliseconds.")
            return
        if not sensors:
            messagebox.showerror("No sensors selected", "Add at least one analog sensor to the OLED screen.")
            return
        if len(sensors) > sensor_limits[layout]:
            messagebox.showerror("Too many sensors", f"{self.oled_layout_var.get()} supports up to {sensor_limits[layout]} sensor(s).")
            return
        analog_ids = {c.id for c in self.project.components if COMPONENTS[c.type_id].kind == "analog_input"}
        if any(sensor_id not in analog_ids for sensor_id in sensors):
            messagebox.showerror("Invalid sensor selection", "Only analog input sensors can be added to this OLED dashboard.")
            return
        self.project.set_oled_screen(display_id, layout, title, sensors, refresh_ms)
        errors = [error for error in self.project.validate() if error.startswith("OLED screen")]
        if errors:
            messagebox.showerror("OLED layout not saved", "\n".join(errors))
            return
        self.status_var.set("OLED layout saved to the project. Generate C++ to update the display code.")
        self.oled_preview_note.set("Saved. The generated sketch uses real analogRead() values at the selected refresh interval.")
        messagebox.showinfo("OLED layout saved", "The OLED layout is saved in this project and will be restored when you reopen it.")

    def _reset_oled_screen(self):
        display_id = self._oled_display_map.get(self.oled_display_var.get())
        if display_id:
            self.project.oled_screens = [screen for screen in self.project.oled_screens if screen.display_id != display_id]
        self._load_oled_screen_config()
        self.status_var.set("Custom OLED layout removed. The automatic sensor dashboard is now the default.")

    def _draw_oled_preview(self):
        if not hasattr(self, "oled_preview"):
            return
        canvas = self.oled_preview
        canvas.delete("all")
        # Display is scaled 3x for editing. This is a visual layout preview,
        # not a font-perfect emulator of the Adafruit_GFX renderer.
        scale, ox, oy = 3, 18, 18
        canvas.create_rectangle(7, 7, 407, 215, fill="#0b1118", outline="#475569", width=2)
        canvas.create_rectangle(ox - 3, oy - 3, ox + 128 * scale + 3, oy + 64 * scale + 3,
                                fill="#06110d", outline="#526b5d", width=2)

        def px(x): return ox + x * scale
        def py(y): return oy + y * scale
        def text_at(x, y, text, size=1):
            font_size = 8 * scale if size == 1 else 16 * scale
            canvas.create_text(px(x), py(y), anchor="nw", text=str(text), fill="#c8ffd7",
                               font=("Consolas", max(8, font_size // 2), "bold" if size > 1 else "normal"))
        def bar_at(y, value):
            canvas.create_rectangle(px(0), py(y), px(128), py(y + 7), outline="#b6e8c6", width=1)
            adc_max = BOARDS[self.project.board_id].adc_max
            width = max(0, min(124, int(124 * value / adc_max)))
            if width:
                canvas.create_rectangle(px(2), py(y + 2), px(2 + width), py(y + 5), fill="#c8ffd7", outline="")

        title = self.oled_title_var.get().strip()[:20] or "SENSOR DASHBOARD"
        text_at(0, 0, title)
        sensor_ids = list(getattr(self, "_oled_selected_sensor_ids", []))
        sensors = [c for c in self.project.components if c.id in sensor_ids and COMPONENTS[c.type_id].kind == "analog_input"]
        sample_values = [512, 768, 256, 900]
        layout = self._oled_layout_id()
        if not sensors:
            text_at(0, 24, "Add an analog sensor")
            text_at(0, 38, "to preview readings")
        elif layout == "single_value":
            sensor = sensors[0]
            text_at(0, 16, sensor.name[:20])
            text_at(0, 29, sample_values[0], size=2)
            bar_at(53, sample_values[0])
        elif layout == "two_column":
            for i, sensor in enumerate(sensors[:2]):
                x = 0 if i == 0 else 66
                text_at(x, 20, sensor.name[:10])
                text_at(x, 36, sample_values[i])
        elif layout == "list":
            for i, sensor in enumerate(sensors[:4]):
                y = 13 + i * 12
                text_at(0, y, sensor.name[:15])
                text_at(98, y, sample_values[i])
        elif layout == "bar_graph":
            for i, sensor in enumerate(sensors[:3]):
                y = 12 + i * 17
                text_at(0, y, sensor.name[:12])
                text_at(100, y, sample_values[i])
                bar_at(y + 8, sample_values[i])
        canvas.create_text(214, 224, anchor="center", text="SAMPLE READINGS  •  128 × 64 px", fill="#94a3b8", font=("Segoe UI", 8))

    def _custom_editor_values(self) -> dict[str, str]:
        return {
            "name": self.custom_name_var.get().strip(),
            "source_url": self.custom_url_var.get().strip(),
            "notes": self.custom_notes_var.get().strip(),
            **{key: widget.get("1.0", "end-1c") for key, widget in self.custom_code_widgets.items()},
        }

    def _set_custom_editor_values(self, item: CustomCodeComponent | None = None):
        self.custom_name_var.set(item.name if item else "")
        self.custom_url_var.set(item.source_url if item else "")
        self.custom_notes_var.set(item.notes if item else "")
        for key, widget in self.custom_code_widgets.items():
            widget.delete("1.0", tk.END)
            value = getattr(item, key, "") if item else ""
            widget.insert("1.0", value)
        self._custom_edit_id = item.id if item else None

    def new_custom_component(self):
        self.custom_tree.selection_remove(self.custom_tree.selection())
        self._set_custom_editor_values(None)
        self.status_var.set("Ready to add an unlisted component using copied documentation code.")

    def load_custom_component(self, _event=None):
        selected = self.custom_tree.selection()
        if not selected:
            return
        component_id = selected[0]
        item = next((x for x in self.project.custom_components if x.id == component_id), None)
        if item:
            self._set_custom_editor_values(item)

    def _refresh_custom_tree(self):
        for row in self.custom_tree.get_children():
            self.custom_tree.delete(row)
        for item in self.project.custom_components:
            source_label = "Official URL" if item.source_url else "Not set"
            self.custom_tree.insert("", "end", iid=item.id, text=item.name, values=(source_label,))

    def open_integration_import_dialog(self):
        """Open a two-stage dialog that extracts one complete pasted integration."""
        window = tk.Toplevel(self.root)
        window.title("Import one complete Arduino integration")
        window.geometry("1080x800")
        window.minsize(850, 620)
        window.transient(self.root)
        window.grab_set()
        window.columnconfigure(0, weight=1)
        window.rowconfigure(1, weight=3)
        window.rowconfigure(3, weight=2)

        ttk.Label(
            window,
            text=(
                "Paste a complete .ino sketch, GitHub README, or documentation text. "
                "The importer keeps one main sketch and separates its includes, globals, setup() and loop()."
            ),
            style="Sub.TLabel", wraplength=1020, justify="left",
        ).grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 6))

        source_frame = ttk.LabelFrame(window, text="Complete integration input", padding=8)
        source_frame.grid(row=1, column=0, sticky="nsew", padx=12, pady=6)
        source_frame.rowconfigure(0, weight=1)
        source_frame.columnconfigure(0, weight=1)
        source_text = tk.Text(source_frame, wrap="none", font=("Consolas", 9), undo=True, padx=8, pady=8)
        source_text.grid(row=0, column=0, sticky="nsew")
        source_y = ttk.Scrollbar(source_frame, orient="vertical", command=source_text.yview)
        source_y.grid(row=0, column=1, sticky="ns")
        source_x = ttk.Scrollbar(source_frame, orient="horizontal", command=source_text.xview)
        source_x.grid(row=1, column=0, sticky="ew")
        source_text.configure(yscrollcommand=source_y.set, xscrollcommand=source_x.set)

        name_row = ttk.Frame(window, padding=(12, 2))
        name_row.grid(row=2, column=0, sticky="ew")
        name_row.columnconfigure(1, weight=1)
        ttk.Label(name_row, text="Component name (auto-detected):").grid(row=0, column=0, sticky="w")
        name_var = tk.StringVar()
        ttk.Entry(name_row, textvariable=name_var).grid(row=0, column=1, sticky="ew", padx=(8, 0))

        preview_frame = ttk.LabelFrame(window, text="Extraction preview", padding=8)
        preview_frame.grid(row=3, column=0, sticky="nsew", padx=12, pady=6)
        preview_frame.rowconfigure(0, weight=1)
        preview_frame.columnconfigure(0, weight=1)
        preview_text = tk.Text(preview_frame, wrap="none", font=("Consolas", 9), height=12, padx=8, pady=8, state="disabled")
        preview_text.grid(row=0, column=0, sticky="nsew")
        preview_y = ttk.Scrollbar(preview_frame, orient="vertical", command=preview_text.yview)
        preview_y.grid(row=0, column=1, sticky="ns")
        preview_text.configure(yscrollcommand=preview_y.set)
        status_var = tk.StringVar(value="Paste the complete integration, then choose Analyze.")
        ttk.Label(window, textvariable=status_var, style="Sub.TLabel", wraplength=1020).grid(row=4, column=0, sticky="ew", padx=12, pady=(2, 6))

        state: dict[str, IntegrationExtraction | None] = {"result": None}

        def show_preview(result: IntegrationExtraction):
            review_lines = [f"WARNING: {warning}" for warning in result.warnings] if result.warnings else ["No importer warnings."]
            sections = [
                f"Detected component: {result.title}",
                f"Distinct code candidates: {result.candidate_count}",
                "",
                "========== INCLUDES ==========",
                result.includes or "(none detected)",
                "",
                "========== GLOBALS / FUNCTIONS ==========",
                result.declarations or "(none detected)",
                "",
                "========== SETUP BODY ==========",
                result.setup_code or "(none detected)",
                "",
                "========== LOOP BODY ==========",
                result.loop_code or "(none detected)",
                "",
                "========== REVIEW NOTES ==========",
            ] + review_lines
            preview_text.configure(state="normal")
            preview_text.delete("1.0", tk.END)
            preview_text.insert("1.0", "\n".join(sections))
            preview_text.configure(state="disabled")

        def analyze():
            raw = source_text.get("1.0", "end-1c")
            try:
                result = extract_integration_document(raw)
            except Exception as exc:
                state["result"] = None
                use_button.configure(state="disabled")
                status_var.set(f"Could not extract integration: {exc}")
                messagebox.showerror("Integration extraction failed", str(exc), parent=window)
                return
            state["result"] = result
            if not name_var.get().strip():
                name_var.set(result.title)
            show_preview(result)
            status_var.set(
                f"Extracted {len(result.includes.splitlines())} include(s), "
                f"{len(result.declarations.splitlines())} global/helper line(s), "
                f"{len(result.setup_code.splitlines())} setup line(s), "
                f"{len(result.loop_code.splitlines())} loop line(s). Review the preview before loading."
            )
            use_button.configure(state="normal")

        def use_extracted():
            result = state.get("result")
            if result is None:
                return
            chosen_name = name_var.get().strip() or result.title
            self.custom_tree.selection_remove(self.custom_tree.selection())
            self._set_custom_editor_values(None)
            self.custom_name_var.set(chosen_name)
            self.custom_url_var.set(result.source_url)
            note_lines = ["Imported from one complete integration document. README prose and duplicate code blocks were excluded."]
            note_lines.extend(f"Review: {warning}" for warning in result.warnings)
            self.custom_notes_var.set("\n".join(note_lines))
            for key in ("includes", "declarations", "setup_code", "loop_code"):
                widget = self.custom_code_widgets[key]
                widget.delete("1.0", tk.END)
                widget.insert("1.0", getattr(result, key))
            added = self._suggest_libraries_from_includes(result.includes, result.source_url)
            self._refresh_library_tree()
            self.notebook.select(self.custom_tab)
            self.status_var.set(
                f"Extracted {chosen_name}: includes, globals, setup() and loop() loaded for review. "
                f"Added {added} suggested library entr(y/ies). Click Save to project when ready."
            )
            window.destroy()

        buttons = ttk.Frame(window, padding=(12, 6, 12, 12))
        buttons.grid(row=5, column=0, sticky="ew")
        ttk.Button(buttons, text="Analyze complete code", style="Primary.TButton", command=analyze).pack(side="left")
        use_button = ttk.Button(buttons, text="Use extracted sections", command=use_extracted, state="disabled")
        use_button.pack(side="left", padx=8)
        ttk.Button(buttons, text="Cancel", command=window.destroy).pack(side="right")

    def _suggest_libraries_from_includes(self, includes_text: str, source_url: str = "") -> int:
        """Add editable dependency suggestions for non-core headers."""
        core_headers = {
            "Arduino.h", "Wire.h", "SPI.h", "Servo.h", "EEPROM.h", "SoftwareSerial.h",
            "HardwareSerial.h", "SD.h", "WiFi.h", "ESP8266WiFi.h", "WiFiClient.h",
            "WiFiUdp.h", "math.h", "stdint.h", "string.h",
        }
        added = 0
        for include in includes_text.splitlines():
            include = include.strip()
            if not include.startswith("#include"):
                continue
            header_match = re.search(r'[<\"]([^>\"]+)[>\"]', include)
            if not header_match:
                continue
            header = header_match.group(1)
            if Path(header).name in core_headers:
                continue
            if not any(item.includes.strip() == include for item in self.project.libraries):
                lib_name = Path(header).stem
                self.project.add_library(
                    lib_name, include, source_url=source_url,
                    notes="Suggested from an include header. Arduino Library Manager package name may differ; verify before installing.",
                )
                added += 1
        return added

    def save_custom_component(self):
        values = self._custom_editor_values()
        if not values["name"]:
            messagebox.showerror("Missing component name", "Enter a name for this custom component.")
            return
        source_url = values["source_url"]
        if source_url and not source_url.lower().startswith(("https://", "http://")):
            messagebox.showerror("Invalid source URL", "Use a complete http:// or https:// URL, or leave the source URL empty.")
            return
        suspicious_wrappers = []
        for key in ("declarations", "setup_code", "loop_code"):
            text = values[key]
            if "void setup(" in text or "void loop(" in text:
                suspicious_wrappers.append(key)
        if suspicious_wrappers:
            proceed = messagebox.askyesno(
                "Complete sketch wrapper detected",
                "Your pasted code appears to contain void setup() or void loop(). The generator already creates "
                "these functions. Paste only the code inside those functions to avoid duplicate definitions.\n\n"
                "Save anyway?",
            )
            if not proceed:
                return
        if self._custom_edit_id:
            item = next((x for x in self.project.custom_components if x.id == self._custom_edit_id), None)
            if item is None:
                self._custom_edit_id = None
            else:
                for key, value in values.items():
                    setattr(item, key, value)
                saved = item
        if not self._custom_edit_id:
            saved = self.project.add_custom_component(**values)
            self._custom_edit_id = saved.id
        self._refresh_custom_tree()
        self.custom_tree.selection_set(saved.id)
        self.custom_tree.focus(saved.id)
        self.status_var.set(f"Saved custom component: {saved.name}. Generate C++ to insert its code.")

    def save_custom_to_local_library(self):
        values = self._custom_editor_values()
        if not values["name"]:
            messagebox.showerror("Missing component name", "Enter a name for this custom component.")
            return
        from .model import CustomCodeComponent
        existing = next((x for x in self.project.custom_components if x.id == self._custom_edit_id), None) if self._custom_edit_id else None
        item_id = existing.id if existing else re.sub(r"[^a-z0-9]+", "_", values["name"].lower()).strip("_") or "custom_component"
        item = CustomCodeComponent(id=item_id, **values)
        try:
            path = save_custom_definition(item)
        except OSError as exc:
            messagebox.showerror("Offline library save failed", str(exc))
            return
        messagebox.showinfo("Saved offline component", f"Saved {item.name} to your local custom component library:\n{path}\n\nIt is stored separately from the current project and can be loaded while offline.")
        self.status_var.set(f"Saved {item.name} to offline library.")

    def load_from_local_library(self):
        items = load_custom_definitions()
        if not items:
            messagebox.showinfo("Offline library is empty", f"No saved definitions yet.\n\nFolder: {custom_library_dir()}")
            return
        choices = [f"{item.name}  [{item.id}]" for item in items]
        chosen = simpledialog.askstring("Load offline component", "Enter a component name or ID:\n\n" + "\n".join(choices), parent=self.root)
        if not chosen:
            return
        key = chosen.strip().casefold()
        item = next((x for x in items if x.name.casefold() == key or x.id.casefold() == key), None)
        if not item:
            messagebox.showerror("Not found", "No saved custom component matched that name or ID.")
            return
        self._set_custom_editor_values(item)
        self.notebook.select(self.custom_tab)
        self.status_var.set(f"Loaded {item.name} from offline custom library. Save to project to include it in this project.")

    def remove_custom_component(self):
        selected = self.custom_tree.selection()
        component_id = selected[0] if selected else self._custom_edit_id
        if not component_id:
            messagebox.showinfo("Select custom component", "Select a custom component to remove.")
            return
        item = next((x for x in self.project.custom_components if x.id == component_id), None)
        if item is None:
            return
        if not messagebox.askyesno("Remove custom component", f"Remove {item.name} and its pasted code from this project?"):
            return
        self.project.remove_custom_component(component_id)
        self._refresh_custom_tree()
        self._set_custom_editor_values(None)
        self.status_var.set(f"Removed custom component: {item.name}.")

    def _refresh_task_component_choices(self, _event=None):
        task_type = self.task_type_var.get() if hasattr(self, "task_type_var") else "Servo sweep"
        wanted = "servo_output" if task_type == "Servo sweep" else "distance_input"
        components = [c for c in self.project.components if COMPONENTS[c.type_id].kind == wanted]
        self._task_component_map = {c.name: c.id for c in components}
        if hasattr(self, "task_component_box"):
            self.task_component_box["values"] = list(self._task_component_map)
            if self.task_component_var.get() not in self._task_component_map:
                self.task_component_var.set(next(iter(self._task_component_map), ""))
        if hasattr(self, "task_interval_var"):
            if task_type == "Continuous ultrasonic monitor":
                self.task_interval_var.set("60")
            else:
                self.task_interval_var.set("20")

    def add_independent_task(self):
        component_id = self._task_component_map.get(self.task_component_var.get())
        if not component_id:
            messagebox.showerror("No compatible component", "Add a servo motor or HC-SR04 ultrasonic sensor to the Components tab first.")
            return
        try:
            interval = int(self.task_interval_var.get())
            if self.task_type_var.get() == "Servo sweep":
                self.project.add_task("servo_sweep", component_id, interval,
                                      int(self.task_start_var.get()), int(self.task_end_var.get()), int(self.task_step_var.get()))
            else:
                self.project.add_task("ultrasonic_monitor", component_id, interval)
        except (ValueError, KeyError) as exc:
            messagebox.showerror("Invalid task", str(exc))
            return
        errors = self.project.validate()
        task_errors = [e for e in errors if e.startswith("Independent task")]
        if task_errors:
            self.project.tasks.pop()
            messagebox.showerror("Task configuration invalid", "\n".join(task_errors))
            return
        self._refresh_task_tree()
        self.status_var.set("Added independent task. It will run without waiting for a WHEN/THEN rule.")

    def remove_independent_task(self):
        selected = self.task_tree.selection()
        if not selected:
            return
        self.project.remove_task(selected[0])
        self._refresh_task_tree()
        self.status_var.set("Removed independent task.")

    def _refresh_task_tree(self):
        if not hasattr(self, "task_tree"):
            return
        for row in self.task_tree.get_children():
            self.task_tree.delete(row)
        for task in self.project.tasks:
            component = next((c for c in self.project.components if c.id == task.component_id), None)
            component_name = component.name if component else task.component_id
            title = "Servo sweep" if task.task_type == "servo_sweep" else "Continuous ultrasonic monitor"
            config = f"{task.start_angle}° ↔ {task.end_angle}°, step {task.step_degrees}°" if task.task_type == "servo_sweep" else "Non-blocking echo polling + Serial output"
            self.task_tree.insert("", "end", iid=task.id, text=task.name, values=(title, component_name, f"{task.interval_ms} ms", config))
        self._refresh_task_component_choices()

    def _refresh_library_tree(self):
        if not hasattr(self, "library_tree"):
            return
        for row in self.library_tree.get_children():
            self.library_tree.delete(row)
        for item in self.project.libraries:
            source = item.source_url or "Manual"
            self.library_tree.insert("", "end", iid=item.id, text=item.name, values=(item.includes, item.version, source))

    def add_library_dependency(self, name=None, includes=None, version=None, source_url=None, notes=""):
        name = name if name is not None else self.library_name_var.get().strip()
        includes = includes if includes is not None else self.library_includes_var.get().strip()
        version = version if version is not None else self.library_version_var.get().strip()
        source_url = source_url if source_url is not None else self.library_url_var.get().strip()
        try:
            self.project.add_library(name, includes, version, source_url, notes)
        except ValueError as exc:
            messagebox.showerror("Library not added", str(exc))
            return
        if hasattr(self, "library_name_var"):
            self.library_name_var.set(""); self.library_includes_var.set(""); self.library_version_var.set(""); self.library_url_var.set("")
        self._refresh_library_tree()
        self.status_var.set(f"Added library dependency: {name}.")

    def remove_library_dependency(self):
        selected = self.library_tree.selection()
        if not selected:
            return
        item = next((library for library in self.project.libraries if library.id == selected[0]), None)
        if item and item.name.casefold() in self.project.required_builtin_library_names():
            messagebox.showerror(
                "Required library",
                f"{item.name} is required by a built-in component in this project. Remove that component first if you no longer need the library.",
            )
            return
        self.project.remove_library(selected[0])
        self._refresh_library_tree()
        self.status_var.set("Removed library dependency from this project.")

    def check_libraries(self):
        try:
            output = list_installed_libraries()
        except Exception as exc:
            messagebox.showerror("Arduino CLI library check", str(exc))
            return
        messagebox.showinfo("Arduino CLI installed libraries", output[:12000])

    def install_selected_library(self):
        selected = self.library_tree.selection()
        if not selected:
            messagebox.showinfo("Select a library", "Select a library dependency first.")
            return
        item = next((x for x in self.project.libraries if x.id == selected[0]), None)
        if not item:
            return
        if not messagebox.askyesno("Install Arduino library", f"Install '{item.name}' using Arduino CLI?\n\nThis downloads code from the configured Arduino Library Manager index."):
            return
        try:
            output = install_library(item.name, item.version)
        except Exception as exc:
            messagebox.showerror("Library installation failed", str(exc))
            return
        messagebox.showinfo("Library installation", output[:12000])

    def scan_documentation(self):
        url = self.import_url_var.get().strip()
        if not url:
            messagebox.showinfo("URL required", "Paste one documentation URL first.")
            return
        self.scan_url_button.configure(state="disabled")
        self.import_status_var.set("Downloading and scanning the single supplied URL…")
        def worker():
            try:
                result = scan_documentation_url(url)
                self.root.after(0, lambda: self._documentation_scan_complete(result=result))
            except Exception as exc:
                self.root.after(0, lambda: self._documentation_scan_complete(error=str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def _documentation_scan_complete(self, result=None, error=None):
        self.scan_url_button.configure(state="normal")
        if error:
            self.import_status_var.set(f"Scan failed: {error}")
            messagebox.showerror("Documentation import failed", error)
            return
        self.custom_name_var.set(str(result.get("title") or "Imported Arduino Component"))
        self.custom_url_var.set(str(result.get("source_url") or self.import_url_var.get()))
        import_notes = ["Imported from a URL. Review pin definitions, library versions and licensing before use."]
        import_notes.extend(f"Review: {warning}" for warning in result.get("warnings", []))
        self.custom_notes_var.set("\n".join(import_notes))
        for key in ("includes", "declarations", "setup_code", "loop_code"):
            widget = self.custom_code_widgets[key]
            widget.delete("1.0", tk.END)
            widget.insert("1.0", str(result.get(key, "")))
        includes_text = str(result.get("includes", ""))
        includes = [line.strip() for line in includes_text.splitlines() if line.strip().startswith("#include")]
        added = self._suggest_libraries_from_includes(includes_text, str(result.get("source_url", "")))
        self._refresh_library_tree()
        self.notebook.select(self.custom_tab)
        count = int(result.get("snippet_count", 0))
        self.import_status_var.set(f"Found {count} C++ code block(s), {len(includes)} include(s). Snippets loaded into Custom Components for review.")
        messagebox.showinfo("Documentation scan complete", f"Found {count} C++ code block(s).\nIncludes: {len(includes)}\nLibrary entries added: {added}.\n\nReview the imported code and verify the exact library package names before compiling.")

    def _categories(self):
        cats = sorted({spec.category for spec in COMPONENTS.values()})
        return ["All supported", *cats]

    def _refresh_catalog(self):
        self.catalog_list.delete(0, tk.END)
        category = self.category_var.get()
        for type_id, spec in COMPONENTS.items():
            if category == "All supported" or category == spec.category:
                self.catalog_list.insert(tk.END, spec.display_name)
        self._show_component_description()

    def _selected_type_id(self):
        selection = self.catalog_list.curselection()
        if not selection:
            return None
        category = self.category_var.get()
        visible = [s for s in COMPONENTS.values() if category == "All supported" or category == s.category]
        if selection[0] >= len(visible):
            return None
        return visible[selection[0]].type_id

    def _show_component_description(self, _event=None):
        type_id = self._selected_type_id()
        if not type_id:
            self.catalog_description.set("Select a component to see what it does.")
            return
        spec = COMPONENTS[type_id]
        self.catalog_description.set(f"{spec.display_name}\n{spec.description}\n\nCategory: {spec.category}")

    def _sync_project_name(self):
        self.project.name = self.project_name_var.get().strip() or "My IoT Project"

    def _board_changed(self, _event=None):
        display = self.board_var.get()
        for board_id, board in BOARDS.items():
            if board.display_name == display:
                self.project.board_id = board_id
                self.project.ensure_builtin_dependencies()
                self.board_note.configure(text=board.notes)
                break
        self._refresh_all()
        self.status_var.set("Board changed. Check pin assignments and validate the project.")

    def _used_pins(self):
        used = {pin.upper() for component in self.project.components for pin in component.pins.values()}
        if any(COMPONENTS[c.type_id].kind == "display_output" for c in self.project.components):
            used.update({"A4", "A5"} if self.project.board_id in ("uno", "nano") else {"21", "22"})
        return used

    def add_component(self):
        type_id = self._selected_type_id()
        if not type_id:
            messagebox.showinfo("Select a component", "Choose a supported component from the library first.")
            return
        spec = COMPONENTS[type_id]
        board = BOARDS[self.project.board_id]
        used = self._used_pins()
        pins = {}
        try:
            for pin_role in spec.pins:
                if spec.kind == "digital_input":
                    role = "input"
                elif spec.kind == "analog_input":
                    role = "analog"
                elif spec.kind == "digital_output":
                    role = "output"
                elif spec.kind == "servo_output":
                    role = "servo"
                elif spec.kind == "distance_input":
                    role = "output" if pin_role == "trig" else "input"
                elif spec.kind == "display_output":
                    continue  # I2C display uses the board's shared SDA/SCL bus.
                else:
                    raise PinError("This component has no pin allocator.")
                pin = allocate_pin(board, role, used)
                pins[pin_role] = pin
                used.add(pin.upper())
        except PinError as exc:
            messagebox.showerror("Cannot add component", str(exc))
            return
        existing_count = sum(1 for c in self.project.components if c.type_id == type_id)
        name = f"{spec.display_name} {existing_count + 1}"
        settings = None
        if spec.kind == "display_output":
            i2c_pins = {"A4", "A5"} if self.project.board_id in ("uno", "nano") else {"21", "22"}
            conflicts = [f"{component.name} uses {pin}" for component in self.project.components for pin in component.pins.values() if pin.upper() in i2c_pins]
            if conflicts:
                messagebox.showerror("I2C pins are already in use", "Move these component pins before adding an I2C display:\n" + "\n".join(conflicts))
                return
            used_addresses = {str(c.settings.get("address", "")).upper() for c in self.project.components if COMPONENTS[c.type_id].kind == "display_output"}
            candidates = ("0x3C", "0x3D") if type_id == "ssd1306_oled" else ("0x27", "0x3F")
            default_address = next((value for value in candidates if value.upper() not in used_addresses), candidates[0])
            address = simpledialog.askstring("I2C display address", f"Enter the I2C address for {spec.display_name}:", initialvalue=default_address, parent=self.root)
            if address is None:
                return
            if address.strip().upper() in used_addresses:
                messagebox.showerror("I2C address already used", "Each device on the same I2C bus needs a unique address.")
                return
            settings = {"address": address.strip()}
        component = self.project.add_component(type_id, name, pins, settings=settings)
        self._refresh_all()
        pin_summary = ", ".join(f"{k}={v}" for k, v in pins.items()) or "shared I2C bus (board defaults)"
        self.status_var.set(f"Added {component.name}. Pins: {pin_summary}")

    def remove_component(self):
        selected = self.component_tree.selection()
        if not selected:
            return
        component_id = selected[0]
        component = self.project.component(component_id)
        if not messagebox.askyesno("Remove component", f"Remove {component.name} and any rules that use it?"):
            return
        self.project.remove_component(component_id)
        self._refresh_all()
        self.status_var.set(f"Removed {component.name}.")

    def edit_selected_pins(self):
        selected = self.component_tree.selection()
        if not selected:
            messagebox.showinfo("Select component", "Select a component whose pin mapping you want to edit.")
            return
        component = self.project.component(selected[0])
        spec = COMPONENTS[component.type_id]
        if spec.kind == "display_output":
            messagebox.showinfo("I2C display", "This display uses the shared I2C SDA/SCL bus. Change its I2C address in the saved project settings if needed.")
            return
        board = BOARDS[self.project.board_id]
        used_elsewhere = {
            pin.upper()
            for item in self.project.components if item.id != component.id
            for pin in item.pins.values()
        }
        if any(COMPONENTS[item.type_id].kind == "display_output" for item in self.project.components if item.id != component.id):
            used_elsewhere.update({"A4", "A5"} if self.project.board_id in ("uno", "nano") else {"21", "22"})
        proposed = {}
        for pin_role, old_pin in component.pins.items():
            value = simpledialog.askstring(
                "Edit pin assignment",
                f"Enter the {pin_role.upper()} pin for {component.name} on {board.display_name}:\nCurrent: {old_pin}",
                initialvalue=old_pin,
                parent=self.root,
            )
            if value is None:
                return
            value = value.strip().upper()
            if spec.kind == "digital_input":
                role = "input"
            elif spec.kind == "analog_input":
                role = "analog"
            elif spec.kind == "digital_output":
                role = "output"
            elif spec.kind == "servo_output":
                role = "servo"
            else:
                role = "output" if pin_role == "trig" else "input"
            try:
                validate_pin(board, value, role)
            except PinError as exc:
                messagebox.showerror("Invalid pin", str(exc))
                return
            if value in used_elsewhere or value in {v.upper() for v in proposed.values()}:
                messagebox.showerror("Pin conflict", f"Pin {value} is already assigned to another component or another pin on this component.")
                return
            proposed[pin_role] = value
        component.pins = proposed
        self._refresh_all()
        self.status_var.set(f"Updated pin mapping for {component.name}.")

    def change_active_level(self):
        selected = self.component_tree.selection()
        if not selected:
            messagebox.showinfo("Select input", "Select a digital input component first.")
            return
        component = self.project.component(selected[0])
        kind = COMPONENTS[component.type_id].kind
        if kind not in ("digital_input", "digital_output"):
            messagebox.showinfo("Polarity not applicable", "Polarity applies to digital inputs and digital outputs, not servo motors.")
            return
        new_level = "LOW" if component.active_level == "HIGH" else "HIGH"
        component.active_level = new_level
        self._refresh_all()
        if kind == "digital_input":
            message = f"{component.name} is now active when its input pin reads {new_level}."
        else:
            message = f"{component.name} now uses {new_level} as its active output level."
        self.status_var.set(message)

    def _refresh_component_tree(self):
        for item in self.component_tree.get_children():
            self.component_tree.delete(item)
        for c in self.project.components:
            pins = ", ".join(f"{key}: {value}" for key, value in c.pins.items())
            if COMPONENTS[c.type_id].kind == "display_output":
                pins = f"I2C address {c.settings.get('address', '0x3C' if c.type_id == 'ssd1306_oled' else '0x27')}"
            active = c.active_level if COMPONENTS[c.type_id].kind in ("digital_input", "digital_output") else "-"
            self.component_tree.insert("", "end", iid=c.id, values=(c.name, pins, active))

    def _refresh_logic_controls(self):
        inputs = [c for c in self.project.components if COMPONENTS[c.type_id].kind in ("digital_input", "analog_input", "distance_input")]
        outputs = [c for c in self.project.components if COMPONENTS[c.type_id].kind in ("digital_output", "servo_output")]
        self._source_map = {c.name: c.id for c in inputs}
        self._target_map = {c.name: c.id for c in outputs}
        self.source_box["values"] = list(self._source_map)
        self.target_box["values"] = list(self._target_map)
        if self.source_var.get() not in self._source_map:
            self.source_var.set(next(iter(self._source_map), ""))
        if self.target_var.get() not in self._target_map:
            self.target_var.set(next(iter(self._target_map), ""))
        self._update_conditions()
        self._update_actions()
        for item in self.rule_tree.get_children():
            self.rule_tree.delete(item)
        for i, rule in enumerate(self.project.rules):
            src, dst = self.project.component(rule.sensor_id), self.project.component(rule.target_id)
            condition = f"{src.name} {rule.condition.replace('_', ' ')}" + (f" {rule.threshold}" if rule.threshold is not None else "")
            action = f"{dst.name} {rule.action}" + (f" {rule.angle}°" if rule.angle is not None else "")
            self.rule_tree.insert("", "end", iid=str(i), values=(condition, action))

    def _update_conditions(self, _event=None):
        source_name = self.source_var.get()
        source_id = getattr(self, "_source_map", {}).get(source_name)
        if not source_id:
            self.condition_box["values"] = ("TRUE", "FALSE", "DETECTED", "NOT_DETECTED")
            self.condition_var.set("TRUE")
            self.threshold_entry.configure(state="disabled")
            return
        kind = COMPONENTS[self.project.component(source_id).type_id].kind
        if kind == "digital_input":
            values = ("TRUE", "FALSE", "DETECTED", "NOT_DETECTED")
        elif kind == "distance_input":
            values = ("DETECTED", "NOT_DETECTED", "BELOW", "ABOVE")
        else:
            values = ("ABOVE", "BELOW")
        self.condition_box["values"] = values
        if self.condition_var.get() not in values:
            self.condition_var.set(values[0])
        needs_threshold = kind in ("analog_input", "distance_input") and self.condition_var.get() in ("ABOVE", "BELOW")
        self.threshold_entry.configure(state="normal" if needs_threshold else "disabled")

    def _update_actions(self):
        target_name = self.target_var.get()
        target_id = getattr(self, "_target_map", {}).get(target_name)
        if not target_id:
            return
        kind = COMPONENTS[self.project.component(target_id).type_id].kind
        values = ("SET ANGLE",) if kind == "servo_output" else ("GLOW", "ON", "OFF", "BEEP", "SILENCE", "ACTIVATE", "DEACTIVATE")
        self.action_box["values"] = values
        if self.action_var.get() not in values:
            self.action_var.set(values[0])
        self.angle_entry.configure(state="normal" if kind == "servo_output" else "disabled")

    def _new_rule_validation_errors(self, candidate, rule):
        """Return validation issues caused by adding this rule.

        In addition to normal rule errors, block a rule that conflicts with a
        sensor explicitly configured for continuous-only monitoring. Other
        pre-existing project issues are left for the project validator.
        """
        errors = candidate.validate()
        rule_prefix = f"Rule {len(candidate.rules)}:"
        sensor_name = candidate.component(rule.sensor_id).name
        monitor_prefix = f"Sensor monitor {sensor_name}: continuous-only mode"
        return [e for e in errors if e.startswith(rule_prefix) or e.startswith(monitor_prefix)]

    def add_structured_rule(self):
        self._update_actions()
        source_id = self._source_map.get(self.source_var.get())
        target_id = self._target_map.get(self.target_var.get())
        if not source_id or not target_id:
            messagebox.showerror("Missing components", "Add at least one supported input and one output component first.")
            return
        condition = self.condition_var.get()
        source_kind = COMPONENTS[self.project.component(source_id).type_id].kind
        threshold = None
        if condition in ("ABOVE", "BELOW") and source_kind in ("analog_input", "distance_input"):
            try:
                threshold = int(self.threshold_var.get())
            except ValueError:
                messagebox.showerror("Invalid threshold", "Enter a whole-number threshold.")
                return
        action = self.action_var.get().replace(" ", "_")
        angle = None
        if action == "SET_ANGLE":
            try:
                angle = int(self.angle_var.get())
            except ValueError:
                messagebox.showerror("Invalid angle", "Enter a whole-number servo angle between 0 and 180.")
                return
        rule = Rule(source_id, condition, threshold, target_id, action, angle)
        candidate = Project.from_dict(self.project.to_dict())
        candidate.add_rule(rule)
        rule_errors = self._new_rule_validation_errors(candidate, rule)
        if rule_errors:
            messagebox.showerror("Rule is not valid", "\n".join(rule_errors))
            return
        self.project.add_rule(rule)
        self._refresh_logic_controls()
        self.status_var.set("Added logic rule.")

    def add_instruction(self):
        self._sync_project_name()
        try:
            rule = parse_instruction(self.command_var.get(), self.project)
        except InstructionError as exc:
            messagebox.showerror("Could not parse instruction", str(exc))
            return
        candidate = Project.from_dict(self.project.to_dict())
        candidate.add_rule(rule)
        errors = self._new_rule_validation_errors(candidate, rule)
        if errors:
            messagebox.showerror("Rule is not valid", "\n".join(errors))
            return
        self.project.add_rule(rule)
        self.command_var.set("")
        self._refresh_logic_controls()
        self.status_var.set("Parsed the instruction and added a rule.")

    def remove_rule(self):
        selected = self.rule_tree.selection()
        if not selected:
            return
        index = int(selected[0])
        del self.project.rules[index]
        self._refresh_logic_controls()
        self.status_var.set("Removed selected rule.")

    def _refresh_all(self):
        # Populate the component picker on first launch and after project resets.
        self._refresh_catalog()
        self._refresh_component_tree()
        self._refresh_logic_controls()
        self._refresh_custom_tree()
        self._refresh_task_tree()
        self._refresh_library_tree()
        self._refresh_oled_controls(load_selected=True)
        self._refresh_connectivity_options()
        self._refresh_connectivity_tree()
        self._refresh_sensor_monitor_controls()
        if self.code_text is not None:
            # Do not erase a code preview just because the board selection changed.
            pass

    def validate_project(self):
        self._sync_project_name()
        errors = self.project.validate()
        if errors:
            messagebox.showerror("Project validation", "The project has issues:\n\n" + "\n".join(f"• {e}" for e in errors))
            self.status_var.set(f"Validation found {len(errors)} issue(s).")
        else:
            messagebox.showinfo(
                "Project validation",
                "Built-in project structure, pin assignments and logic rules are valid.\n\n"
                "Custom pasted C++ is not compiled or pin-checked here. Compile the generated sketch "
                "with the Arduino IDE or Arduino CLI before uploading it."
            )
            self.status_var.set("Built-in project validation passed. Review custom code separately.")

    def generate_code(self):
        self._sync_project_name()
        try:
            code = generate_cpp(self.project)
        except ValueError as exc:
            messagebox.showerror("Cannot generate code", str(exc))
            return
        self.code_text.delete("1.0", tk.END)
        self.code_text.insert("1.0", code)
        self._refresh_library_tree()
        self.notebook.select(self.code_tab)
        self.status_var.set("C++ sketch generated successfully.")

    def save_sketch(self):
        if not self.code_text.get("1.0", "end-1c").strip() or self.code_text.get("1.0", "end-1c").startswith("// Your generated"):
            self.generate_code()
        code = self.code_text.get("1.0", "end-1c")
        if not code.strip():
            return
        path = filedialog.asksaveasfilename(defaultextension=".ino", filetypes=[("Arduino sketch", "*.ino"), ("C++ source", "*.cpp")], initialfile="iot_project.ino")
        if not path:
            return
        Path(path).write_text(code, encoding="utf-8")
        self.status_var.set(f"Saved sketch: {path}")

    def copy_code(self):
        code = self.code_text.get("1.0", "end-1c")
        self.root.clipboard_clear()
        self.root.clipboard_append(code)
        self.status_var.set("Code copied to clipboard.")

    def save_project(self):
        self._sync_project_name()
        path = self.current_project_path or filedialog.asksaveasfilename(defaultextension=".iotproj", filetypes=[("Mixer Code project", "*.iotproj"), ("JSON", "*.json")], initialfile="my_iot_project.iotproj")
        if not path:
            return
        try:
            self.project.save(path)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Save failed", str(exc))
            return
        self.current_project_path = path
        self.status_var.set(f"Saved project: {path}")

    def open_project(self):
        path = filedialog.askopenfilename(filetypes=[("Mixer Code project", "*.iotproj *.json"), ("JSON", "*.json")])
        if not path:
            return
        try:
            project = Project.load(path)
        except Exception as exc:
            messagebox.showerror("Open failed", f"Could not open project:\n{exc}")
            return
        errors = project.validate()
        self.project = project
        self._set_custom_editor_values(None)
        self.current_project_path = path
        self.project_name_var.set(project.name)
        self.board_var.set(BOARDS.get(project.board_id, BOARDS["uno"]).display_name)
        self.board_note.configure(text=BOARDS.get(project.board_id, BOARDS["uno"]).notes)
        self._refresh_all()
        self.status_var.set(f"Opened project. {len(errors)} validation issue(s)." if errors else "Project opened successfully.")

    def new_project(self):
        if self.project.components or self.project.rules or self.project.custom_components or self.project.libraries or self.project.tasks or self.project.oled_screens or self.project.communications or self.project.sensor_monitors:
            if not messagebox.askyesno("New project", "Discard the current unsaved project and start fresh?"):
                return
        self.project = Project()
        self._set_custom_editor_values(None)
        self.current_project_path = None
        self.project_name_var.set(self.project.name)
        self.board_var.set(BOARDS[self.project.board_id].display_name)
        self.board_note.configure(text=BOARDS[self.project.board_id].notes)
        self.code_text.delete("1.0", tk.END)
        self.code_text.insert("1.0", "// Your generated Arduino C++ sketch will appear here.\n")
        self._refresh_all()
        self.status_var.set("Started a new project.")


def run_app():
    root = tk.Tk()
    IoTCodeStudio(root)
    root.mainloop()
