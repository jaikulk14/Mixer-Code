"""Deterministic Arduino C++ generator with display and independent-task adapters."""
from __future__ import annotations

import re
from collections import defaultdict
from .boards import BOARDS
from .catalog import COMPONENTS
from .model import Project
from .connectivity import generate_connectivity_sections


def _symbol(component_id: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_]", "_", component_id)
    if not value or value[0].isdigit():
        value = "c_" + value
    return value


def _condition(rule, source_kind: str) -> str:
    src = _symbol(rule.sensor_id)
    if source_kind == "digital_input":
        return f"{src}_state" if rule.condition in ("TRUE", "DETECTED") else f"!{src}_state"
    if source_kind == "analog_input":
        op = ">" if rule.condition == "ABOVE" else "<"
        return f"{src}_value {op} {rule.threshold}"
    if rule.condition == "DETECTED":
        return f"{src}_detected"
    if rule.condition == "NOT_DETECTED":
        return f"!{src}_detected"
    op = "<" if rule.condition == "BELOW" else ">"
    return f"({src}_distance_cm >= 0 && {src}_distance_cm {op} {rule.threshold})"


def _write_action(target, rule) -> str:
    dst = _symbol(target.id)
    if COMPONENTS[target.type_id].kind == "servo_output":
        return f"{dst}_servo.write({rule.angle});"
    on_actions = {"GLOW", "ON", "BEEP", "ACTIVATE"}
    active_level = target.active_level
    inactive_level = "LOW" if active_level == "HIGH" else "HIGH"
    level = active_level if rule.action in on_actions else inactive_level
    return f"digitalWrite({dst}_pin, {level});"


def _cpp_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\r", " ").replace("\n", " ")


def _unique(lines: list[str]) -> list[str]:
    seen = set()
    output = []
    for line in lines:
        key = line.strip()
        if key and key not in seen:
            seen.add(key)
            output.append(line)
    return output


def generate_cpp(project: Project) -> str:
    project.ensure_builtin_dependencies()
    errors = project.validate()
    if errors:
        raise ValueError("Project validation failed:\n- " + "\n- ".join(errors))
    board = BOARDS[project.board_id]
    connectivity = generate_connectivity_sections(project)
    lines: list[str] = ["/*", " * Mixer Code generated sketch", " * Release: 2.1.5", f" * Project: {project.name}",
        f" * Board profile: {board.display_name}", " * Generated deterministically from the project model.",
        " * Review wiring, voltage levels and module polarity before powering hardware.", " */", ""]

    servos = [c for c in project.components if COMPONENTS[c.type_id].kind == "servo_output"]
    displays = [c for c in project.components if COMPONENTS[c.type_id].kind == "display_output"]
    has_oled = any(c.type_id == "ssd1306_oled" for c in displays)
    has_lcd = any(c.type_id == "lcd1602_i2c" for c in displays)
    analog_inputs = [c for c in project.components if COMPONENTS[c.type_id].kind == "analog_input"]
    # A saved OLED Designer layout always wins. If the user has added an OLED
    # and analog input(s) but has not visited/saved the designer, generate a
    # sensible automatic dashboard instead of leaving the OLED on "OLED ready".
    # The fallback is local to generation and does not silently modify the
    # project's saved configuration.
    oled_screens = {}
    auto_oled_screens: set[str] = set()
    for display in displays:
        if display.type_id != "ssd1306_oled":
            continue
        configured_screen = project.oled_screen(display.id)
        resolved_screen = configured_screen or project.default_oled_screen(display.id)
        if resolved_screen is not None:
            oled_screens[display.id] = resolved_screen
            if configured_screen is None:
                auto_oled_screens.add(display.id)
    enabled_tasks = [t for t in project.tasks if t.enabled]
    active_sensor_monitors = [m for m in project.sensor_monitors if m.mode in ("continuous", "both")]
    sensor_monitor_distance_ids = {
        m.component_id for m in active_sensor_monitors
        if COMPONENTS[project.component(m.component_id).type_id].kind == "distance_input"
    }
    async_distance_ids = {t.component_id for t in enabled_tasks if t.task_type == "ultrasonic_monitor"} | sensor_monitor_distance_ids
    active_sweep_tasks = [t for t in enabled_tasks if t.task_type == "servo_sweep"]
    # A single sweep servo + a sonar monitor is the common radar configuration.
    # Capture the angle at ping start so the serial stream pairs each reading
    # with the servo position at the time the measurement was triggered.
    radar_servo_task = active_sweep_tasks[0] if len(active_sweep_tasks) == 1 else None

    include_lines: list[str] = []
    if servos:
        include_lines.extend(["#if defined(ARDUINO_ARCH_ESP32)", "#include <ESP32Servo.h> // Install ESP32Servo for ESP32 boards.", "#else", "#include <Servo.h>", "#endif"])
    if displays:
        include_lines.append("#include <Wire.h>")
    if has_oled:
        include_lines.extend(["#include <Adafruit_GFX.h>", "#include <Adafruit_SSD1306.h>"])
    if has_lcd:
        include_lines.extend(["#include <hd44780.h>", "#include <hd44780ioClass/hd44780_I2Cexp.h>"])
    include_lines.extend(connectivity["includes"])
    conditional_headers = {"ESP32Servo.h", "Servo.h"} if servos else set()
    # Preserve the explicit include order from an imported integration before
    # adding library-manager dependency headers. This matters when a driver
    # header expects Wire.h (or another core header) to have been included first.
    for custom in project.custom_components:
        if custom.includes.strip():
            include_lines.extend(custom.includes.strip().splitlines())
    for library in project.libraries:
        if library.includes.strip():
            for include in library.includes.strip().splitlines():
                header = re.search(r"[<\"]([^>\"]+)[>\"]", include)
                if not (header and header.group(1).split("/")[-1] in conditional_headers):
                    include_lines.append(include)
    include_lines = _unique(include_lines)
    lines.extend(include_lines)
    if include_lines:
        lines.append("")

    for custom in project.custom_components:
        safe_name = custom.name.replace("\r", " ").replace("\n", " ").replace("*/", "* /")
        safe_source = custom.source_url.replace("\r", " ").replace("\n", " ").replace("*/", "* /")
        safe_notes = custom.notes.replace("\r", " ").replace("\n", " ").replace("*/", "* /")
        lines.append(f"// Custom component: {safe_name}")
        if safe_source: lines.append(f"// Documentation source: {safe_source}")
        if safe_notes: lines.append(f"// Wiring / notes: {safe_notes}")
    for library in project.libraries:
        lines.append(f"// Library dependency: {library.name}" + (f" {library.version}" if library.version else ""))
        if library.source_url: lines.append(f"// Library documentation: {library.source_url}")
        if library.notes: lines.append(f"// Library notes: {library.notes.replace(chr(10), ' ')}")
    if project.custom_components or project.libraries:
        lines.append("")

    lines.append("// Pin map")
    for c in project.components:
        if COMPONENTS[c.type_id].kind == "display_output":
            lines.append(f"// {c.name} ({c.type_id}) uses I2C: board-default SDA/SCL pins")
        else:
            for key, pin in c.pins.items(): lines.append(f"// {c.name} ({c.type_id}) {key}: {pin}")
    if displays:
        if project.board_id in ("uno", "nano"):
            lines.append("// I2C pins: SDA=A4, SCL=A5")
        elif project.board_id == "esp32":
            lines.append("// I2C defaults on this profile: SDA=GPIO21, SCL=GPIO22")
        elif project.board_id == "esp8266":
            lines.append("// NodeMCU I2C defaults on this profile: SDA=GPIO4 (D2), SCL=GPIO5 (D1)")
    lines.append("")

    for c in servos:
        lines.append(f"Servo {_symbol(c.id)}_servo;")
    for c in displays:
        s = _symbol(c.id)
        address = str(c.settings.get("address", "0x3C" if c.type_id == "ssd1306_oled" else "0x27"))
        if c.type_id == "ssd1306_oled":
            lines.append(f"Adafruit_SSD1306 {s}_display(128, 64, &Wire, -1);")
        elif c.type_id == "lcd1602_i2c":
            lines.append(f"hd44780_I2Cexp {s}_display({address});")
    for c in project.components:
        s = _symbol(c.id)
        spec = COMPONENTS[c.type_id]
        if spec.kind == "distance_input":
            lines.append(f"const uint8_t {s}_trig_pin = {c.pins['trig']};")
            lines.append(f"const uint8_t {s}_echo_pin = {c.pins['echo']};")
            lines.append(f"bool {s}_detected = false; // True when a valid ultrasonic echo is received.")
        elif spec.kind != "display_output":
            lines.append(f"const uint8_t {s}_pin = {c.pins['signal']};")
    if project.components or servos or displays:
        lines.append("")
    if connectivity["globals"]:
        lines.extend(connectivity["globals"])
        lines.append("")

    for custom in project.custom_components:
        code = custom.declarations.strip()
        if code:
            lines.append(f"// Custom component declarations and helper functions: {custom.name}")
            lines.extend(code.splitlines()); lines.append("")

    if connectivity["helpers"]:
        lines.extend(connectivity["helpers"])
        lines.append("")

    blocking_distances = [c for c in project.components if COMPONENTS[c.type_id].kind == "distance_input" and c.id not in async_distance_ids]
    if blocking_distances:
        lines.extend(["float readDistanceCm(uint8_t trigPin, uint8_t echoPin) {", "  digitalWrite(trigPin, LOW);", "  delayMicroseconds(2);", "  digitalWrite(trigPin, HIGH);", "  delayMicroseconds(10);", "  digitalWrite(trigPin, LOW);", "  unsigned long duration = pulseIn(echoPin, HIGH, 30000UL);", "  if (duration == 0) return -1.0f; // No echo / out of range", "  return (duration * 0.0343f) / 2.0f;", "}", ""])

    # Global state for independent, cooperative tasks.
    for display in displays:
        if enabled_tasks or active_sensor_monitors or display.id in oled_screens:
            lines.append(f"unsigned long {_symbol(display.id)}_last_update_ms = 0;")
    for monitor in active_sensor_monitors:
        component = project.component(monitor.component_id)
        symbol = _symbol(component.id)
        kind = COMPONENTS[component.type_id].kind
        if kind in ("analog_input", "digital_input"):
            lines.append(f"unsigned long {symbol}_monitor_last_ms = 0;")
        elif kind == "distance_input":
            task_symbol = f"sensor_monitor_{symbol}"
            lines.extend([
                f"float {symbol}_distance_cm = -1.0f;",
                f"uint8_t {task_symbol}_state = 0; // 0=wait, 1=wait for echo HIGH, 2=wait for echo LOW",
                f"unsigned long {task_symbol}_state_started_us = 0;",
                f"unsigned long {task_symbol}_echo_started_us = 0;",
                f"unsigned long {task_symbol}_last_ping_us = 0;",
            ])
    for task in enabled_tasks:
        t = _symbol(task.id)
        if task.task_type == "servo_sweep":
            lines.extend([f"unsigned long {t}_last_ms = 0;", f"int {t}_angle = {task.start_angle};", f"int {t}_direction = 1;"])
        elif task.task_type == "ultrasonic_monitor":
            c = _symbol(task.component_id)
            lines.extend([f"float {c}_distance_cm = -1.0f;", f"uint8_t {t}_state = 0; // 0=wait, 1=wait for echo HIGH, 2=wait for echo LOW", f"unsigned long {t}_state_started_us = 0;", f"unsigned long {t}_echo_started_us = 0;", f"unsigned long {t}_last_ping_us = 0;"])
            if radar_servo_task is not None:
                lines.append(f"int {t}_angle_at_ping = 0;")
    if enabled_tasks:
        lines.append("")

    task_functions: list[str] = []
    for task in enabled_tasks:
        t = _symbol(task.id)
        component = project.component(task.component_id)
        c = _symbol(component.id)
        if task.task_type == "servo_sweep":
            task_functions.extend([
                f"void tick_{t}() {{",
                f"  unsigned long now = millis();",
                f"  if ((unsigned long)(now - {t}_last_ms) >= {task.interval_ms}UL) {{",
                f"    {t}_last_ms = now;",
                f"    {t}_angle += {t}_direction * {task.step_degrees};",
                f"    if ({t}_angle >= {task.end_angle}) {{ {t}_angle = {task.end_angle}; {t}_direction = -1; }}",
                f"    else if ({t}_angle <= {task.start_angle}) {{ {t}_angle = {task.start_angle}; {t}_direction = 1; }}",
                f"    {c}_servo.write({t}_angle);",
                "  }", "}", "",
            ])
        elif task.task_type == "ultrasonic_monitor":
            trig = f"{c}_trig_pin"; echo = f"{c}_echo_pin"
            task_functions.extend([
                f"void tick_{t}() {{",
                "  unsigned long nowUs = micros();",
                f"  if ({t}_state == 0) {{",
                f"    if ((unsigned long)(nowUs - {t}_last_ping_us) >= {task.interval_ms}UL * 1000UL) {{",
                *([f"      {t}_angle_at_ping = {_symbol(radar_servo_task.id)}_angle;"] if radar_servo_task is not None else []),
                f"      digitalWrite({trig}, LOW);",
                "      delayMicroseconds(2);",
                f"      digitalWrite({trig}, HIGH);",
                "      delayMicroseconds(10);",
                f"      digitalWrite({trig}, LOW);",
                f"      {t}_state_started_us = micros();",
                f"      {t}_state = 1;",
                "    }",
                f"  }} else if ({t}_state == 1) {{",
                f"    if (digitalRead({echo}) == HIGH) {{ {t}_echo_started_us = micros(); {t}_state = 2; }}",
                *([f"    else if ((unsigned long)(nowUs - {t}_state_started_us) > 30000UL) {{ {c}_distance_cm = -1.0f; {c}_detected = false; Serial.print(F(\"RADAR,\")); Serial.print({t}_angle_at_ping); Serial.println(F(\",-1\")); {t}_last_ping_us = nowUs; {t}_state = 0; }}"] if radar_servo_task is not None else [f"    else if ((unsigned long)(nowUs - {t}_state_started_us) > 30000UL) {{ {c}_distance_cm = -1.0f; {c}_detected = false; {t}_last_ping_us = nowUs; {t}_state = 0; }}"]),
                f"  }} else if ({t}_state == 2) {{",
                f"    if (digitalRead({echo}) == LOW) {{",
                f"      unsigned long duration = (unsigned long)(micros() - {t}_echo_started_us);",
                f"      {c}_distance_cm = (duration * 0.0343f) / 2.0f;",
                f"      {c}_detected = true;",
                *([f"      Serial.print(F(\"RADAR,\")); Serial.print({t}_angle_at_ping); Serial.print(','); Serial.println({c}_distance_cm, 1);"] if radar_servo_task is not None else [f"      Serial.print(F(\"{_cpp_string(component.name)} distance: \")); Serial.print({c}_distance_cm); Serial.println(F(\" cm\"));"]),
                f"      {t}_last_ping_us = micros(); {t}_state = 0;",
                *([f"    }} else if ((unsigned long)(nowUs - {t}_echo_started_us) > 30000UL) {{ {c}_distance_cm = -1.0f; {c}_detected = false; Serial.print(F(\"RADAR,\")); Serial.print({t}_angle_at_ping); Serial.println(F(\",-1\")); {t}_last_ping_us = nowUs; {t}_state = 0; }}"] if radar_servo_task is not None else [f"    }} else if ((unsigned long)(nowUs - {t}_echo_started_us) > 30000UL) {{ {c}_distance_cm = -1.0f; {c}_detected = false; {t}_last_ping_us = nowUs; {t}_state = 0; }}"]),
                "  }", "}", "",
            ])
    lines.extend(task_functions)

    # Generic continuous monitor adapter for HC-SR04. Unlike pulseIn(), this
    # cooperative state machine returns immediately and is called every loop.
    monitor_functions: list[str] = []
    for monitor in active_sensor_monitors:
        component = project.component(monitor.component_id)
        if COMPONENTS[component.type_id].kind != "distance_input":
            continue
        c = _symbol(component.id)
        t = f"sensor_monitor_{c}"
        trig, echo = f"{c}_trig_pin", f"{c}_echo_pin"
        tag = _cpp_string(component.id)
        monitor_functions.extend([
            f"void tick_{t}() {{",
            "  unsigned long nowUs = micros();",
            f"  if ({t}_state == 0) {{",
            f"    if ((unsigned long)(nowUs - {t}_last_ping_us) >= {monitor.interval_ms}UL * 1000UL) {{",
            f"      digitalWrite({trig}, LOW);",
            "      delayMicroseconds(2);",
            f"      digitalWrite({trig}, HIGH);",
            "      delayMicroseconds(10);",
            f"      digitalWrite({trig}, LOW);",
            f"      {t}_state_started_us = micros();",
            f"      {t}_state = 1;",
            "    }",
            f"  }} else if ({t}_state == 1) {{",
            f"    if (digitalRead({echo}) == HIGH) {{ {t}_echo_started_us = micros(); {t}_state = 2; }}",
            f"    else if ((unsigned long)(nowUs - {t}_state_started_us) > 30000UL) {{",
            f"      {c}_distance_cm = -1.0f;",
            f"      {c}_detected = false;",
            f'      Serial.print(F("MONITOR,{tag},DISTANCE_CM,")); Serial.println(-1);',
            f"      {t}_last_ping_us = nowUs; {t}_state = 0;",
            "    }",
            f"  }} else if ({t}_state == 2) {{",
            f"    if (digitalRead({echo}) == LOW) {{",
            f"      unsigned long duration = (unsigned long)(micros() - {t}_echo_started_us);",
            f"      {c}_distance_cm = (duration * 0.0343f) / 2.0f;",
            f"      {c}_detected = true;",
            f'      Serial.print(F("MONITOR,{tag},DISTANCE_CM,")); Serial.println({c}_distance_cm, 1);',
            f"      {t}_last_ping_us = micros(); {t}_state = 0;",
            f"    }} else if ((unsigned long)(nowUs - {t}_echo_started_us) > 30000UL) {{",
            f"      {c}_distance_cm = -1.0f;",
            f"      {c}_detected = false;",
            f'      Serial.print(F("MONITOR,{tag},DISTANCE_CM,")); Serial.println(-1);',
            f"      {t}_last_ping_us = nowUs; {t}_state = 0;",
            "    }",
            "  }",
            "}",
            "",
        ])
    lines.extend(monitor_functions)

    lines.append("void setup() {")
    custom_initializes_usb_serial = any(
        re.search(r"\bSerial\s*\.\s*begin\s*\(", custom.setup_code)
        for custom in project.custom_components
    )
    if custom_initializes_usb_serial:
        lines.append("  // Serial is initialized by an imported custom component.")
    else:
        lines.append("  Serial.begin(115200);")
    if analog_inputs and any(display.id in auto_oled_screens for display in displays) and len(analog_inputs) > 4:
        lines.append('  Serial.println(F("OLED automatic dashboard shows the first 4 analog inputs. Configure OLED Designer to choose a different set."));')
    if displays or any(cfg.profile_type == "i2c_scanner" for cfg in project.communications):
        lines.append("  Wire.begin();")
    for c in project.components:
        spec = COMPONENTS[c.type_id]; s = _symbol(c.id)
        if spec.kind == "digital_input":
            mode = "INPUT_PULLUP" if "INPUT_PULLUP" in spec.pin_modes else "INPUT"
            lines.append(f"  pinMode({s}_pin, {mode});")
        elif spec.kind == "analog_input":
            lines.append(f"  pinMode({s}_pin, INPUT);")
        elif spec.kind == "distance_input":
            lines.append(f"  pinMode({s}_trig_pin, OUTPUT); pinMode({s}_echo_pin, INPUT);")
            lines.append(f"  digitalWrite({s}_trig_pin, LOW);")
        elif spec.kind == "digital_output":
            inactive_level = "LOW" if c.active_level == "HIGH" else "HIGH"
            lines.append(f"  pinMode({s}_pin, OUTPUT);")
            lines.append(f"  digitalWrite({s}_pin, {inactive_level});")
        elif spec.kind == "servo_output":
            sweep = next((t for t in enabled_tasks if t.task_type == "servo_sweep" and t.component_id == c.id), None)
            initial = sweep.start_angle if sweep else 0
            lines.append(f"  {s}_servo.attach({s}_pin);")
            lines.append(f"  {s}_servo.write({initial});")
    for c in displays:
        s = _symbol(c.id)
        address = str(c.settings.get("address", "0x3C" if c.type_id == "ssd1306_oled" else "0x27"))
        if c.type_id == "ssd1306_oled":
            lines.extend([f"  if (!{s}_display.begin(SSD1306_SWITCHCAPVCC, {address}, true, false)) {{ Serial.println(F(\"SSD1306 allocation failed\")); }}",
                          f"  {s}_display.clearDisplay(); {s}_display.setTextSize(1); {s}_display.setTextColor(SSD1306_WHITE);",
                          f"  {s}_display.setCursor(0, 0); {s}_display.println(F(\"Mixer Code\")); {s}_display.println(F(\"OLED ready\")); {s}_display.display();"])
        elif c.type_id == "lcd1602_i2c":
            lines.extend([f"  int {s}_display_status = {s}_display.begin(16, 2);",
                          f"  if ({s}_display_status) Serial.println(F(\"LCD initialization failed\"));",
                          f"  {s}_display.clear(); {s}_display.setCursor(0, 0); {s}_display.print(\"Mixer Code\");",
                          f"  {s}_display.setCursor(0, 1); {s}_display.print(\"LCD ready\");"])
    for setup_line in connectivity["setup"]:
        lines.append("  " + setup_line if setup_line else "")
    for custom in project.custom_components:
        code = custom.setup_code.strip()
        if code:
            lines.append(f"  // Custom component setup: {custom.name}")
            lines.extend(("  " + line if line.strip() else "") for line in code.splitlines())
    lines.append("}")
    lines.append("")

    lines.append("void loop() {")
    if enabled_tasks or active_sensor_monitors:
        lines.append("  // Independent cooperative tasks and continuous sensor monitors.")
        for task in enabled_tasks:
            lines.append(f"  tick_{_symbol(task.id)}();")
        for monitor in active_sensor_monitors:
            component = project.component(monitor.component_id)
            if COMPONENTS[component.type_id].kind == "distance_input":
                lines.append(f"  tick_sensor_monitor_{_symbol(component.id)}();")
    for c in project.components:
        spec = COMPONENTS[c.type_id]; s = _symbol(c.id)
        if spec.kind == "digital_input":
            lines.append(f"  bool {s}_state = (digitalRead({s}_pin) == {c.active_level});")
        elif spec.kind == "analog_input":
            lines.append(f"  int {s}_value = analogRead({s}_pin);")
        elif spec.kind == "distance_input" and c.id not in async_distance_ids:
            lines.append(f"  float {s}_distance_cm = readDistanceCm({s}_trig_pin, {s}_echo_pin);")
            lines.append(f"  {s}_detected = ({s}_distance_cm >= 0.0f);")
    for monitor in active_sensor_monitors:
        component = project.component(monitor.component_id)
        symbol = _symbol(component.id)
        kind = COMPONENTS[component.type_id].kind
        if kind not in ("analog_input", "digital_input"):
            continue
        tag = _cpp_string(component.id)
        lines.extend([
            f"  if ((unsigned long)(millis() - {symbol}_monitor_last_ms) >= {monitor.interval_ms}UL) {{",
            f"    {symbol}_monitor_last_ms = millis();",
        ])
        if kind == "analog_input":
            lines.append(f'    Serial.print(F("MONITOR,{tag},ANALOG,")); Serial.println({symbol}_value);')
        else:
            lines.append(f'    Serial.print(F("MONITOR,{tag},DIGITAL,")); Serial.println({symbol}_state ? F("ACTIVE") : F("INACTIVE"));')
        lines.append("  }")
    if project.components:
        lines.append("")

    grouped = defaultdict(list)
    for rule in project.rules:
        grouped[rule.target_id].append(rule)
    for target_id, rules in grouped.items():
        target = project.component(target_id); target_symbol = _symbol(target_id)
        lines.append(f"  // Logic for {target.name}. First matching rule wins.")
        for index, rule in enumerate(rules):
            source = project.component(rule.sensor_id); source_kind = COMPONENTS[source.type_id].kind
            prefix = "if" if index == 0 else "else if"
            lines.append(f"  {prefix} ({_condition(rule, source_kind)}) {{")
            lines.append(f"    {_write_action(target, rule)}")
            lines.append("  }")
        if COMPONENTS[target.type_id].kind == "digital_output":
            inactive_level = "LOW" if target.active_level == "HIGH" else "HIGH"
            lines.extend(["  else {", f"    digitalWrite({target_symbol}_pin, {inactive_level}); // Safe default when no rule matches", "  }"])
        lines.append("")

    for loop_line in connectivity["loop"]:
        lines.append("  " + loop_line if loop_line else "")
    if connectivity["loop"]:
        lines.append("")

    if displays:
        distance_task = next((t for t in enabled_tasks if t.task_type == "ultrasonic_monitor"), None)
        servo_task = next((t for t in enabled_tasks if t.task_type == "servo_sweep"), None)
        for display in displays:
            d = _symbol(display.id)
            screen = oled_screens.get(display.id) if display.type_id == "ssd1306_oled" else None
            if screen is not None:
                if display.id in auto_oled_screens:
                    lines.append(f"  // Automatic OLED dashboard: displays the first {len(screen.sensor_ids)} analog input(s) until a custom layout is saved.")
                lines.extend([
                    f"  if ((unsigned long)(millis() - {d}_last_update_ms) >= {screen.refresh_ms}UL) {{",
                    f"    {d}_last_update_ms = millis();",
                    f"    {d}_display.clearDisplay();",
                    f"    {d}_display.setTextSize(1);",
                    f"    {d}_display.setCursor(0, 0); {d}_display.println(F(\"{_cpp_string(screen.title[:20])}\"));",
                ])
                selected_sensors = [project.component(sensor_id) for sensor_id in screen.sensor_ids]
                if screen.layout == "single_value":
                    sensor = selected_sensors[0]
                    ss = _symbol(sensor.id)
                    lines.extend([
                        f"    {d}_display.setCursor(0, 15); {d}_display.println(F(\"{_cpp_string(sensor.name[:20])}\"));",
                        f"    {d}_display.setTextSize(2); {d}_display.setCursor(0, 28); {d}_display.print({ss}_value);",
                        f"    {d}_display.setTextSize(1);",
                        f"    {d}_display.drawRect(0, 53, 128, 9, SSD1306_WHITE);",
                        f"    {d}_display.fillRect(2, 55, (uint8_t)((long){ss}_value * 124L / {board.adc_max}L), 5, SSD1306_WHITE);",
                    ])
                elif screen.layout == "two_column":
                    for index, sensor in enumerate(selected_sensors):
                        ss = _symbol(sensor.id)
                        x = 0 if index == 0 else 66
                        lines.extend([
                            f"    {d}_display.setCursor({x}, 20); {d}_display.println(F(\"{_cpp_string(sensor.name[:10])}\"));",
                            f"    {d}_display.setCursor({x}, 36); {d}_display.print({ss}_value);",
                        ])
                elif screen.layout == "list":
                    for index, sensor in enumerate(selected_sensors):
                        ss = _symbol(sensor.id)
                        y = 13 + index * 12
                        lines.extend([
                            f"    {d}_display.setCursor(0, {y}); {d}_display.print(F(\"{_cpp_string(sensor.name[:15])}\"));",
                            f"    {d}_display.setCursor(98, {y}); {d}_display.print({ss}_value);",
                        ])
                elif screen.layout == "bar_graph":
                    for index, sensor in enumerate(selected_sensors):
                        ss = _symbol(sensor.id)
                        y = 12 + index * 17
                        lines.extend([
                            f"    {d}_display.setCursor(0, {y}); {d}_display.print(F(\"{_cpp_string(sensor.name[:12])}\"));",
                            f"    {d}_display.setCursor(100, {y}); {d}_display.print({ss}_value);",
                            f"    {d}_display.drawRect(0, {y + 8}, 128, 7, SSD1306_WHITE);",
                            f"    {d}_display.fillRect(2, {y + 10}, (uint8_t)((long){ss}_value * 124L / {board.adc_max}L), 3, SSD1306_WHITE);",
                        ])
                lines.extend([f"    {d}_display.display();", "  }", ""])
            elif enabled_tasks or active_sensor_monitors:
                refresh_interval = max(100, min([m.interval_ms for m in active_sensor_monitors] + [150]))
                lines.extend([f"  if ((unsigned long)(millis() - {d}_last_update_ms) >= {refresh_interval}UL) {{", f"    {d}_last_update_ms = millis();"])
                if display.type_id == "ssd1306_oled":
                    screen_title = "LIVE SENSOR MONITOR" if active_sensor_monitors else "MIXER CODE RADAR"
                    lines.extend([
                        f"    {d}_display.clearDisplay();",
                        f"    {d}_display.setTextSize(1);",
                        f"    {d}_display.setCursor(0, 0); {d}_display.println(F(\"{screen_title}\"));",
                    ])
                    if active_sensor_monitors:
                        for row_index, monitor in enumerate(active_sensor_monitors[:4]):
                            component = project.component(monitor.component_id)
                            cs = _symbol(component.id)
                            kind = COMPONENTS[component.type_id].kind
                            y = 13 + row_index * 12
                            if kind == "analog_input":
                                lines.append(f"    {d}_display.setCursor(0, {y}); {d}_display.print(F(\"{_cpp_string(component.name[:12])}: \")); {d}_display.print({cs}_value);")
                            elif kind == "digital_input":
                                lines.append(f"    {d}_display.setCursor(0, {y}); {d}_display.print(F(\"{_cpp_string(component.name[:12])}: \")); {d}_display.print({cs}_state ? F(\"ACTIVE\") : F(\"INACTIVE\"));")
                            else:
                                lines.append(f"    {d}_display.setCursor(0, {y}); {d}_display.print(F(\"{_cpp_string(component.name[:10])}: \")); if ({cs}_distance_cm < 0) {d}_display.print(F(\"No echo\")); else {{ {d}_display.print({cs}_distance_cm, 1); {d}_display.print(F(\" cm\")); }}")
                    else:
                        if distance_task:
                            ds = _symbol(distance_task.component_id)
                            lines.append(f"    {d}_display.setCursor(0, 16); {d}_display.print(F(\"Distance: \")); if ({ds}_distance_cm < 0) {d}_display.println(F(\"No echo\")); else {{ {d}_display.print({ds}_distance_cm, 1); {d}_display.println(F(\" cm\")); }}")
                        if servo_task:
                            ts = _symbol(servo_task.id)
                            lines.append(f"    {d}_display.setCursor(0, 53); {d}_display.print(F(\"Angle: \")); {d}_display.println({ts}_angle);")
                    lines.append(f"    {d}_display.display();")
                elif display.type_id == "lcd1602_i2c":
                    if active_sensor_monitors:
                        for row_index, monitor in enumerate(active_sensor_monitors[:2]):
                            component = project.component(monitor.component_id)
                            cs = _symbol(component.id)
                            kind = COMPONENTS[component.type_id].kind
                            lines.append(f"    {d}_display.setCursor(0, {row_index}); {d}_display.print(F(\"{_cpp_string(component.name[:7])}:\"));")
                            if kind == "analog_input":
                                lines.append(f"    {d}_display.print({cs}_value); {d}_display.print(F(\"    \"));")
                            elif kind == "digital_input":
                                lines.append(f"    {d}_display.print({cs}_state ? F(\"ON\") : F(\"OFF\")); {d}_display.print(F(\"   \"));")
                            else:
                                lines.append(f"    if ({cs}_distance_cm < 0) {d}_display.print(F(\"--.-cm  \")); else {{ {d}_display.print({cs}_distance_cm, 1); {d}_display.print(F(\"cm  \")); }}")
                    else:
                        if distance_task:
                            ds = _symbol(distance_task.component_id)
                            lines.append(f"    {d}_display.setCursor(0, 0); {d}_display.print(F(\"Dist: \")); if ({ds}_distance_cm < 0) {d}_display.print(F(\"--.- cm   \")); else {{ {d}_display.print({ds}_distance_cm, 1); {d}_display.print(F(\" cm  \")); }}")
                        if servo_task:
                            ts = _symbol(servo_task.id)
                            lines.append(f"    {d}_display.setCursor(0, 1); {d}_display.print(F(\"Angle: \")); {d}_display.print({ts}_angle); {d}_display.print(F(\"    \"));")
                lines.append("  }")
                lines.append("")

    for custom in project.custom_components:
        code = custom.loop_code.strip()
        if code:
            lines.append(f"  // Custom component loop code: {custom.name}")
            lines.extend(("  " + line if line.strip() else "") for line in code.splitlines())
            lines.append("")
    has_custom_loop_code = any(custom.loop_code.strip() for custom in project.custom_components)
    if not enabled_tasks and not active_sensor_monitors and not connectivity["loop"] and not has_custom_loop_code:
        lines.append("  delay(20); // Small loop pause; tune for your application.")
    elif connectivity["loop"]:
        lines.append("  // Communication handlers are polled continuously; keep custom work non-blocking.")
        lines.append("  delay(1); // Yield briefly to background network/USB tasks.")
    elif has_custom_loop_code:
        lines.append("  // Imported custom loop code controls its own timing; review delay() calls before combining with tasks.")
    else:
        lines.append("  // No blocking delay: independent tasks and continuous monitors stay responsive.")
    lines.append("}")
    lines.append("")
    return "\n".join(lines)
