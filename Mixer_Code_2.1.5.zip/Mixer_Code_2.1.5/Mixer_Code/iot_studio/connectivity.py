"""Connectivity profiles and deterministic Arduino code generation.

Supported adapters intentionally use documented, well-established APIs. The
module keeps configuration/validation separate from the Tk UI and main sketch
renderer so every profile can be unit-tested independently.
"""
from __future__ import annotations

import re
from typing import Any

from .boards import BOARDS, validate_pin, PinError


def _field(label: str, default: str, kind: str = "text", help_text: str = "") -> dict[str, str]:
    return {"label": label, "default": default, "kind": kind, "help": help_text}


PROFILES: dict[str, dict[str, Any]] = {
    "uart_bridge": {
        "name": "UART Serial Bridge", "category": "Serial", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Bidirectional bridge between USB Serial Monitor and a second UART. Uses SoftwareSerial on Uno/Nano and UART2 on ESP32/ESP8266.",
        "fields": {"rx_pin": _field("Module RX pin (MCU receives)", "10"), "tx_pin": _field("Module TX pin (MCU transmits)", "11"), "baud": _field("Baud rate", "9600")},
    },
    "rs485_half_duplex": {
        "name": "MAX485 RS-485 Half-Duplex Bridge", "category": "Serial & Industrial", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Raw UART bridge for a MAX485/RS-485 transceiver. DE and RE are tied together to the direction-control pin. This is not a Modbus RTU implementation.",
        "fields": {"rx_pin": _field("RO → MCU RX pin", "10"), "tx_pin": _field("MCU TX → DI pin", "11"), "de_pin": _field("DE + /RE direction pin", "4"), "baud": _field("Bus baud rate", "9600")},
    },
    "hc05_bluetooth": {
        "name": "HC-05 / HC-06 Bluetooth Classic UART", "category": "Bluetooth", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Serial bridge to an external HC-05/HC-06 module. The module handles Bluetooth pairing; this profile handles its UART link.",
        "fields": {"rx_pin": _field("Module TX → MCU RX pin", "10"), "tx_pin": _field("MCU TX → module RX pin", "11"), "baud": _field("Module data baud", "9600")},
    },
    "hm10_ble_uart": {
        "name": "HM-10 BLE UART", "category": "Bluetooth", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Serial bridge to an external HM-10-compatible BLE UART module. BLE service/firmware varies by module clone.",
        "fields": {"rx_pin": _field("Module TX → MCU RX pin", "10"), "tx_pin": _field("MCU TX → module RX pin", "11"), "baud": _field("Module baud", "9600")},
    },
    "esp32_bt_spp": {
        "name": "ESP32 Bluetooth Classic SPP", "category": "Bluetooth", "boards": ("esp32",),
        "description": "Native Bluetooth Classic serial service on original ESP32 SoCs that support SPP. Not supported on ESP32-S2/C3/S3.",
        "fields": {"device_name": _field("Bluetooth device name", "MixerCode")},
    },
    "wifi_sta": {
        "name": "Wi-Fi Station (connect to router)", "category": "Wi-Fi & Network", "boards": ("esp32", "esp8266"),
        "description": "Connects an ESP32 or ESP8266 board to an existing Wi-Fi access point with a retry timer.",
        "fields": {"ssid": _field("Wi-Fi SSID", "YOUR_WIFI_NAME"), "password": _field("Wi-Fi password", "YOUR_WIFI_PASSWORD", "password")},
    },
    "wifi_ap": {
        "name": "Wi-Fi Access Point (device hotspot)", "category": "Wi-Fi & Network", "boards": ("esp32", "esp8266"),
        "description": "Creates a local Wi-Fi network from the ESP32/ESP8266. Other devices can connect directly to the board.",
        "fields": {"ssid": _field("Access point SSID", "MixerCode_AP"), "password": _field("Access point password (8+ chars)", "CHANGE_THIS_PASSWORD", "password")},
    },
    "esp8266_at_wifi": {
        "name": "ESP8266 AT Wi-Fi Modem (Uno/Nano)", "category": "Wi-Fi & Network", "boards": ("uno", "nano"),
        "description": "Initializes an ESP8266 running Espressif ESP-AT firmware over a software UART. It joins a router and reports modem responses; it is not a transparent TCP/MQTT client.",
        "fields": {"rx_pin": _field("ESP8266 TX → MCU RX pin", "10"), "tx_pin": _field("MCU TX → ESP8266 RX pin", "11"), "baud": _field("ESP-AT baud rate", "9600"), "ssid": _field("Wi-Fi SSID", "YOUR_WIFI_NAME"), "password": _field("Wi-Fi password", "YOUR_WIFI_PASSWORD", "password")},
    },
    "mqtt_client": {
        "name": "MQTT Client", "category": "IoT Cloud & Messaging", "boards": ("esp32", "esp8266"),
        "description": "PubSubClient MQTT client with reconnect scheduling, one subscription and a startup publish. Requires Wi-Fi Station.",
        "fields": {"host": _field("Broker hostname / IP", "broker.hivemq.com"), "port": _field("Broker port", "1883"), "client_id": _field("Client ID", "MixerCodeDevice"), "username": _field("Username (optional)", ""), "password": _field("Password (optional)", "", "password"), "subscribe_topic": _field("Subscribe topic", "mixercode/in"), "publish_topic": _field("Publish topic", "mixercode/out"), "reconnect_ms": _field("Reconnect interval (ms)", "5000")},
    },
    "http_get": {
        "name": "HTTP REST Client (GET/POST/PUT/DELETE)", "category": "IoT Cloud & Messaging", "boards": ("esp32", "esp8266"),
        "description": "Periodically performs an HTTP REST request and prints the response. Requires Wi-Fi Station. Basic template is plain HTTP; HTTPS needs certificate/client configuration.",
        "fields": {"method": _field("HTTP method (GET/POST/PUT/DELETE)", "GET"), "url": _field("HTTP URL (http://)", "http://example.com/"), "payload": _field("Request body (POST/PUT/DELETE)", "{\"message\":\"hello\"}"), "interval_ms": _field("Request interval (ms)", "30000")},
    },
    "udp_listener": {
        "name": "UDP Listener", "category": "IoT Cloud & Messaging", "boards": ("esp32", "esp8266"),
        "description": "Listens for UDP datagrams on a local port and prints received payloads. Requires Wi-Fi Station or Access Point.",
        "fields": {"listen_port": _field("Local UDP port", "4210")},
    },
    "web_server": {
        "name": "HTTP Web Status Server", "category": "IoT Cloud & Messaging", "boards": ("esp32", "esp8266"),
        "description": "Hosts a minimal / and /status plain-text page on the board. Requires Wi-Fi Station or Access Point.",
        "fields": {"port": _field("HTTP server port", "80")},
    },
    "ntp_sync": {
        "name": "NTP Clock Synchronization", "category": "Time & Storage", "boards": ("esp32", "esp8266"),
        "description": "Synchronizes the device clock over the network and prints formatted local time periodically. Requires Wi-Fi Station.",
        "fields": {"utc_offset_seconds": _field("UTC offset seconds", "19800"), "daylight_offset_seconds": _field("Daylight offset seconds", "0"), "interval_ms": _field("Print interval (ms)", "60000")},
    },
    "wifi_scan": {
        "name": "Wi-Fi Network Scanner", "category": "Wi-Fi & Network", "boards": ("esp32", "esp8266"),
        "description": "Scans nearby Wi-Fi access points once at startup and prints SSID, RSSI and channel. Scanning may temporarily interrupt a station connection.",
        "fields": {},
    },
    "lora_radio": {
        "name": "LoRa SX127x Radio (send + receive)", "category": "Long-range Radio", "boards": ("uno", "nano", "esp32"),
        "description": "Sends a short text packet periodically and prints received packets using the SX1276/77/78/79 LoRa library. Radio frequency, antenna and duty-cycle rules are region-specific; verify local regulations before transmitting.",
        "fields": {"cs_pin": _field("NSS / CS pin", "10"), "reset_pin": _field("RESET pin", "9"), "dio0_pin": _field("DIO0 interrupt pin", "2"), "frequency_mhz": _field("Radio frequency MHz (verify region)", "866.0"), "node_message": _field("Message to transmit", "Mixer Code node online"), "interval_ms": _field("Transmit interval (ms)", "10000")},
    },
    "ota_update": {
        "name": "ESP32 OTA Firmware Update", "category": "Device Management", "boards": ("esp32",),
        "description": "Enables ArduinoOTA firmware uploads over the local network. Requires Wi-Fi Station and a unique hostname.",
        "fields": {"hostname": _field("OTA hostname", "mixer-coder-device"), "password": _field("OTA password (required)", "CHANGE_THIS_PASSWORD", "password")},
    },
    "i2c_scanner": {
        "name": "I2C Bus Scanner", "category": "Hardware Buses", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Scans I2C addresses once at startup and reports responding devices over Serial. Uses the board's default SDA/SCL pins.",
        "fields": {},
    },
    "spi_transfer": {
        "name": "SPI Byte Transfer Test", "category": "Hardware Buses", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Performs a periodic one-byte SPI transaction and prints the received byte. Connect a compatible SPI peripheral and select its CS pin.",
        "fields": {"cs_pin": _field("Chip-select pin", "10"), "tx_byte": _field("Byte to transmit (0-255)", "0"), "clock_hz": _field("SPI clock (Hz)", "1000000"), "interval_ms": _field("Transfer interval (ms)", "1000")},
    },
    "sd_logger": {
        "name": "SPI SD Card CSV Logger", "category": "Time & Storage", "boards": ("uno", "nano", "esp32", "esp8266"),
        "description": "Creates/opens a CSV file and appends an uptime row at a set interval. Extend the row with your sensor values in the generated code or custom loop section.",
        "fields": {"cs_pin": _field("SD chip-select pin", "10"), "file_name": _field("CSV filename", "mixer.csv"), "interval_ms": _field("Log interval (ms)", "1000")},
    },
}


def profile_options(board_id: str | None = None) -> list[tuple[str, str]]:
    return [(key, value["name"]) for key, value in PROFILES.items() if board_id is None or board_id in value["boards"]]


def profile_defaults(profile_type: str, board_id: str | None = None) -> dict[str, str]:
    spec = PROFILES[profile_type]
    values = {key: field["default"] for key, field in spec["fields"].items()}
    if board_id == "esp32":
        if profile_type in ("uart_bridge", "hc05_bluetooth", "hm10_ble_uart", "rs485_half_duplex"):
            values.update({"rx_pin": "16", "tx_pin": "17"})
            if profile_type == "rs485_half_duplex": values["de_pin"] = "25"
    elif board_id == "esp8266":
        if profile_type in ("uart_bridge", "hc05_bluetooth", "hm10_ble_uart", "rs485_half_duplex"):
            values.update({"rx_pin": "4", "tx_pin": "5"})
            if profile_type == "rs485_half_duplex": values["de_pin"] = "12"
        if profile_type in ("spi_transfer", "sd_logger"):
            values["cs_pin"] = "4"
    if profile_type == "lora_radio":
        if board_id == "esp32":
            values.update({"cs_pin": "25", "reset_pin": "14", "dio0_pin": "26"})
        elif board_id in ("uno", "nano"):
            values.update({"cs_pin": "10", "reset_pin": "9", "dio0_pin": "2"})
    return values


def _as_int(settings: dict[str, Any], key: str, default: int) -> int:
    try:
        return int(str(settings.get(key, default)).strip(), 0)
    except (TypeError, ValueError):
        return default


def validate_communications(project) -> list[str]:
    errors: list[str] = []
    board = project.board_id
    configs = project.communications
    ids: set[str] = set()
    counts: dict[str, int] = {}
    for index, cfg in enumerate(configs, 1):
        if cfg.profile_type not in PROFILES:
            errors.append(f"Connectivity profile {index}: unsupported profile {cfg.profile_type!r}.")
            continue
        spec = PROFILES[cfg.profile_type]
        if cfg.id in ids:
            errors.append(f"Connectivity profile {cfg.name}: duplicate profile ID.")
        ids.add(cfg.id)
        counts[cfg.profile_type] = counts.get(cfg.profile_type, 0) + 1
        if board not in spec["boards"]:
            errors.append(f"{cfg.name}: {spec['name']} is not supported on {BOARDS[board].display_name}.")
        st = cfg.settings
        if cfg.profile_type in ("uart_bridge", "hc05_bluetooth", "hm10_ble_uart", "esp8266_at_wifi", "rs485_half_duplex"):
            rx, tx = str(st.get("rx_pin", "10")), str(st.get("tx_pin", "11"))
            if rx.strip().upper() == tx.strip().upper():
                errors.append(f"{cfg.name}: RX and TX must use different pins.")
            try:
                validate_pin(BOARDS[board], rx, "input")
                validate_pin(BOARDS[board], tx, "output")
            except PinError as exc:
                errors.append(f"{cfg.name}: {exc}")
            baud = _as_int(st, "baud", 0)
            max_baud = 115200 if board in ("uno", "nano", "esp8266") else 1000000
            if not 1200 <= baud <= max_baud:
                errors.append(f"{cfg.name}: baud rate must be between 1200 and {max_baud} for this board's serial adapter.")
            if cfg.profile_type == "rs485_half_duplex":
                try:
                    validate_pin(BOARDS[board], str(st.get("de_pin", "")), "output")
                except PinError as exc:
                    errors.append(f"{cfg.name}: DE/RE direction pin: {exc}")
                rs485_pins = [str(st.get(k, "")).upper() for k in ("rx_pin", "tx_pin", "de_pin")]
                if len(set(rs485_pins)) != 3:
                    errors.append(f"{cfg.name}: RX, TX and DE/RE must use three different pins.")
        if cfg.profile_type in ("wifi_sta", "wifi_ap"):
            ssid = str(st.get("ssid", "")).strip()
            password = str(st.get("password", ""))
            if not ssid or ssid.upper().startswith(("YOUR_", "REPLACE_", "CHANGE_")):
                errors.append(f"{cfg.name}: replace the Wi-Fi SSID placeholder.")
            if cfg.profile_type == "wifi_sta" and password and password.upper().startswith(("YOUR_", "REPLACE_", "CHANGE_")):
                errors.append(f"{cfg.name}: replace the Wi-Fi password placeholder or explicitly use an empty password for an open network.")
            if cfg.profile_type == "wifi_ap" and (len(password) < 8 or len(password) > 63 or password == "CHANGE_THIS_PASSWORD"):
                errors.append(f"{cfg.name}: set a unique Wi-Fi AP password between 8 and 63 characters; do not keep the placeholder.")
        if cfg.profile_type == "esp8266_at_wifi":
            if not str(st.get("ssid", "")).strip() or str(st.get("ssid", "")).upper().startswith(("YOUR_", "REPLACE_", "CHANGE_")):
                errors.append(f"{cfg.name}: replace the Wi-Fi SSID placeholder.")
        if cfg.profile_type == "esp32_bt_spp":
            name = str(st.get("device_name", "")).strip()
            if not name:
                errors.append(f"{cfg.name}: Bluetooth device name cannot be empty.")
        if cfg.profile_type == "mqtt_client":
            if not str(st.get("host", "")).strip():
                errors.append(f"{cfg.name}: MQTT broker host is required.")
            if not 1 <= _as_int(st, "port", 0) <= 65535:
                errors.append(f"{cfg.name}: MQTT port must be between 1 and 65535.")
            if str(st.get("password", "")) and not str(st.get("username", "")).strip():
                errors.append(f"{cfg.name}: MQTT password requires a username; leave both empty for anonymous access.")
            if not str(st.get("client_id", "")).strip() or not str(st.get("publish_topic", "")).strip():
                errors.append(f"{cfg.name}: client ID and publish topic are required.")
            if not 1000 <= _as_int(st, "reconnect_ms", 0) <= 60000:
                errors.append(f"{cfg.name}: reconnect interval must be 1000 to 60000 ms.")
        if cfg.profile_type == "http_get":
            url = str(st.get("url", "")).strip()
            if not url.startswith("http://"):
                errors.append(f"{cfg.name}: this starter adapter accepts http:// URLs only. HTTPS requires explicit TLS certificate configuration.")
            method = str(st.get("method", "GET")).upper()
            if method not in {"GET", "POST", "PUT", "DELETE"}:
                errors.append(f"{cfg.name}: HTTP method must be GET, POST, PUT or DELETE.")
            if len(str(st.get("payload", ""))) > 1000:
                errors.append(f"{cfg.name}: request body must be 1000 characters or fewer.")
            if not 1000 <= _as_int(st, "interval_ms", 0) <= 86400000:
                errors.append(f"{cfg.name}: HTTP interval must be 1000 to 86400000 ms.")
        if cfg.profile_type in ("udp_listener",):
            if not 1 <= _as_int(st, "listen_port", 0) <= 65535:
                errors.append(f"{cfg.name}: UDP port must be between 1 and 65535.")
        if cfg.profile_type == "web_server":
            if not 1 <= _as_int(st, "port", 0) <= 65535:
                errors.append(f"{cfg.name}: web-server port must be between 1 and 65535.")
        if cfg.profile_type == "ntp_sync":
            if not -43200 <= _as_int(st, "utc_offset_seconds", 999999) <= 50400:
                errors.append(f"{cfg.name}: UTC offset is outside the supported range.")
            if not 1000 <= _as_int(st, "interval_ms", 0) <= 86400000:
                errors.append(f"{cfg.name}: NTP report interval must be 1000 to 86400000 ms.")
        if cfg.profile_type == "ota_update":
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]{0,31}", str(st.get("hostname", ""))):
                errors.append(f"{cfg.name}: hostname must contain 1-32 letters, digits or hyphens and start with a letter/digit.")
            if len(str(st.get("password", ""))) < 8 or str(st.get("password", "")) == "CHANGE_THIS_PASSWORD":
                errors.append(f"{cfg.name}: set a unique OTA password of at least 8 characters; do not keep the placeholder.")
        if cfg.profile_type == "lora_radio":
            for key, role in (("cs_pin", "output"), ("reset_pin", "output"), ("dio0_pin", "input")):
                try:
                    validate_pin(BOARDS[board], str(st.get(key, "")), role)
                except PinError as exc:
                    errors.append(f"{cfg.name}: {key}: {exc}")
            pins = [str(st.get(k, "")).upper() for k in ("cs_pin", "reset_pin", "dio0_pin")]
            if len(set(pins)) != 3:
                errors.append(f"{cfg.name}: CS, RESET and DIO0 must use three different pins.")
            if board in ("uno", "nano") and str(st.get("dio0_pin", "")).upper() not in {"2", "3"}:
                errors.append(f"{cfg.name}: on Uno/Nano, LoRa DIO0 must use external-interrupt pin D2 or D3.")
            try:
                frequency = float(st.get("frequency_mhz", "0"))
            except (TypeError, ValueError):
                frequency = 0
            if not 137.0 <= frequency <= 1020.0:
                errors.append(f"{cfg.name}: frequency must be between 137 and 1020 MHz; verify the module and local radio regulations.")
            if not 1000 <= _as_int(st, "interval_ms", 0) <= 86400000:
                errors.append(f"{cfg.name}: transmit interval must be 1000 to 86400000 ms.")
            if not str(st.get("node_message", "")).strip() or len(str(st.get("node_message", ""))) > 180:
                errors.append(f"{cfg.name}: LoRa message must contain 1-180 characters.")
        if cfg.profile_type in ("spi_transfer", "sd_logger"):
            pin_key = "cs_pin"
            try:
                validate_pin(BOARDS[board], str(st.get(pin_key, "10")), "output")
            except PinError as exc:
                errors.append(f"{cfg.name}: {exc}")
            if cfg.profile_type == "spi_transfer":
                if not 0 <= _as_int(st, "tx_byte", -1) <= 255:
                    errors.append(f"{cfg.name}: SPI transmit byte must be 0 to 255.")
                if not 10000 <= _as_int(st, "clock_hz", 0) <= 20000000:
                    errors.append(f"{cfg.name}: SPI clock must be 10000 to 20000000 Hz.")
            else:
                if not 100 <= _as_int(st, "interval_ms", 0) <= 86400000:
                    errors.append(f"{cfg.name}: SD logging interval must be 100 to 86400000 ms.")
                filename = str(st.get("file_name", "mixer.csv"))
                if not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}", filename):
                    errors.append(f"{cfg.name}: filename may contain letters, numbers, dot, underscore and hyphen only (max 32 chars).")
    serial_adapter_types = {"uart_bridge", "hc05_bluetooth", "hm10_ble_uart", "esp8266_at_wifi", "rs485_half_duplex"}
    serial_adapter_count = sum(1 for c in configs if c.profile_type in serial_adapter_types)
    if serial_adapter_count > 1:
        errors.append("This release assigns one serial port per UART/Bluetooth/modem adapter. Keep only one of these profiles per project to avoid UART/SoftwareSerial conflicts.")
    if counts.get("lora_radio", 0) > 1:
        errors.append("Only one LoRa radio instance is supported per project in this release.")
    if counts.get("sd_logger", 0) > 1:
        errors.append("Only one SD logger is supported per project in this release.")
    # Internet/server profiles use a native board Wi-Fi stack in this release.
    # The ESP8266 AT UART profile is an initialization/diagnostic adapter only.
    network_profiles = {"wifi_sta", "wifi_ap"}
    net_present = any(c.profile_type in network_profiles for c in configs)
    if counts.get("wifi_sta", 0) + counts.get("wifi_ap", 0) > 1:
        errors.append("Choose one built-in Wi-Fi mode per project (Station or Access Point). Combined AP+STA mode is not generated by this release.")
    if counts.get("esp8266_at_wifi", 0) > 1:
        errors.append("Only one ESP8266 AT modem profile is supported per project.")
    if counts.get("wifi_scan", 0) and (counts.get("wifi_sta", 0) or counts.get("wifi_ap", 0)):
        errors.append("The one-shot Wi-Fi scanner cannot be combined with Station/AP mode in this release. Use a separate scanner project to avoid interrupting the network service.")
    for cfg in configs:
        if cfg.profile_type in {"mqtt_client", "http_get", "udp_listener", "web_server", "ntp_sync", "ota_update"} and not net_present:
            errors.append(f"{cfg.name}: add a Wi-Fi Station or Access Point profile first.")
        if cfg.profile_type in {"mqtt_client", "http_get", "ntp_sync", "ota_update"} and not any(c.profile_type == "wifi_sta" for c in configs):
            errors.append(f"{cfg.name}: this feature requires Wi-Fi Station mode, not only an Access Point.")
        if cfg.profile_type == "mqtt_client" and board not in ("esp32", "esp8266"):
            errors.append(f"{cfg.name}: MQTT starter requires native ESP32/ESP8266 Wi-Fi.")
    # Reserve hardware SPI bus lines whenever a generated SPI device is present.
    spi_profiles = [c for c in configs if c.profile_type in ("spi_transfer", "sd_logger", "lora_radio")]
    claimed: dict[str, str] = {}
    uses_i2c = any(c.profile_type == "i2c_scanner" for c in configs) or any(
        getattr(component, "type_id", "") in {"ssd1306_oled", "lcd1602_i2c"}
        for component in project.components
    )
    if uses_i2c:
        i2c_pins = {"uno": (("A4", "shared I2C SDA bus"), ("A5", "shared I2C SCL bus")),
                    "nano": (("A4", "shared I2C SDA bus"), ("A5", "shared I2C SCL bus")),
                    "esp32": (("21", "shared I2C SDA bus"), ("22", "shared I2C SCL bus")),
                    "esp8266": (("4", "shared I2C SDA bus"), ("5", "shared I2C SCL bus"))}.get(board, ())
        for pin, description in i2c_pins:
            claimed[pin] = description
    if spi_profiles:
        bus_pins = {"uno": ("11", "12", "13"), "nano": ("11", "12", "13"), "esp32": ("23", "19", "18"), "esp8266": ("13", "12", "14")}.get(board, ())
        for pin in bus_pins:
            claimed[pin] = "hardware SPI bus (MOSI/MISO/SCK)"
    for component in project.components:
        for pin in component.pins.values():
            normalized = str(pin).upper()
            if normalized in claimed:
                errors.append(f"{component.name}: pin {normalized} is reserved by {claimed[normalized]}.")
            else:
                claimed[normalized] = component.name
    for cfg in configs:
        st = cfg.settings
        pin_keys = ("rx_pin", "tx_pin", "de_pin") if cfg.profile_type == "rs485_half_duplex" else ("rx_pin", "tx_pin") if cfg.profile_type in ("uart_bridge", "hc05_bluetooth", "hm10_ble_uart", "esp8266_at_wifi") else ("cs_pin",) if cfg.profile_type in ("spi_transfer", "sd_logger") else ("cs_pin", "reset_pin", "dio0_pin") if cfg.profile_type == "lora_radio" else ()
        for key in pin_keys:
            pin = str(st.get(key, "")).upper()
            if pin in claimed:
                errors.append(f"{cfg.name}: pin {pin} is already assigned to {claimed[pin]} or another connectivity profile.")
            else:
                claimed[pin] = cfg.name
    return errors


def required_connectivity_libraries(project) -> list[tuple[str, str, str, str]]:
    """(name, include, source_url, notes) dependencies automatically recorded."""
    found = {item.profile_type for item in project.communications}
    result = []
    if "mqtt_client" in found:
        result.append(("PubSubClient", "#include <PubSubClient.h>", "https://github.com/knolleary/pubsubclient", "MQTT client. Requires an ESP32/ESP8266 Wi-Fi profile."))
    if "lora_radio" in found:
        result.append(("LoRa", "#include <LoRa.h>", "https://github.com/sandeepmistry/arduino-LoRa", "SX1276/77/78/79 radio driver. Check module frequency, antenna and local radio regulations."))
    return result


def _sym(value: str) -> str:
    out = re.sub(r"[^A-Za-z0-9_]", "_", value)
    if not out or out[0].isdigit():
        out = "mc_" + out
    return "mc_" + out


def _q(value: Any) -> str:
    text = str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\r", " ").replace("\n", " ")
    return f'"{text}"'


def generate_connectivity_sections(project) -> dict[str, list[str]]:
    """Return include/global/setup/helper/loop lines for configured adapters."""
    result = {key: [] for key in ("includes", "globals", "helpers", "setup", "loop")}
    board = project.board_id
    has_wifi = any(c.profile_type in ("wifi_sta", "wifi_ap") for c in project.communications)
    if has_wifi or any(c.profile_type in ("mqtt_client", "ota_update") for c in project.communications):
        result["globals"].append("// SECURITY: credentials below are embedded in source and project JSON. Do not publish this sketch with real secrets.")
    for cfg in project.communications:
        kind, st = cfg.profile_type, cfg.settings
        s = _sym(cfg.id)
        if kind in ("uart_bridge", "hc05_bluetooth", "hm10_ble_uart"):
            baud = _as_int(st, "baud", 9600)
            rx, tx = str(st.get("rx_pin", "10")), str(st.get("tx_pin", "11"))
            if board in ("uno", "nano", "esp8266"):
                result["includes"].append("#include <SoftwareSerial.h>")
                result["globals"].append(f"SoftwareSerial {s}_serial({rx}, {tx});")
                result["setup"].append(f"{s}_serial.begin({baud});")
            else:
                result["globals"].append(f"HardwareSerial {s}_serial(2);")
                result["setup"].append(f"{s}_serial.begin({baud}, SERIAL_8N1, {rx}, {tx});")
            result["loop"].extend([
                f"while ({s}_serial.available()) Serial.write({s}_serial.read());",
                f"while (Serial.available()) {s}_serial.write(Serial.read());",
            ])
        elif kind == "rs485_half_duplex":
            baud = _as_int(st, "baud", 9600)
            rx, tx, de = str(st.get("rx_pin", "10")), str(st.get("tx_pin", "11")), str(st.get("de_pin", "4"))
            if board in ("uno", "nano", "esp8266"):
                result["includes"].append("#include <SoftwareSerial.h>")
                result["globals"].append(f"SoftwareSerial {s}_serial({rx}, {tx});")
            else:
                result["globals"].append(f"HardwareSerial {s}_serial(2);")
            result["setup"].extend([f"pinMode({de}, OUTPUT);", f"digitalWrite({de}, LOW); // Receive mode", f"{s}_serial.begin({baud});" if board in ("uno", "nano", "esp8266") else f"{s}_serial.begin({baud}, SERIAL_8N1, {rx}, {tx});"])
            result["loop"].extend([
                f"while ({s}_serial.available()) Serial.write({s}_serial.read());",
                f"if (Serial.available()) {{ digitalWrite({de}, HIGH); while (Serial.available()) {s}_serial.write(Serial.read()); {s}_serial.flush(); digitalWrite({de}, LOW); }}",
            ])
        elif kind == "esp8266_at_wifi":
            result["includes"].append("#include <SoftwareSerial.h>")
            result["globals"].append(f"SoftwareSerial {s}_modem({st.get('rx_pin', '10')}, {st.get('tx_pin', '11')});")
            result["helpers"].extend([
                f"bool {s}_sendAT(const char* command, const char* expected, unsigned long timeoutMs) {{",
                f"  while ({s}_modem.available()) {s}_modem.read();",
                f"  {s}_modem.println(command);",
                "  unsigned long started = millis();",
                "  String response;",
                f"  while ((unsigned long)(millis() - started) < timeoutMs) {{ while ({s}_modem.available()) {{ char ch = (char){s}_modem.read(); response += ch; Serial.write(ch); if (response.indexOf(expected) >= 0) return true; if (response.indexOf(\"ERROR\") >= 0) return false; }} }}",
                "  return false;", "}",
            ])
            result["setup"].extend([
                f"{s}_modem.begin({_as_int(st, 'baud', 9600)});",
                f"Serial.println(F(\"ESP8266 AT modem: checking firmware\"));",
                f"if (!{s}_sendAT(\"AT\", \"OK\", 2000)) Serial.println(F(\"No AT response. Check baud, wiring and ESP-AT firmware.\"));",
                f"{s}_sendAT(\"ATE0\", \"OK\", 1000);",
                f"{s}_sendAT(\"AT+CWMODE=1\", \"OK\", 2000);",
                f"String {s}_join = String(\"AT+CWJAP=\\\"\") + {_q(st.get('ssid', 'YOUR_WIFI_NAME'))} + \"\\\",\\\"\" + {_q(st.get('password', 'YOUR_WIFI_PASSWORD'))} + \"\\\"\";",
                f"if (!{s}_sendAT({s}_join.c_str(), \"OK\", 20000)) Serial.println(F(\"Wi-Fi join failed; check credentials and module firmware.\"));",
            ])
        elif kind == "esp32_bt_spp":
            result["includes"].append("#include <BluetoothSerial.h>")
            result["globals"].append(f"BluetoothSerial {s}_bt;")
            result["setup"].append(f"if (!{s}_bt.begin({_q(st.get('device_name', 'MixerCode'))})) Serial.println(F(\"Bluetooth SPP start failed\"));")
            result["loop"].extend([f"while ({s}_bt.available()) Serial.write({s}_bt.read());", f"while (Serial.available()) {s}_bt.write(Serial.read());"])
        elif kind in ("wifi_sta", "wifi_ap"):
            result["includes"].append("#include <ESP8266WiFi.h>" if board == "esp8266" else "#include <WiFi.h>")
            result["globals"].append(f"const char* {s}_ssid = {_q(st.get('ssid', 'YOUR_WIFI_NAME'))};")
            result["globals"].append(f"const char* {s}_password = {_q(st.get('password', 'YOUR_WIFI_PASSWORD'))};")
            if kind == "wifi_sta":
                result["globals"].append(f"unsigned long {s}_last_retry_ms = 0;")
                result["setup"].extend(["WiFi.mode(WIFI_STA);", f"WiFi.begin({s}_ssid, {s}_password);", "Serial.println(F(\"Wi-Fi station connection started (non-blocking).\"));"])
                result["loop"].extend([
                    f"if (WiFi.status() == WL_CONNECTED) {{ /* Connected */ }} else if ((unsigned long)(millis() - {s}_last_retry_ms) >= 10000UL) {{",
                    f"  {s}_last_retry_ms = millis(); WiFi.begin({s}_ssid, {s}_password);",
                    "}",
                ])
            else:
                result["setup"].extend(["WiFi.mode(WIFI_AP);", f"if (!WiFi.softAP({s}_ssid, {s}_password)) Serial.println(F(\"Wi-Fi AP start failed\"));", "Serial.print(F(\"AP IP: \")); Serial.println(WiFi.softAPIP());"])
        elif kind == "mqtt_client":
            result["includes"].append("#include <PubSubClient.h>")
            result["globals"].extend([f"WiFiClient {s}_net;", f"PubSubClient {s}_mqtt({s}_net);", f"unsigned long {s}_last_connect_ms = 0;", f"const char* {s}_sub_topic = {_q(st.get('subscribe_topic', 'mixercode/in'))};", f"const char* {s}_pub_topic = {_q(st.get('publish_topic', 'mixercode/out'))};"])
            mqtt_client_id = _q(st.get("client_id", "MixerCodeDevice"))
            mqtt_username = str(st.get("username", "")).strip()
            if mqtt_username:
                mqtt_connect_call = f"{s}_mqtt.connect({mqtt_client_id}, {_q(mqtt_username)}, {_q(st.get('password', ''))})"
            else:
                mqtt_connect_call = f"{s}_mqtt.connect({mqtt_client_id})"
            result["helpers"].extend([
                f"void {s}_callback(char* topic, byte* payload, unsigned int length) {{",
                "  Serial.print(F(\"MQTT [\")); Serial.print(topic); Serial.print(F(\"] \"));",
                "  for (unsigned int i = 0; i < length; ++i) Serial.write(payload[i]); Serial.println();", "}",
                f"bool {s}_publish(const char* message) {{ return {s}_mqtt.connected() && {s}_mqtt.publish({s}_pub_topic, message); }}",
                f"void {s}_tick() {{",
                f"  if (WiFi.status() != WL_CONNECTED) return;",
                f"  if (!{s}_mqtt.connected()) {{",
                f"    if ((unsigned long)(millis() - {s}_last_connect_ms) >= {_as_int(st, 'reconnect_ms', 5000)}UL) {{",
                f"      {s}_last_connect_ms = millis();",
                f"      if ({mqtt_connect_call}) {{",
                f"        if (strlen({s}_sub_topic)) {s}_mqtt.subscribe({s}_sub_topic);",
                f"        {s}_mqtt.publish({s}_pub_topic, \"Mixer Code online\");",
                "      }", "    }", "  } else {", f"    {s}_mqtt.loop();", "  }", "}",
            ])
            result["setup"].extend([f"{s}_mqtt.setServer({_q(st.get('host', 'broker.hivemq.com'))}, {_as_int(st, 'port', 1883)});", f"{s}_mqtt.setCallback({s}_callback);", f"{s}_mqtt.setSocketTimeout(2);"])
            result["loop"].append(f"{s}_tick();")
        elif kind == "http_get":
            result["includes"].extend([
                "#include <ESP8266HTTPClient.h>" if board == "esp8266" else "#include <HTTPClient.h>",
                "#include <WiFiClient.h>",
            ])
            result["globals"].extend([
                f"WiFiClient {s}_http_client;",
                f"unsigned long {s}_last_request_ms = 0;",
            ])
            result["helpers"].extend([
                f"void {s}_tick() {{",
                f"  if (WiFi.status() != WL_CONNECTED) return;",
                f"  if ((unsigned long)(millis() - {s}_last_request_ms) < {_as_int(st, 'interval_ms', 30000)}UL) return;",
                f"  {s}_last_request_ms = millis();",
                "  HTTPClient http;", "  http.setConnectTimeout(3000); http.setTimeout(3000);",
                f"  if (http.begin({s}_http_client, {_q(st.get('url', 'http://example.com/'))})) {{",
                (f"    int code = http.GET();" if str(st.get("method", "GET")).upper() == "GET" else
                 f"    int code = http.POST(String({_q(st.get('payload', ''))}));" if str(st.get("method", "GET")).upper() == "POST" else
                 f"    String body = {_q(st.get('payload', ''))}; int code = http.sendRequest({_q(str(st.get('method', 'GET')).upper())}, (uint8_t*)body.c_str(), body.length());"),
                "    Serial.print(F(\"HTTP status: \")); Serial.println(code);",
                "    if (code > 0) Serial.println(http.getString());",
                "    http.end();", "  }", "}",
            ])
            result["loop"].append(f"{s}_tick();")
        elif kind == "udp_listener":
            result["includes"].append("#include <WiFiUdp.h>")
            result["globals"].append(f"WiFiUDP {s}_udp;")
            result["setup"].append(f"{s}_udp.begin({_as_int(st, 'listen_port', 4210)});")
            result["loop"].extend([
                f"int {s}_packet_size = {s}_udp.parsePacket();",
                f"if ({s}_packet_size > 0) {{ char {s}_buffer[256]; int {s}_n = {s}_udp.read({s}_buffer, sizeof({s}_buffer) - 1); if ({s}_n < 0) {s}_n = 0; {s}_buffer[{s}_n] = '\\0'; Serial.print(F(\"UDP: \")); Serial.println({s}_buffer); }}",
            ])
        elif kind == "web_server":
            if board == "esp8266":
                result["includes"].append("#include <ESP8266WebServer.h>")
            else:
                result["includes"].append("#include <WebServer.h>")
            result["globals"].append(f"{'ESP8266WebServer' if board == 'esp8266' else 'WebServer'} {s}_server({_as_int(st, 'port', 80)});")
            result["setup"].extend([
                f"{s}_server.on(\"/\", []() {{ {s}_server.send(200, \"text/plain\", \"Mixer Code device online\"); }});",
                f"{s}_server.on(\"/status\", []() {{ {s}_server.send(200, \"application/json\", \"{{\\\"status\\\":\\\"online\\\"}}\"); }});",
                f"{s}_server.begin(); Serial.println(F(\"HTTP status server started\"));",
            ])
            result["loop"].append(f"{s}_server.handleClient();")
        elif kind == "ntp_sync":
            result["includes"].append("#include <time.h>")
            result["globals"].append(f"unsigned long {s}_last_report_ms = 0;")
            result["setup"].append(f"configTime({_as_int(st, 'utc_offset_seconds', 19800)}, {_as_int(st, 'daylight_offset_seconds', 0)}, \"pool.ntp.org\", \"time.nist.gov\");")
            result["loop"].extend([
                f"if ((unsigned long)(millis() - {s}_last_report_ms) >= {_as_int(st, 'interval_ms', 60000)}UL) {{",
                f"  {s}_last_report_ms = millis(); time_t {s}_now = time(nullptr);",
                f"  if ({s}_now > 100000) {{ char {s}_time_text[32]; struct tm {s}_time_info; localtime_r(&{s}_now, &{s}_time_info); strftime({s}_time_text, sizeof({s}_time_text), \"%Y-%m-%d %H:%M:%S\", &{s}_time_info); Serial.println({s}_time_text); }} else Serial.println(F(\"NTP time not synchronized yet\"));",
                "}",
            ])
        elif kind == "wifi_scan":
            result["includes"].append("#include <ESP8266WiFi.h>" if board == "esp8266" else "#include <WiFi.h>")
            result["setup"].extend(["WiFi.mode(WIFI_STA);", "Serial.println(F(\"Scanning Wi-Fi networks...\"));", "int networkCount = WiFi.scanNetworks();", "if (networkCount < 0) Serial.println(F(\"Wi-Fi scan failed\"));", "for (int i = 0; i < networkCount; ++i) { Serial.print(WiFi.SSID(i)); Serial.print(F(\" RSSI=\")); Serial.print(WiFi.RSSI(i)); Serial.println(F(\" dBm\")); }", "WiFi.scanDelete();"])
        elif kind == "lora_radio":
            result["includes"].append("#include <LoRa.h>")
            cs, reset, dio0 = (str(st.get(k, d)) for k, d in (("cs_pin", "10"), ("reset_pin", "9"), ("dio0_pin", "2")))
            result["globals"].extend([
                f"unsigned long {s}_last_tx_ms = 0;",
                f"volatile bool {s}_tx_ready = true;",
                f"bool {s}_radio_ready = false;",
            ])
            result["helpers"].append(f"void {s}_tx_done_callback() {{ {s}_tx_ready = true; }}")
            result["setup"].extend([
                f"LoRa.setPins({cs}, {reset}, {dio0});",
                f"if (!LoRa.begin({float(st.get('frequency_mhz', '866.0')):.3f}E6)) Serial.println(F(\"LoRa init failed: check power, wiring, frequency and module\")); else {{ LoRa.onTxDone({s}_tx_done_callback); {s}_radio_ready = true; Serial.println(F(\"LoRa radio ready\")); }}",
            ])
            result["loop"].extend([
                f"if ({s}_radio_ready && {s}_tx_ready) {{",
                f"  int {s}_packet_size = LoRa.parsePacket();",
                f"  if ({s}_packet_size) {{ Serial.print(F(\"LoRa RX: \")); while (LoRa.available()) Serial.write((uint8_t)LoRa.read()); Serial.print(F(\" | RSSI=\")); Serial.println(LoRa.packetRssi()); }}",
                f"  if ((unsigned long)(millis() - {s}_last_tx_ms) >= {_as_int(st, 'interval_ms', 10000)}UL) {{",
                f"    if (LoRa.beginPacket()) {{ LoRa.print({_q(st.get('node_message', 'Mixer Code node online'))}); {s}_tx_ready = false; {s}_last_tx_ms = millis(); if (!LoRa.endPacket(true)) {s}_tx_ready = true; }}",
                "  }", "}",
            ])
        elif kind == "ota_update":
            result["includes"].append("#include <ArduinoOTA.h>")
            result["globals"].append(f"bool {s}_started = false;")
            result["setup"].extend([f"ArduinoOTA.setHostname({_q(st.get('hostname', 'mixer-coder-device'))});", f"ArduinoOTA.setPassword({_q(st.get('password', 'change-this-password'))});"])
            result["loop"].extend([f"if (WiFi.status() == WL_CONNECTED && !{s}_started) {{ ArduinoOTA.begin(); {s}_started = true; Serial.println(F(\"OTA ready on local network\")); }}", f"if ({s}_started) ArduinoOTA.handle();"])
        elif kind == "i2c_scanner":
            result["includes"].append("#include <Wire.h>")
            result["setup"].extend([
                "Serial.println(F(\"I2C scan start\"));",
                "for (uint8_t address = 1; address < 127; ++address) { Wire.beginTransmission(address); uint8_t error = Wire.endTransmission(); if (error == 0) { Serial.print(F(\"I2C device: 0x\")); if (address < 16) Serial.print('0'); Serial.println(address, HEX); } }",
                "Serial.println(F(\"I2C scan complete\"));",
            ])
        elif kind == "spi_transfer":
            result["includes"].append("#include <SPI.h>")
            cs = str(st.get("cs_pin", "10"))
            result["globals"].append(f"unsigned long {s}_last_ms = 0;")
            result["helpers"].append(f"uint8_t {s}_transfer(uint8_t value) {{ SPI.beginTransaction(SPISettings({_as_int(st, 'clock_hz', 1000000)}UL, MSBFIRST, SPI_MODE0)); digitalWrite({cs}, LOW); uint8_t received = SPI.transfer(value); digitalWrite({cs}, HIGH); SPI.endTransaction(); return received; }}")
            result["setup"].extend(["SPI.begin();", f"pinMode({cs}, OUTPUT); digitalWrite({cs}, HIGH);"])
            result["loop"].extend([f"if ((unsigned long)(millis() - {s}_last_ms) >= {_as_int(st, 'interval_ms', 1000)}UL) {{ {s}_last_ms = millis(); uint8_t response = {s}_transfer({_as_int(st, 'tx_byte', 0)}); Serial.print(F(\"SPI RX: \")); Serial.println(response); }}"])
        elif kind == "sd_logger":
            result["includes"].extend(["#include <SPI.h>", "#include <SD.h>"])
            cs = str(st.get("cs_pin", "10"))
            filename = str(st.get("file_name", "mixer.csv"))
            result["globals"].append(f"unsigned long {s}_last_log_ms = 0;")
            result["setup"].extend([f"if (!SD.begin({cs})) Serial.println(F(\"SD card initialization failed\")); else {{ File f = SD.open({_q(filename)}, FILE_WRITE); if (f) {{ if (f.size() == 0) f.println(F(\"uptime_ms\")); f.close(); }} }}"])
            result["loop"].extend([
                f"if ((unsigned long)(millis() - {s}_last_log_ms) >= {_as_int(st, 'interval_ms', 1000)}UL) {{",
                f"  {s}_last_log_ms = millis(); File f = SD.open({_q(filename)}, FILE_WRITE); if (f) {{ f.println(millis()); f.close(); }} else Serial.println(F(\"SD log open failed\"));", "}",
            ])
    return result
