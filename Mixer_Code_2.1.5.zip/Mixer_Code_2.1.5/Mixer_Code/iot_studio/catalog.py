"""Data-driven component catalog for Mixer Code."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ComponentSpec:
    type_id: str
    display_name: str
    category: str
    kind: str  # digital_input, analog_input, distance_input, digital_output, servo_output, display_output
    description: str
    pins: tuple[str, ...]
    pin_modes: tuple[str, ...]
    default_active_level: str = "HIGH"
    generator: str = "core"
    aliases: tuple[str, ...] = ()


COMPONENTS: dict[str, ComponentSpec] = {
    "touch_sensor": ComponentSpec("touch_sensor", "Capacitive Touch Sensor", "Basic Inputs", "digital_input", "Digital touch module such as TTP223.", ("signal",), ("INPUT",), aliases=("touch", "touchsensor", "ttp223")),
    "push_button": ComponentSpec("push_button", "Push Button", "Basic Inputs", "digital_input", "Momentary button. Uses INPUT_PULLUP by default.", ("signal",), ("INPUT_PULLUP",), "LOW", aliases=("button", "switch", "pushbutton")),
    "pir_sensor": ComponentSpec("pir_sensor", "PIR Motion Sensor", "Basic Inputs", "digital_input", "Digital motion-detection output.", ("signal",), ("INPUT",), aliases=("pir", "motion", "motionsensor")),
    "flame_sensor": ComponentSpec("flame_sensor", "Flame Sensor", "Safety Inputs", "digital_input", "Digital flame output. Default active level is configurable in the project file.", ("signal",), ("INPUT",), "LOW", aliases=("flame", "firesensor")),
    "ldr": ComponentSpec("ldr", "LDR Light Sensor", "Analog Inputs", "analog_input", "Analog light-level reading. Use a voltage-divider module.", ("signal",), ("INPUT",), aliases=("light", "lightsensor", "ldrmodule")),
    "mq_gas": ComponentSpec("mq_gas", "MQ Gas Sensor", "Analog Inputs", "analog_input", "Analog gas-level reading. Calibration and warm-up are application-specific.", ("signal",), ("INPUT",), aliases=("mq2", "mq135", "gassensor", "gas")),
    "soil_moisture": ComponentSpec("soil_moisture", "Soil Moisture Sensor", "Analog Inputs", "analog_input", "Analog output from a soil-moisture module.", ("signal",), ("INPUT",), aliases=("soil", "moisture", "moisturesensor")),
    "sound_sensor": ComponentSpec("sound_sensor", "Sound Sensor", "Analog Inputs", "analog_input", "Analog sound-level module. Threshold depends on the module and environment.", ("signal",), ("INPUT",), aliases=("sound", "mic", "microphone")),
    "rain_sensor_analog": ComponentSpec("rain_sensor_analog", "Rain Sensor (Analog)", "Environmental Inputs", "analog_input", "Analog output from a rain sensor board. Values are raw ADC readings and depend on module calibration.", ("signal",), ("INPUT",), aliases=("rain analog", "rain level", "raindrop analog")),
    "water_level": ComponentSpec("water_level", "Water Level Sensor", "Environmental Inputs", "analog_input", "Analog water-level probe/module. Values are raw ADC readings; calibrate against your tank geometry.", ("signal",), ("INPUT",), aliases=("water level", "waterlevel", "water depth")),
    "lm35": ComponentSpec("lm35", "LM35 Temperature Sensor", "Environmental Inputs", "analog_input", "Analog temperature sensor. The generator reports raw ADC counts; convert to degrees using the board reference voltage and calibration.", ("signal",), ("INPUT",), aliases=("lm 35", "analog temperature")),
    "ntc_thermistor": ComponentSpec("ntc_thermistor", "NTC Thermistor Module", "Environmental Inputs", "analog_input", "Analog thermistor divider output. Raw ADC values require a resistance/temperature conversion for degrees.", ("signal",), ("INPUT",), aliases=("thermistor", "ntc", "temperature thermistor")),
    "fsr": ComponentSpec("fsr", "Force Sensitive Resistor (FSR)", "Measurement Inputs", "analog_input", "Analog force/pressure response. Output is a raw ADC value and is not a calibrated force measurement.", ("signal",), ("INPUT",), aliases=("force sensor", "pressure pad", "fsr sensor")),
    "flex_sensor": ComponentSpec("flex_sensor", "Flex Sensor", "Measurement Inputs", "analog_input", "Analog resistance-divider output from a flex sensor. Raw ADC only; calibrate for bend angle if needed.", ("signal",), ("INPUT",), aliases=("bend sensor", "flex")),
    "voltage_sensor": ComponentSpec("voltage_sensor", "Voltage Sensor Module", "Measurement Inputs", "analog_input", "Analog divider output. Convert raw ADC counts using your module ratio and board reference voltage.", ("signal",), ("INPUT",), aliases=("voltage divider", "voltage monitor")),
    "joystick_axis": ComponentSpec("joystick_axis", "Joystick Axis (X or Y)", "Control Inputs", "analog_input", "One analog axis output from a joystick module. Add a separate component for the other axis.", ("signal",), ("INPUT",), aliases=("joystick x", "joystick y", "analog joystick")),
    "ir_obstacle": ComponentSpec("ir_obstacle", "IR Obstacle Detection Module", "Digital Detection Inputs", "digital_input", "Digital obstacle output. Many modules are active LOW; verify the module's DO polarity and change active level if needed.", ("signal",), ("INPUT",), "LOW", aliases=("ir obstacle", "infrared obstacle", "obstacle sensor")),
    "line_tracking": ComponentSpec("line_tracking", "IR Line Tracking Sensor", "Digital Detection Inputs", "digital_input", "Digital line-detection output. Sensor polarity varies by board; active level is configurable.", ("signal",), ("INPUT",), "LOW", aliases=("line tracker", "line tracking", "ir line sensor")),
    "vibration_sensor": ComponentSpec("vibration_sensor", "SW-420 Vibration Sensor", "Digital Detection Inputs", "digital_input", "Digital vibration event output. Many SW-420 modules idle HIGH and pulse LOW; verify the module polarity.", ("signal",), ("INPUT",), "LOW", aliases=("sw420", "sw-420", "vibration", "vibration module")),
    "tilt_switch": ComponentSpec("tilt_switch", "Tilt / Ball Switch", "Digital Detection Inputs", "digital_input", "Simple tilt switch. Uses INPUT_PULLUP and treats a closed-to-ground contact as active by default.", ("signal",), ("INPUT_PULLUP",), "LOW", aliases=("tilt sensor", "ball switch")),
    "reed_switch": ComponentSpec("reed_switch", "Magnetic Reed Switch", "Digital Detection Inputs", "digital_input", "Magnet-operated contact. Uses INPUT_PULLUP and treats a closed-to-ground contact as active by default.", ("signal",), ("INPUT_PULLUP",), "LOW", aliases=("magnetic switch", "door magnetic sensor", "reed sensor")),
    "limit_switch": ComponentSpec("limit_switch", "Mechanical Limit Switch", "Digital Detection Inputs", "digital_input", "End-stop/limit switch. Uses INPUT_PULLUP; wire the switch between signal and GND.", ("signal",), ("INPUT_PULLUP",), "LOW", aliases=("end stop", "endstop", "microswitch", "limit sensor")),
    "rain_sensor_digital": ComponentSpec("rain_sensor_digital", "Rain Sensor (Digital)", "Digital Detection Inputs", "digital_input", "Digital rain threshold output from the module comparator. Adjust the module trimmer and verify active polarity.", ("signal",), ("INPUT",), "LOW", aliases=("rain digital", "rain detected")),
    "water_leak_sensor": ComponentSpec("water_leak_sensor", "Water Leak Detection Module", "Digital Detection Inputs", "digital_input", "Digital leak-detection output. Check whether the selected module asserts HIGH or LOW when wet.", ("signal",), ("INPUT",), "HIGH", aliases=("leak sensor", "water leak", "water detector")),
    "sound_sensor_digital": ComponentSpec("sound_sensor_digital", "Sound Sensor (Digital)", "Digital Detection Inputs", "digital_input", "Digital sound-trigger output from an onboard comparator. Adjust its trimmer and verify polarity.", ("signal",), ("INPUT",), "LOW", aliases=("sound trigger", "sound detected", "clap sensor")),
    "potentiometer": ComponentSpec("potentiometer", "Potentiometer", "Analog Inputs", "analog_input", "Analog control input.", ("signal",), ("INPUT",), aliases=("pot", "knob")),
    "hc_sr04": ComponentSpec("hc_sr04", "HC-SR04 Ultrasonic", "Distance Sensors", "distance_input", "Measures distance in centimetres using TRIG and ECHO. For ESP32, level-shift the 5V Echo signal.", ("trig", "echo"), ("OUTPUT", "INPUT"), aliases=("ultrasonic", "distance", "hcsr04")),
    "led": ComponentSpec("led", "LED", "Basic Outputs", "digital_output", "Digital LED output. Add a suitable current-limiting resistor.", ("signal",), ("OUTPUT",), aliases=("light", "lamp")),
    "buzzer": ComponentSpec("buzzer", "Buzzer", "Basic Outputs", "digital_output", "Active buzzer digital output. Passive buzzers need tone/frequency control.", ("signal",), ("OUTPUT",), aliases=("beeper",)),
    "relay": ComponentSpec("relay", "Relay Module", "Power Outputs", "digital_output", "Relay control output. Check module polarity and load ratings.", ("signal",), ("OUTPUT",), aliases=("relaymodule",)),
    "servo": ComponentSpec("servo", "Servo Motor", "Motion Outputs", "servo_output", "Servo position output, 0 to 180 degrees. Uses Servo on Uno/Nano and ESP32Servo on ESP32.", ("signal",), ("SERVO",), aliases=("servomotor",)),
    "ssd1306_oled": ComponentSpec("ssd1306_oled", "SSD1306 OLED 128x64 (I2C)", "Displays", "display_output", "Supported 128x64 I2C OLED. Uses Adafruit SSD1306 + Adafruit GFX libraries. Default address 0x3C.", (), (), aliases=("oled", "ssd1306", "oleddisplay")),
    "lcd1602_i2c": ComponentSpec("lcd1602_i2c", "LCD 16x2 (I2C)", "Displays", "display_output", "Supported 16x2 I2C character LCD. Uses the hd44780 library with I2Cexp support. Default address 0x27.", (), (), aliases=("lcd", "1602", "lcd1602", "i2clcd")),
}

# Devices without a tested built-in adapter remain available through Custom Components.
PLANNED_COMPONENTS: tuple[dict[str, Any], ...] = (
    {"name": "DHT11 / DHT22", "category": "Environmental", "note": "Use Custom Components or add a tested typed adapter."},
    {"name": "MPU6050", "category": "Motion & Orientation", "note": "Use Custom Components or add a tested typed adapter."},
    {"name": "MAX30102", "category": "Health & Optical", "note": "Use Custom Components or add a tested typed adapter."},
    {"name": "SH1106 OLED", "category": "Displays", "note": "Use a custom U8g2 adapter; SSD1306 OLED is built in."},
    {"name": "HX711 Load Cell", "category": "Measurement", "note": "Use Custom Components or add a tested typed adapter."},
    {"name": "DS18B20", "category": "Environmental", "note": "Use Custom Components or add a tested typed adapter."},
)


def list_components() -> list[ComponentSpec]:
    return list(COMPONENTS.values())


def normalize(value: str) -> str:
    return "".join(ch.lower() for ch in value if ch.isalnum())
