"""Extract Arduino integration sketches from pasted code or README documents.

The importer deliberately extracts one primary sketch. It does not execute,
compile, or trust pasted code. Markdown prose and repeated copies of the same
sketch are discarded; extracted sections are shown for user review before save.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from html import unescape
from pathlib import Path
import re
from typing import Iterable


@dataclass
class IntegrationExtraction:
    title: str
    includes: str
    declarations: str
    setup_code: str
    loop_code: str
    warnings: list[str]
    source_url: str = ""
    candidate_count: int = 0
    duplicate_count: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


_FENCE_RE = re.compile(
    r"(?ms)^[ \t]*(?P<mark>`{3,}|~{3,})[^\n]*\n(?P<body>.*?)(?:^[ \t]*(?P=mark)[ \t]*$)",
)
_HEADING_RE = re.compile(r"^\s*#{1,6}\s+.+$", re.M)
_INCLUDE_RE = re.compile(r"^\s*#\s*include\s*[<\"][^>\"]+[>\"]\s*$", re.M)


def normalize_pasted_text(raw: str) -> str:
    """Normalize common HTML/Markdown escaped clipboard content."""
    text = unescape(raw or "")
    text = text.replace("\ufeff", "").replace("\u200b", "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Some rich-text sources escape Markdown punctuation and angle brackets.
    text = re.sub(r"(?m)^(\s*)\\(?=#)", r"\1", text)
    text = re.sub(r"\\([<>])", r"\1", text)
    text = text.replace("\\|", "|").replace("\\`", "`")
    # A few chat/export formats append a literal backslash to every line.
    lines = text.split("\n")
    nonempty = [line for line in lines if line.strip()]
    slash_lines = sum(1 for line in nonempty if line.rstrip().endswith("\\"))
    if nonempty and slash_lines / len(nonempty) >= 0.60:
        lines = [re.sub(r"\\\s*$", "", line) for line in lines]
        text = "\n".join(lines)
    # Convert HTML non-breaking spaces and normalise indentation entities.
    text = text.replace("\xa0", " ")
    return text.strip()


def _mask_comments_and_strings(code: str) -> str:
    """Return same-length code with comments and quoted strings masked."""
    out = list(code)
    i = 0
    state = "normal"
    while i < len(code):
        ch = code[i]
        nxt = code[i + 1] if i + 1 < len(code) else ""
        if state == "line_comment":
            if ch == "\n":
                state = "normal"
            else:
                out[i] = " "
        elif state == "block_comment":
            if ch == "*" and nxt == "/":
                out[i] = out[i + 1] = " "
                state = "normal"
                i += 1
            elif ch != "\n":
                out[i] = " "
        elif state in ("string", "char"):
            if ch == "\\":
                if ch != "\n":
                    out[i] = " "
                if i + 1 < len(code):
                    if code[i + 1] != "\n":
                        out[i + 1] = " "
                    i += 1
            elif (state == "string" and ch == '"') or (state == "char" and ch == "'"):
                out[i] = " "
                state = "normal"
            elif ch != "\n":
                out[i] = " "
        else:
            if ch == "/" and nxt == "/":
                out[i] = out[i + 1] = " "
                state = "line_comment"
                i += 1
            elif ch == "/" and nxt == "*":
                out[i] = out[i + 1] = " "
                state = "block_comment"
                i += 1
            elif ch == '"':
                out[i] = " "
                state = "string"
            elif ch == "'":
                out[i] = " "
                state = "char"
        i += 1
    return "".join(out)


def _matching_brace(code: str, masked: str, opening: int) -> int | None:
    depth = 0
    for i in range(opening, len(masked)):
        ch = masked[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return i + 1
    return None


def _find_function_spans(code: str, name: str) -> list[tuple[int, int]]:
    """Find complete void setup()/loop() definitions, respecting comments."""
    masked = _mask_comments_and_strings(code)
    pattern = re.compile(r"\bvoid\s+" + re.escape(name) + r"\s*\(\s*(?:void\s*)?\)\s*\{", re.I)
    spans: list[tuple[int, int]] = []
    for match in pattern.finditer(masked):
        opening = masked.find("{", match.start(), match.end())
        end = _matching_brace(code, masked, opening)
        if end is not None:
            spans.append((match.start(), end))
    return spans


def _function_body(code: str, span: tuple[int, int]) -> str:
    start, end = span
    opening = code.find("{", start, end)
    if opening < 0:
        return ""
    body = code[opening + 1:end - 1].strip("\r\n")
    lines = body.splitlines()
    positive_indents = [
        len(line) - len(line.lstrip(" \t"))
        for line in lines if line.strip() and line[:1] in (" ", "\t")
    ]
    common_indent = min(positive_indents) if positive_indents else 0
    if common_indent:
        lines = [line[common_indent:] if line.strip() and len(line) - len(line.lstrip(" \t")) >= common_indent else line for line in lines]
    return "\n".join(lines).strip()


def _strip_markdown_outer_text(text: str) -> str:
    """Prefer the raw preamble before README headings; otherwise keep code."""
    heading = _HEADING_RE.search(text)
    if heading:
        prefix = text[:heading.start()].strip()
        if re.search(r"\bvoid\s+(?:setup|loop)\s*\(", _mask_comments_and_strings(prefix), re.I):
            return prefix
    return text.strip()


def _candidate_blocks(text: str) -> list[str]:
    candidates: list[str] = []
    fences = list(_FENCE_RE.finditer(text))
    if fences:
        # A raw complete sketch may precede the README (as in copied GitHub pages).
        prefix = text[:fences[0].start()].strip()
        if prefix:
            prefix = _strip_markdown_outer_text(prefix)
            if _looks_like_cpp(prefix):
                candidates.append(prefix)
        for match in fences:
            body = match.group("body").strip()
            info_line = text[match.start():match.start() + 100].split("\n", 1)[0]
            language = info_line.lstrip(" `~").split(None, 1)[0].lower() if info_line.strip(" `~") else ""
            if language in {"text", "txt", "bash", "sh", "shell", "json", "yaml", "yml", "ini", "diff"}:
                continue
            if _looks_like_cpp(body):
                candidates.append(body)
    else:
        raw = _strip_markdown_outer_text(text)
        if _looks_like_cpp(raw):
            candidates.append(raw)

    # De-duplicate exact candidates while preserving order.
    result: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        canonical = re.sub(r"\s+", " ", candidate).strip()
        if canonical and canonical not in seen:
            seen.add(canonical)
            result.append(candidate)
    return result


def _looks_like_cpp(text: str) -> bool:
    masked = _mask_comments_and_strings(text)
    return bool(re.search(
        r"#\s*include\b|\bvoid\s+(?:setup|loop)\s*\(|\b(?:Serial|Wire|SPI)\s*\.|\b(?:pinMode|digitalRead|digitalWrite|analogRead)\s*\(|\b[A-Za-z_]\w*\s+\w+\s*(?:\([^;]*\))?\s*;",
        masked,
        re.I,
    ))


def _clean_candidate(code: str) -> str:
    text = code.strip()
    # Remove any accidentally retained fence markers and standalone README separators.
    text = re.sub(r"(?m)^\s*```[^\n]*$", "", text)
    text = re.sub(r"(?m)^\s*---+\s*$", "", text)
    return text.strip()


def _looks_like_cpp_global_line(line: str) -> bool:
    """Filter obvious README prose while preserving ordinary global C++ lines."""
    stripped = line.strip()
    if not stripped:
        return True
    if stripped.startswith(("//", "/*", "*", "*/", "#")):
        return True
    if stripped in {"---", "***", "___"}:
        return False
    if stripped.startswith(("|", "- ", "* ", "+ ")):
        return False
    if re.match(r"^\d+[.)]\s+", stripped):
        return False
    lowered = stripped.casefold()
    if lowered in {"connections", "code", "troubleshooting", "setup instructions", "license", "how to use", "table of contents"}:
        return False
    if lowered.startswith(("this repository", "this guide", "the mpu", "the sensor", "below is", "let me know", "replace ", "save this", "commit and", "for more", "table of contents", "connections", "troubleshooting", "setup instructions", "license")):
        return False
    if re.match(r"^(?:class|struct|enum|namespace|template|typedef|extern)\b", stripped):
        return True
    if re.search(r"[;{}()=,*\[\]]", stripped):
        return True
    words = re.findall(r"[A-Za-z_]\w*", stripped)
    # A short type/declaration continuation such as "class Sensor" is kept;
    # paragraph-like natural language is discarded.
    if len(words) <= 3 and not stripped.endswith((".", ":")):
        return True
    return False


def _extract_candidate(code: str) -> tuple[str, str, str, str, int, int, int]:
    code = _clean_candidate(code)
    includes: list[str] = []
    for line in code.splitlines():
        if re.match(r"^\s*#\s*include\b", line):
            clean = re.sub(r"^\s*#\s*include", "#include", line.strip())
            if clean not in includes:
                includes.append(clean)

    setup_spans = _find_function_spans(code, "setup")
    loop_spans = _find_function_spans(code, "loop")
    # Keep the first complete setup()/loop() body, but remove every wrapper
    # from globals so repeated README examples cannot become nested duplicate
    # function definitions in the generated sketch.
    selected_spans: list[tuple[int, int]] = [*setup_spans, *loop_spans]
    setup_body = _function_body(code, setup_spans[0]) if setup_spans else ""
    loop_body = _function_body(code, loop_spans[0]) if loop_spans else ""

    remainder = code
    for start, end in sorted(selected_spans, reverse=True):
        remainder = remainder[:start] + "\n" + remainder[end:]
    remainder = "\n".join(
        line for line in remainder.splitlines()
        if not re.match(r"^\s*#\s*include\b", line)
    ).strip()

    # Anything clearly from README prose should not be stored as C++ declarations.
    remainder_lines: list[str] = []
    for line in remainder.splitlines():
        stripped = line.strip()
        if re.match(r"^#{1,6}\s+", stripped):
            break
        if not _looks_like_cpp_global_line(line):
            continue
        remainder_lines.append(line)
    remainder = "\n".join(remainder_lines).strip()

    # Remove duplicate setup/loop definitions beyond the first. They are not
    # inserted as globals, and a warning will tell the user one sketch was chosen.
    duplicates = max(0, len(setup_spans) - 1) + max(0, len(loop_spans) - 1)
    return ("\n".join(includes), remainder, setup_body, loop_body,
            int(bool(setup_spans)), int(bool(loop_spans)), duplicates)


def _infer_title(code: str, includes: str, fallback: str = "") -> str:
    if fallback.strip():
        return fallback.strip()
    for line in includes.splitlines():
        match = re.search(r"[<\"]([^>\"]+)[>\"]", line)
        if match:
            stem = Path(match.group(1)).stem
            if stem.casefold() not in {"wire", "spi", "arduino", "servo", "softwareserial", "hardwareSerial".casefold()}:
                return stem.replace("_", " ")
    masked = _mask_comments_and_strings(code)
    obj = re.search(r"\b([A-Z][A-Za-z0-9_]*)\s+[a-z_]\w*\s*(?:\([^;]*\))?\s*;", masked)
    if obj:
        return obj.group(1)
    heading = re.search(r"(?m)^#{1,6}\s+(.+)$", code)
    if heading:
        return heading.group(1).strip()
    return "Imported Arduino Component"


def extract_integration_document(raw: str, source_url: str = "", title: str = "") -> IntegrationExtraction:
    """Extract a single Arduino sketch from pasted code, Markdown or README text."""
    text = normalize_pasted_text(raw)
    if not text:
        raise ValueError("Paste an Arduino integration sketch or README document first.")

    candidates = _candidate_blocks(text)
    if not candidates:
        raise ValueError("No recognizable Arduino C++ was found. Paste the complete sketch or a README containing a C++ code block.")

    parsed: list[tuple[tuple[int, int, int, int], str, tuple[str, str, str, str, int, int, int]]] = []
    combined_candidate_text = "\n\n".join(candidates)
    for candidate in candidates:
        inc, decl, setup_body, loop_body, has_setup, has_loop, duplicates = _extract_candidate(candidate)
        score = (
            has_setup + has_loop,
            len(inc.splitlines()),
            len(decl.splitlines()) + len(setup_body.splitlines()) + len(loop_body.splitlines()),
            len(candidate),
        )
        parsed.append((score, candidate, (inc, decl, setup_body, loop_body, has_setup, has_loop, duplicates)))

    # Some READMEs put includes/globals/setup/loop in separate fenced blocks.
    # Merge these only when no individual block already contains both wrappers;
    # this avoids combining unrelated complete examples from a long README.
    if not any(item[2][4] and item[2][5] for item in parsed) and len(candidates) > 1:
        combined = combined_candidate_text
        inc, decl, setup_body, loop_body, has_setup, has_loop, duplicates = _extract_candidate(combined)
        if has_setup or has_loop:
            score = (
                has_setup + has_loop,
                len(inc.splitlines()),
                len(decl.splitlines()) + len(setup_body.splitlines()) + len(loop_body.splitlines()),
                len(combined),
            )
            parsed.append((score, combined, (inc, decl, setup_body, loop_body, has_setup, has_loop, duplicates)))

    # Prefer a complete setup+loop integration, then the richest candidate.
    parsed.sort(key=lambda item: item[0], reverse=True)
    _score, selected_code, data = parsed[0]
    includes, declarations, setup_code, loop_code, has_setup, has_loop, duplicate_count = data

    if not any((includes.strip(), declarations.strip(), setup_code.strip(), loop_code.strip())):
        raise ValueError("The selected text did not contain extractable C++ sections.")

    warnings: list[str] = []
    if not has_setup:
        warnings.append("No complete void setup() function was found. The Setup section will be empty.")
    if not has_loop:
        warnings.append("No complete void loop() function was found. The Loop section will be empty.")
    if len(candidates) > 1 and selected_code == combined_candidate_text:
        warnings.append("Includes, globals and lifecycle code were combined from separate code blocks because no single block contained a complete setup() and loop() pair.")
    elif len(candidates) > 1:
        warnings.append(f"Found {len(candidates)} distinct code candidates. Imported the strongest complete sketch only; review other examples separately if they are also required.")
    if duplicate_count:
        warnings.append("Repeated setup()/loop() definitions were found inside the selected code. Only the first complete definition of each was kept.")
    # Detect blocking patterns because they can slow continuous tasks and communications.
    if re.search(r"\bdelay\s*\(", loop_code):
        warnings.append("The imported loop contains delay(). It blocks other cooperative tasks, sensor monitors and network servicing while it waits.")
    if re.search(r"\bSerial\s*\.\s*begin\s*\(", setup_code):
        warnings.append("The imported setup initializes Serial. Its baud rate will override Mixer Code's default Serial.begin(115200). Use the same baud rate in Serial Monitor.")
    if re.search(r"\bwhile\s*\(\s*1\s*\)|\bfor\s*\(\s*;\s*;\s*\)", loop_code):
        warnings.append("The imported loop contains an infinite blocking loop. This can prevent Mixer Code tasks and communications from running.")

    inferred_title = _infer_title(selected_code, includes, title)
    return IntegrationExtraction(
        title=inferred_title,
        includes=includes,
        declarations=declarations,
        setup_code=setup_code,
        loop_code=loop_code,
        warnings=warnings,
        source_url=source_url.strip(),
        candidate_count=len(candidates),
        duplicate_count=duplicate_count,
    )
