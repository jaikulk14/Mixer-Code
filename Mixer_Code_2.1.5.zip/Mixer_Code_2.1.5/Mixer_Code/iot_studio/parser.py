"""Small, deterministic instruction parser for the IoT rule grammar."""
from __future__ import annotations

from .catalog import COMPONENTS, normalize
from .model import Project, Rule


class InstructionError(ValueError):
    pass


def _match_component(text: str, project: Project, kinds: set[str]):
    wanted = normalize(text)
    matches = []
    for component in project.components:
        spec = COMPONENTS[component.type_id]
        if spec.kind not in kinds:
            continue
        labels = [component.name, component.id, component.type_id, spec.display_name, *spec.aliases]
        for label in labels:
            norm = normalize(label)
            if norm and norm == wanted:
                matches.append(component)
                break
    if not matches:
        raise InstructionError(f"I couldn't identify '{text}' as a compatible component already added to the project.")
    if len(matches) > 1:
        names = ", ".join(c.name for c in matches)
        raise InstructionError(f"'{text}' matches more than one component: {names}. Use the exact component name.")
    return matches[0]


def parse_instruction(line: str, project: Project) -> Rule:
    """Parse sensor rules with digital, presence and numeric conditions.

    Supported conditions include TRUE/FALSE, DETECTED/NOT_DETECTED, and
    ABOVE/BELOW <threshold>. DETECTED and NOT DETECTED are accepted as
    equivalent spellings. THEN is optional for compact keyword sequences.
    """
    tokens = line.strip().split()
    if not tokens:
        raise InstructionError("Enter an instruction first.")
    if tokens[0].upper() == "WHEN":
        tokens = tokens[1:]

    condition_pos = None
    condition = None
    condition_length = 1
    supported_conditions = {"TRUE", "FALSE", "ABOVE", "BELOW", "DETECTED", "NOT_DETECTED", "NOT-DETECTED", "NO_ECHO"}
    for i, token in enumerate(tokens):
        upper = token.upper()
        if upper == "NOT" and i + 1 < len(tokens) and tokens[i + 1].upper() == "DETECTED":
            condition_pos, condition, condition_length = i, "NOT_DETECTED", 2
            break
        normalized = upper.replace("-", "_")
        if normalized == "NO_ECHO":
            normalized = "NOT_DETECTED"
        if normalized in supported_conditions:
            condition_pos, condition = i, normalized
            break
    if condition_pos is None or condition_pos == 0:
        raise InstructionError("Condition must be TRUE, FALSE, DETECTED, NOT_DETECTED, ABOVE, or BELOW.")

    sensor_text = " ".join(tokens[:condition_pos])
    after_condition = tokens[condition_pos + condition_length:]
    threshold = None
    if condition in ("ABOVE", "BELOW"):
        if not after_condition or not after_condition[0].isdigit():
            raise InstructionError("ABOVE and BELOW need a numeric threshold, for example: WHEN LDR ABOVE 600 THEN LED GLOW.")
        threshold = int(after_condition[0])
        after_condition = after_condition[1:]

    if after_condition and after_condition[0].upper() == "THEN":
        after_condition = after_condition[1:]
    elif "THEN" in [token.upper() for token in after_condition]:
        raise InstructionError("Put THEN between the condition and action.")

    if len(after_condition) < 2:
        raise InstructionError("Instruction is incomplete. Example: WHEN TouchSensor TRUE LED GLOW")

    action_tokens = [t.upper() for t in after_condition]
    angle = None
    action = None
    if len(action_tokens) >= 3 and action_tokens[-3] == "SET" and action_tokens[-2] == "ANGLE" and action_tokens[-1].isdigit():
        action = "SET_ANGLE"
        angle = int(action_tokens[-1])
        target_text = " ".join(after_condition[:-3])
    else:
        action_aliases = {
            "GLOW": "GLOW", "ON": "ON", "OFF": "OFF", "BEEP": "BEEP",
            "SILENCE": "SILENCE", "ACTIVATE": "ACTIVATE", "DEACTIVATE": "DEACTIVATE",
        }
        last = action_tokens[-1]
        if last not in action_aliases:
            raise InstructionError("Unknown action. Use GLOW, ON, OFF, BEEP, SILENCE, ACTIVATE, DEACTIVATE, or SET ANGLE 90.")
        action = action_aliases[last]
        target_text = " ".join(after_condition[:-1])
    if not target_text:
        raise InstructionError("Name an output component before the action.")

    source = _match_component(sensor_text, project, {"digital_input", "analog_input", "distance_input"})
    target = _match_component(target_text, project, {"digital_output", "servo_output"})
    return Rule(source.id, condition, threshold, target.id, action, angle)
