"""Documentation import and Arduino CLI library helpers.

The URL scanner only reads a single user-supplied public HTTP(S) URL. It does not
execute page scripts, follow links, or install code automatically.
"""
from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, build_opener, HTTPRedirectHandler
import ipaddress
import re
import shutil
import socket
import subprocess

from .integration_import import extract_integration_document

MAX_PAGE_BYTES = 2 * 1024 * 1024
USER_AGENT = "MixerCode-Documentation-Importer/1.0"


class DocumentationImportError(ValueError):
    pass


def _validate_public_url(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise DocumentationImportError("Enter a complete public http:// or https:// URL.")
    if parsed.username or parsed.password:
        raise DocumentationImportError("URLs containing usernames or passwords are not supported.")
    host = parsed.hostname.rstrip(".").lower()
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".internal", ".test")):
        raise DocumentationImportError("Local or private network URLs are blocked for safety.")
    try:
        addresses = {ipaddress.ip_address(host)}
    except ValueError:
        try:
            addresses = {ipaddress.ip_address(info[4][0]) for info in socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)}
        except OSError as exc:
            raise DocumentationImportError(f"Could not resolve website host: {exc}") from exc
    if not addresses or any(not addr.is_global for addr in addresses):
        raise DocumentationImportError("The URL must resolve only to a public internet address.")
    return url.strip()


class _SafeRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class _SnippetHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title_parts: list[str] = []
        self._in_title = False
        self._pre_depth = 0
        self._code_depth = 0
        self._pre_parts: list[str] = []
        self._code_parts: list[str] = []
        self.blocks: list[str] = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag == "title":
            self._in_title = True
        elif tag == "pre":
            if self._pre_depth == 0:
                self._pre_parts = []
            self._pre_depth += 1
        elif tag == "code" and self._pre_depth == 0:
            if self._code_depth == 0:
                self._code_parts = []
            self._code_depth += 1

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "title":
            self._in_title = False
        elif tag == "pre" and self._pre_depth:
            self._pre_depth -= 1
            if self._pre_depth == 0:
                text = "".join(self._pre_parts).strip()
                if text:
                    self.blocks.append(text)
                self._pre_parts = []
        elif tag == "code" and self._pre_depth == 0 and self._code_depth:
            self._code_depth -= 1
            if self._code_depth == 0:
                text = "".join(self._code_parts).strip()
                if text:
                    self.blocks.append(text)
                self._code_parts = []

    def handle_data(self, data):
        if self._in_title:
            self.title_parts.append(data)
        if self._pre_depth:
            self._pre_parts.append(data)
        elif self._code_depth:
            self._code_parts.append(data)


def _find_function_span(code: str, function_name: str) -> tuple[int, int] | None:
    match = re.search(r"\bvoid\s+" + re.escape(function_name) + r"\s*\([^)]*\)\s*\{", code, flags=re.I)
    if not match:
        return None
    brace_start = code.find("{", match.start(), match.end())
    depth = 0
    i = brace_start
    state = "normal"
    while i < len(code):
        ch = code[i]
        nxt = code[i + 1] if i + 1 < len(code) else ""
        if state == "line_comment":
            if ch == "\n": state = "normal"
        elif state == "block_comment":
            if ch == "*" and nxt == "/": state = "normal"; i += 1
        elif state == "string":
            if ch == "\\": i += 1
            elif ch == '"': state = "normal"
        elif state == "char":
            if ch == "\\": i += 1
            elif ch == "'": state = "normal"
        else:
            if ch == "/" and nxt == "/": state = "line_comment"; i += 1
            elif ch == "/" and nxt == "*": state = "block_comment"; i += 1
            elif ch == '"': state = "string"
            elif ch == "'": state = "char"
            elif ch == "{": depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return match.start(), i + 1
        i += 1
    return None


def classify_cpp_snippets(snippets: list[str], source_url: str = "", title: str = "") -> dict[str, str | int]:
    """Split imported C++ snippets using the same single-sketch parser as paste import."""
    code_blocks = [block.strip() for block in snippets if block and block.strip()]
    code_blocks = [
        block for block in code_blocks
        if re.search(r"#\s*include|\bvoid\s+(?:setup|loop)\s*\(|[;{}]|\b(?:pinMode|digitalRead|analogRead|Serial\.)", block, re.I)
    ]
    if not code_blocks:
        return {
            "title": title.strip() or (Path(urlparse(source_url).path).stem if source_url else "Imported component"),
            "source_url": source_url,
            "includes": "", "declarations": "", "setup_code": "", "loop_code": "",
            "snippet_count": 0,
        }
    result = extract_integration_document("\n\n".join(code_blocks), source_url=source_url, title=title)
    return {
        "title": result.title,
        "source_url": result.source_url,
        "includes": result.includes,
        "declarations": result.declarations,
        "setup_code": result.setup_code,
        "loop_code": result.loop_code,
        "snippet_count": len(code_blocks),
        "warnings": result.warnings,
    }


def scan_documentation_url(url: str, timeout: int = 15) -> dict[str, str | int]:
    """Fetch one public documentation page/raw source and classify C++ snippets."""
    url = _validate_public_url(url)
    opener = build_opener(_SafeRedirectHandler())
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,text/plain,application/octet-stream;q=0.9,*/*;q=0.5"})
    try:
        with opener.open(request, timeout=timeout) as response:
            final_url = _validate_public_url(response.geturl())
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > MAX_PAGE_BYTES:
                raise DocumentationImportError("The page is larger than the 2 MB import limit.")
            raw = response.read(MAX_PAGE_BYTES + 1)
            content_type = (response.headers.get_content_type() or "").lower()
    except DocumentationImportError:
        raise
    except Exception as exc:
        raise DocumentationImportError(f"Could not download the documentation page: {exc}") from exc
    if len(raw) > MAX_PAGE_BYTES:
        raise DocumentationImportError("The page is larger than the 2 MB import limit.")
    charset = "utf-8"
    try:
        charset = response.headers.get_content_charset() or "utf-8"
    except Exception:
        pass
    text = raw.decode(charset, errors="replace")
    parser = _SnippetHTMLParser()
    title = ""
    snippets: list[str]
    if "html" in content_type or re.search(r"<\s*(?:html|pre|code|title)\b", text[:4000], re.I):
        parser.feed(text)
        title = " ".join("".join(parser.title_parts).split())
        snippets = parser.blocks
    else:
        snippets = [text]
    if not snippets:
        raise DocumentationImportError("No code blocks were found. Try a direct .ino/.cpp source link or paste the code manually while offline.")
    result = classify_cpp_snippets(snippets, final_url, title)
    if not any(result[key] for key in ("includes", "declarations", "setup_code", "loop_code")):
        raise DocumentationImportError("The page contained code blocks, but no recognizable Arduino C++ was found.")
    return result


def find_arduino_cli() -> str | None:
    return shutil.which("arduino-cli")


def list_installed_libraries() -> str:
    cli = find_arduino_cli()
    if not cli:
        raise RuntimeError("Arduino CLI was not found. Install Arduino CLI and add it to PATH to manage libraries from Mixer Code.")
    result = subprocess.run([cli, "lib", "list"], capture_output=True, text=True, timeout=20, check=False)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "Arduino CLI library list failed.").strip())
    return result.stdout.strip() or "No libraries are currently listed by Arduino CLI."


def install_library(name: str, version: str = "") -> str:
    clean = name.strip()
    version = version.strip()
    if not clean or len(clean) > 120 or any(ch in clean for ch in "\r\n\0@"):
        raise ValueError("Enter a valid Arduino Library Manager package name.")
    if version and (len(version) > 40 or not re.fullmatch(r"[0-9A-Za-z][0-9A-Za-z.+_-]*", version)):
        raise ValueError("Enter a valid library version, for example 1.2.3.")
    target = f"{clean}@{version}" if version else clean
    cli = find_arduino_cli()
    if not cli:
        raise RuntimeError("Arduino CLI was not found. Install Arduino CLI and add it to PATH first.")
    result = subprocess.run([cli, "lib", "install", target], capture_output=True, text=True, timeout=180, check=False)
    output = (result.stdout + "\n" + result.stderr).strip()
    if result.returncode != 0:
        raise RuntimeError(output or f"Could not install {clean}.")
    return output or f"Installed {target}."
