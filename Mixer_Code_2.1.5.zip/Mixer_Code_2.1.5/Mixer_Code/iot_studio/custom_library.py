"""Persistent offline library of user-authored custom component snippets."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from dataclasses import asdict

from .model import CustomCodeComponent


def custom_library_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config")))
    return base / "MixerCoder" / "custom_components"


def _safe_id(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.casefold()).strip("_") or "custom_component"


def save_custom_definition(item: CustomCodeComponent) -> Path:
    folder = custom_library_dir()
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{_safe_id(item.id or item.name)}.json"
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(asdict(item), indent=2), encoding="utf-8")
    tmp.replace(path)
    return path


def load_custom_definitions() -> list[CustomCodeComponent]:
    folder = custom_library_dir()
    if not folder.exists():
        return []
    items: list[CustomCodeComponent] = []
    for path in sorted(folder.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            items.append(CustomCodeComponent(**data))
        except (OSError, ValueError, TypeError):
            continue
    return items
