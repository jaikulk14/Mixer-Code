"""Board profiles and pin allocation/validation."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BoardProfile:
    board_id: str
    display_name: str
    fqbn: str
    digital_pins: tuple[str, ...]
    analog_pins: tuple[str, ...]
    pwm_pins: tuple[str, ...]
    adc_max: int
    input_only: tuple[str, ...] = ()
    notes: str = ""


BOARDS = {
    "uno": BoardProfile("uno", "Arduino Uno R3", "arduino:avr:uno", tuple(str(i) for i in range(2, 14)), tuple(f"A{i}" for i in range(6)), tuple(str(i) for i in (3, 5, 6, 9, 10, 11)), 1023, notes="D0/D1 are reserved for serial communication by default."),
    "nano": BoardProfile("nano", "Arduino Nano (classic)", "arduino:avr:nano", tuple(str(i) for i in range(2, 14)), tuple(f"A{i}" for i in range(8)), tuple(str(i) for i in (3, 5, 6, 9, 10, 11)), 1023, notes="Classic ATmega328P Nano profile."),
    "esp32": BoardProfile("esp32", "ESP32 Dev Module", "esp32:esp32:esp32", tuple(str(i) for i in (4, 13, 14, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33, 34, 35, 36, 39)), tuple(f"{i}" for i in (32, 33, 34, 35, 36, 39)), tuple(str(i) for i in (4, 13, 14, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33)), 4095, input_only=tuple(str(i) for i in (34, 35, 36, 39)), notes="Uses a conservative pin list. GPIO 34-39 are input-only; GPIO 6-11 and boot-strapping pins are omitted."),
    "esp8266": BoardProfile("esp8266", "ESP8266 NodeMCU / ESP-12E", "esp8266:esp8266:nodemcuv2", ("4", "5", "12", "13", "14", "16"), ("A0",), ("4", "5", "12", "13", "14"), 1023, notes="NodeMCU-style ESP8266 profile. GPIO 4/5/12/13/14/16 are exposed conservatively; board labels D1/D2 etc. map to GPIO numbers. Verify your exact board and A0 input range."),
}


class PinError(ValueError):
    pass


def _pin_key(pin: str) -> str:
    return pin.strip().upper()


def available_pins(board: BoardProfile, role: str) -> list[str]:
    if role in ("input", "analog"):
        if role == "analog":
            return list(board.analog_pins)
        return list(board.digital_pins)
    if role == "output":
        return [p for p in board.digital_pins if p not in board.input_only]
    if role == "servo":
        return [p for p in board.digital_pins if p not in board.input_only]
    raise PinError(f"Unknown pin role: {role}")


def validate_pin(board: BoardProfile, pin: str, role: str) -> None:
    p = _pin_key(pin)
    valid = {_pin_key(x) for x in available_pins(board, role)}
    if p not in valid:
        raise PinError(f"Pin {pin} is not valid for {role} on {board.display_name}.")


def allocate_pin(board: BoardProfile, role: str, used: set[str]) -> str:
    used_norm = {_pin_key(x) for x in used}
    for pin in available_pins(board, role):
        if _pin_key(pin) not in used_norm:
            return pin
    raise PinError(f"No free {role} pins remain on {board.display_name}.")
