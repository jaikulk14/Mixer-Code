# Mixer Code 2.1.5

**Offline-first desktop IoT C++ project builder for Arduino Uno/Nano, ESP32 and ESP8266.**

Mixer Code builds Arduino sketches from a component catalog, structured `WHEN / THEN` rules, saved custom C++ adapters, library dependencies, independent tasks, OLED layouts and connectivity profiles. Code generation is deterministic: the application generates from the project model and validates pin, board and adapter constraints before creating a sketch.

## Download and run

1. Extract the release ZIP to a normal writable folder.
2. Install Python 3.10 or newer.
3. Run `run_windows.bat` on Windows, or run `python main.py` from this folder.
4. Choose a target board, add components or connectivity profiles, validate the project, then generate C++.

The desktop interface uses Python's built-in Tkinter. The product branding is Mixer Code; the legacy per-user custom-component folder name `MixerCoder` is retained so earlier offline sensor definitions remain available. No third-party Python package is required to launch the application. The Arduino board cores and hardware libraries are separate dependencies used when compiling or uploading generated sketches.

## What's in this release

The desktop app contains nine tabs:

1. **Components**: a wider catalog of analog and digital sensors, outputs and display modules.
2. **Logic Builder**: keyword-driven conditions and output actions, including value-free `DETECTED` / `NOT_DETECTED` rules.
3. **Independent Tasks**: cooperative non-blocking tasks such as radar servo sweep and ultrasonic measurement.
4. **C++ Code**: generated sketch preview and export.
5. **Custom Components**: paste official code manually or import a supported documentation page.
6. **Libraries & URL Import**: record dependencies, inspect installed libraries and install through Arduino CLI when available.
7. **OLED Designer**: design and preview SSD1306 128x64 layouts; save the design with the project.
8. **Connectivity & Protocols**: select Wi-Fi, Bluetooth, serial, bus, messaging, storage, time, OTA and radio profiles.
9. **Sensor Monitor**: choose threshold-only, continuous telemetry-only, or both behaviors independently for each sensor.

### Supported boards

| Board profile | Arduino CLI FQBN | Native connectivity in this profile |
|---|---|---|
| Arduino Uno R3 | `arduino:avr:uno` | USB Serial only. Add external HC-05, HM-10, ESP8266 AT or LoRa hardware as needed. |
| Arduino Nano classic | `arduino:avr:nano` | USB/UART through its USB adapter. Add external modules for wireless features. |
| ESP32 Dev Module (original ESP32) | `esp32:esp32:esp32` | Wi-Fi, Bluetooth Classic SPP and native UART/SPI/I2C. |
| ESP8266 NodeMCU / ESP-12E | `esp8266:esp8266:nodemcuv2` | Wi-Fi and network services; no native Bluetooth. |

The ESP32 Bluetooth Classic profile is for original ESP32 SoCs that support SPP. It is not a general profile for ESP32-S2, ESP32-C3 or ESP32-S3. The ESP8266 profile does not include Bluetooth. Verify the exact module variant, board pinout and core before compiling.

## Connectivity and protocol catalog

Connectivity profiles are added in the **Connectivity & Protocols** tab. Profile availability changes with the selected board.

| Category | Available profiles | Target |
|---|---|---|
| Serial | UART Serial Bridge | Uno, Nano, ESP32, ESP8266 |
| Industrial serial | MAX485 RS-485 Half-Duplex Bridge | Uno, Nano, ESP32, ESP8266 |
| Bluetooth | HC-05 / HC-06 Bluetooth Classic UART | External module on Uno, Nano, ESP32, ESP8266 |
| Bluetooth | HM-10 BLE UART | External BLE UART module on Uno, Nano, ESP32, ESP8266 |
| Bluetooth | ESP32 Bluetooth Classic SPP | Original ESP32 Dev Module profile |
| Wi-Fi | Wi-Fi Station | ESP32, ESP8266 |
| Wi-Fi | Wi-Fi Access Point | ESP32, ESP8266 |
| Wi-Fi | Wi-Fi Network Scanner | ESP32, ESP8266 |
| Wi-Fi | ESP8266 AT Wi-Fi Modem | Uno, Nano with ESP8266 running compatible ESP-AT firmware |
| Messaging | MQTT Client, optional username/password, publish and subscribe | ESP32, ESP8266 |
| Messaging | HTTP REST Client: GET, POST, PUT, DELETE | ESP32, ESP8266 |
| Messaging | UDP Listener | ESP32, ESP8266 |
| Messaging | HTTP Web Status Server (`/`, `/status`) | ESP32, ESP8266 |
| Time | NTP Clock Synchronization | ESP32, ESP8266 |
| Device management | ArduinoOTA firmware updates | ESP32 |
| Hardware buses | I2C Bus Scanner | All four board profiles |
| Hardware buses | SPI Byte Transfer Test | All four board profiles |
| Storage | SPI SD Card CSV Logger | All four board profiles |
| Long-range radio | LoRa SX1276/77/78/79 send and receive | Uno, Nano, ESP32 |

### What the adapters generate

- **UART Serial Bridge**: connects the USB Serial Monitor to one external serial module.
- **MAX485 RS-485**: raw half-duplex serial bridge with an exposed DE/RE direction pin. It is not a Modbus RTU stack.
- **HC-05 / HC-06**: serial pass-through for a Bluetooth Classic module.
- **HM-10**: serial pass-through for a BLE UART module. This is not a native BLE GATT stack implementation on the MCU. Native ESP32 BLE GATT services are not included in this release; HM-10 clones and firmware can differ.
- **ESP32 SPP**: exposes a Bluetooth Classic serial endpoint. Use only a compatible original ESP32 variant.
- **Wi-Fi Station / Access Point**: connects to a router or creates a local device hotspot.
- **Wi-Fi Scanner**: scans once at startup and reports SSID and signal strength over Serial. This is a synchronous scan and can temporarily interrupt a connection, so keep it separate from a live STA project.
- **ESP8266 AT Modem**: sends basic AT initialization and joins a Wi-Fi network from Uno/Nano. This adapter is a modem setup/diagnostic example, not a general TCP, MQTT or HTTP transport. For those profiles, select ESP8266 as the target board.
- **MQTT**: uses PubSubClient, reconnect scheduling, a subscription callback and an example startup publish. The generated helper exposes a publish function for your own sensor logic.
- **HTTP REST**: periodic plain HTTP requests with GET, POST, PUT or DELETE. POST and payload-bearing PUT/DELETE include the configured request body.
- **UDP**: receives and prints datagrams on a configured port.
- **Web server**: serves a simple text root page and a JSON `/status` response.
- **NTP**: sets the system clock using configured UTC and daylight offsets.
- **OTA**: starts ArduinoOTA after Wi-Fi station connectivity is available, then services OTA events in `loop()`.
- **I2C scanner**: scans addresses 1 through 126 and reports responders.
- **SPI transfer**: performs a configured test transaction with a user-selected chip-select pin.
- **SD logger**: creates/appends a CSV file with uptime in milliseconds. Extend the generated row to log project sensor values.
- **LoRa**: sends a configured text message periodically using the library's asynchronous TX mode and a DIO0 transmission-complete callback, while polling for received packets between transmissions. It prints received payloads and RSSI. Uses the Arduino-LoRa library.

## Presence detection rules

The Logic Builder supports `DETECTED` and `NOT_DETECTED` for digital and ultrasonic inputs without a numeric threshold. For HC-SR04, this represents valid echo received versus no valid echo before the timeout, not a calibrated obstacle-distance boundary. See [Presence and Sensor Catalog](docs/PRESENCE_AND_SENSOR_CATALOG.md) for examples and limitations.

## Sensor monitoring modes

See [Sensor Monitoring Guide](docs/SENSOR_MONITORING_GUIDE.md) for the telemetry format, display behavior, and timing notes.


Use the **Sensor Monitor** tab to choose the behavior independently for each analog, digital or HC-SR04 input:

| Mode | Behavior |
|---|---|
| Threshold rules only | Original `WHEN / THEN` behavior. No continuous telemetry is emitted. |
| Continuous monitor only | Samples the sensor on its configured interval and streams readings to Serial without requiring any threshold. Threshold rules for that sensor are disallowed. |
| Continuous + threshold rules | Streams the current sensor reading and still evaluates its `WHEN / THEN` rules. |

Unconfigured sensors default to threshold-rule behavior, preserving older project behavior. Monitoring interval is 10 to 60000 ms; HC-SR04 uses a minimum 60 ms ping interval to avoid triggering the module too quickly. Telemetry is emitted as CSV-style lines:

```text
MONITOR,mq_gas,ANALOG,642
MONITOR,touch_sensor,DIGITAL,ACTIVE
MONITOR,ultrasonic,DISTANCE_CM,37.4
```

For HC-SR04, Mixer Code generates a cooperative `micros()` state machine. It does not call blocking `pulseIn()` in continuous mode. It reports `-1` when no echo is received within the timeout. The monitor updates a connected SSD1306 OLED or LCD when no saved OLED Designer layout takes precedence. Existing radar independent tasks continue to work; do not configure both the legacy ultrasonic task and the new sensor monitor for the same ultrasonic module.

Continuous scheduling is cooperative, not parallel threading. Keep custom loop code and network operations short/non-blocking. Serial telemetry uses USB/UART `Serial` at 115200 baud and can compete with other code that also writes to Serial.

## Hardware and pin cautions

- **Uno/Nano SoftwareSerial**: this release allows only one UART/HC-05/HM-10/ESP8266 AT profile per project on Uno, Nano and ESP8266. SoftwareSerial cannot receive on multiple ports at the same time. ESP32 connectivity UART profiles also reserve UART2 in this starter adapter, so only one such profile is allowed per project.
- **MAX485 / RS-485**: tie DE and /RE together to the configured direction pin. Connect RO to MCU RX and DI to MCU TX. Add appropriate termination at the two physical bus ends and biasing as required. This profile is a simple serial bridge, not Modbus.
- **HC-05/HC-06**: connect module TX to MCU RX and MCU TX to module RX. Many breakout boards accept 5V power but the UART RX input is still 3.3V logic. Check your exact breakout and use a divider/level shifter on a 5V MCU TX line when required.
- **HM-10**: use correct 3.3V logic and verify that the module is genuine HM-10 or a compatible firmware variant. Not all clones expose the same BLE service or AT commands.
- **ESP8266 with Uno/Nano**: ESP8266 is a 3.3V device with short high-current peaks. Use a suitable regulated 3.3V supply and level-shift the MCU TX signal into ESP8266 RX. Do not assume the Uno/Nano 3.3V pin can power it safely.
- **ESP32**: GPIO 34, 35, 36 and 39 in this profile are input-only. Avoid board-specific boot/strapping pins unless you understand their boot requirements. Board variants differ.
- **I2C**: Uno/Nano use A4 SDA and A5 SCL. ESP32 profile defaults to GPIO21 SDA and GPIO22 SCL. ESP8266 NodeMCU profile defaults to GPIO4 SDA and GPIO5 SCL. Mixer Code reserves these pins when an I2C display or scanner is selected.
- **SPI**: Uno/Nano use D11 MOSI, D12 MISO and D13 SCK. ESP32 profile uses VSPI GPIO23 MOSI, GPIO19 MISO and GPIO18 SCK. ESP8266 NodeMCU profile uses GPIO13 MOSI, GPIO12 MISO and GPIO14 SCK. SPI chip-select pins are independent and must not collide with other components.
- **LoRa**: modules are usually 3.3V devices and need an appropriate supply, antenna and matching frequency. DIO0 must be connected to a valid interrupt-capable pin. Uno/Nano defaults use CS D10, RESET D9 and DIO0 D2. The ESP32 defaults use CS GPIO25, RESET GPIO14 and DIO0 GPIO26.
- **Servos**: use a separate suitable supply and connect the supply ground to MCU ground. Do not power a servo from an I/O pin.

## Libraries and board cores

Mixer Code records dependencies for built-in adapters, including Adafruit GFX, Adafruit SSD1306, hd44780, PubSubClient and LoRa. Some APIs such as Wire, SPI, SD, ESP32 Wi-Fi, ESP8266 Wi-Fi and ArduinoOTA come from the selected board core or its bundled libraries.

Install the appropriate board package and libraries with Arduino IDE Board Manager / Library Manager or Arduino CLI. Typical library installs:

```text
arduino-cli lib install "PubSubClient"
arduino-cli lib install "LoRa"
arduino-cli lib install "Adafruit GFX Library"
arduino-cli lib install "Adafruit SSD1306"
```

For ESP8266, install the ESP8266 Arduino core and select the matching NodeMCU profile. For ESP32, install Espressif's Arduino-ESP32 core. The exact core and library versions depend on your Arduino IDE / CLI environment.

## Custom components and URL scanning

- Complete integration import: paste one complete `.ino` sketch or a README containing Arduino code. Mixer Code extracts `#include` lines, global declarations/helper functions, the body of `void setup()` and the body of `void loop()`. Function wrappers, Markdown headings, tables, README paragraphs and repeated copies are excluded from the generated component. A preview and warnings appear before the sections are loaded into the editor. Separate fenced snippets can be combined when no single block contains both lifecycle functions.
- Offline manual mode: type includes, declarations, setup statements, loop statements, source link and wiring notes in the Custom Components tab. Save to the local custom library and reuse it later.
- Online: provide one documentation URL. The importer reads that page or raw source and extracts code blocks, includes and likely `setup()` / `loop()` code into editable fields.
- The URL importer does not crawl all links, execute JavaScript, run downloaded code or guarantee semantic correctness. The complete-code paste importer is a source-text parser, not a C++ compiler: it selects one main integration, does not infer arbitrary hardware pin wiring, and asks you to review the extracted sections. It may not detect snippets rendered only by browser-side JavaScript. In those cases, paste the code manually or use a direct raw-source URL.
- Arbitrary custom C++ is inserted as source text. It is not sandboxed or fully understood by the validator. Review it before compiling.

## OLED Designer

The SSD1306 128x64 OLED Designer supports Single Value, Two Columns, List and Bar Graph layouts. Choose analog input components, title and refresh interval. The 128x64 preview uses example values; generated sketches call `analogRead()` for live readings. If an SSD1306 and analog inputs are present without a saved layout, a default dashboard is generated automatically. An explicitly saved layout takes priority. Raw ADC values and percentage bars are not calibrated lux, gas concentration or moisture readings.

## Independent task scheduler

Independent tasks use cooperative, non-blocking `millis()` / `micros()` state machines. The included radar example sweeps a positional servo while the ultrasonic monitor measures in its own schedule, without blocking `pulseIn()`. Serial output uses `RADAR,angle,distance_cm`, with `-1` for an echo timeout. This is not true parallel processing or an RTOS. A blocking custom function or network request can still delay the loop.

## Example projects

The `examples` folder includes 24 saved `.iotproj` models with matching generated `.ino` sketches for OLED dashboards, radar, ESP32 Wi-Fi/MQTT/Web/UDP/NTP/OTA gateway, HTTP REST POST, ESP32 Bluetooth SPP, ESP32 Wi-Fi scanning, ESP8266 Wi-Fi/web server, Uno HC-05, Uno ESP8266 AT modem, SPI and SD logger, LoRa peer node, MAX485 RS-485 bridge, continuous sensor monitor examples for analog, digital, and ultrasonic inputs, threshold-free ultrasonic presence detection, expanded multi-sensor input profiles, and the imported MPU6050 integration example.

## Security and networking limitations

- Wi-Fi, MQTT and OTA secrets are stored in `.iotproj` JSON and generated C++ as plain text. Do not commit real passwords, broker credentials or OTA passwords to a public repository. Use a private local project and replace demo settings before uploading.
- The MQTT example uses regular TCP unless you add your own TLS adapter. MQTT on port 1883 is not encrypted. A public broker and public topics are not appropriate for private data.
- The HTTP REST starter supports `http://` only. It does not configure HTTPS/TLS certificates. The request itself is synchronous, with short connect/read timeouts. Avoid very short polling intervals or using it alongside timing-critical work.
- ArduinoOTA is enabled for a password-protected local network workflow, not a full device-security system. Keep the device on a trusted network and do not expose OTA ports to the public internet.
- Raw LoRa packets from the included library profile are not encrypted and are not LoRaWAN. The adapter does not manage duty-cycle limits or regional spectrum rules. Confirm the module band, antenna, permitted frequency, transmit power and local regulations before transmitting.
- The built-in Wi-Fi AP and OTA profiles require you to replace their sample passwords before validation succeeds.

## Validation and testing

The release includes Python unit tests and a syntax-check harness for the bundled Arduino sketches. Run:

```text
python -m unittest discover -s tests -v
python tools/syntax_check_examples.py
```

The C++ syntax harness uses lightweight API stubs to catch malformed generated C++ and integration mistakes. It is not a substitute for compiling with the actual Arduino board cores and installed libraries. No physical hardware is attached to the build environment, so real Wi-Fi association, Bluetooth pairing, MQTT broker access, LoRa range, display output and board upload have not been physically tested.

## Project compatibility

The project data model is schema version 6. Projects from prior Mixer Code releases are migrated when opened and saved. Version 2.1.5 adds complete integration-code import and extraction without removing prior components, rules, custom code, libraries, independent tasks, OLED layouts or connectivity profiles.
