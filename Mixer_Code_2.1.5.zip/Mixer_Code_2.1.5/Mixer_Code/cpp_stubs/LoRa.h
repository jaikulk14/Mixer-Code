#pragma once
#include "Arduino.h"
class LoRaClass {
public:
  void setPins(int, int, int) {}
  bool begin(long) { return true; }
  void onTxDone(void (*)(void)) {}
  int parsePacket() { return 0; }
  int available() { return 0; }
  int read() { return -1; }
  int packetRssi() { return -50; }
  int beginPacket() { return 1; }
  template<class T> size_t print(const T&) { return 1; }
  int endPacket(bool = false) { return 1; }
};
extern LoRaClass LoRa;
