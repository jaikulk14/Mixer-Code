#pragma once
#include "Arduino.h"
class BluetoothSerial {
public:
  bool begin(const char*) { return true; }
  int available() { return 0; }
  int read() { return -1; }
  size_t write(uint8_t) { return 1; }
};
