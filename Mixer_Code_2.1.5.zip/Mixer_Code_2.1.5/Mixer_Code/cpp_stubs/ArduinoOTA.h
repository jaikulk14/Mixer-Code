#pragma once
class ArduinoOTAClass {
public:
  void setHostname(const char*) {}
  void setPassword(const char*) {}
  void begin() {}
  void handle() {}
};
extern ArduinoOTAClass ArduinoOTA;
