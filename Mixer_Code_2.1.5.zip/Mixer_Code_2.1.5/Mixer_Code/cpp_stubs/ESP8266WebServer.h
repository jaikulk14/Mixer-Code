#pragma once
#include "WebServer.h"
using ESP8266WebServer = WebServer;
