#pragma once
#include "Arduino.h"
class WiFiUDP {
public:
  uint8_t begin(uint16_t) { return 1; }
  int parsePacket() { return 0; }
  int read(char*, size_t) { return 0; }
};
