#pragma once
#include "Arduino.h"
class SPISettings { public: SPISettings(uint32_t, uint8_t, uint8_t) {} };
class SPIClass {
public:
  void begin() {}
  void beginTransaction(const SPISettings&) {}
  uint8_t transfer(uint8_t b) { return b; }
  void endTransaction() {}
};
extern SPIClass SPI;
