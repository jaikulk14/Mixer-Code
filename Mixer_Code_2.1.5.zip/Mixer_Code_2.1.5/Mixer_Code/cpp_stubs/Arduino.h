#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <string>
#include <ctime>
using std::size_t;
using byte = uint8_t;
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define A0 14
#define A1 15
#define A2 16
#define A3 17
#define A4 18
#define A5 19
#define HEX 16
#define SERIAL_8N1 0
#define WL_CONNECTED 3
#define WIFI_STA 1
#define WIFI_AP 2
#define FILE_WRITE 1
#define MSBFIRST 1
#define SPI_MODE0 0
#define F(x) x
inline void pinMode(uint8_t, uint8_t) {}
inline int analogRead(uint8_t) { return 512; }
inline int digitalRead(uint8_t) { return LOW; }
inline void digitalWrite(uint8_t, uint8_t) {}
inline void delay(unsigned long) {}
inline void delayMicroseconds(unsigned int) {}
inline unsigned long millis() { static unsigned long t=0; return ++t; }
inline unsigned long micros() { static unsigned long t=0; return ++t; }
inline unsigned long pulseIn(uint8_t, uint8_t, unsigned long = 1000000UL) { return 0; }
inline void configTime(long, int, const char*, const char* = nullptr) {}
class String {
  std::string value;
public:
  String() = default;
  String(const char* s): value(s ? s : "") {}
  String(const std::string& s): value(s) {}
  String& operator+=(char c) { value += c; return *this; }
  String& operator+=(const char* s) { value += (s ? s : ""); return *this; }
  int indexOf(const char* s) const { auto p=value.find(s ? s : ""); return p == std::string::npos ? -1 : (int)p; }
  const char* c_str() const { return value.c_str(); }
  unsigned int length() const { return (unsigned int)value.size(); }
  friend String operator+(const String& a, const char* b) { return String(a.value + (b ? b : "")); }
  friend String operator+(const String& a, const String& b) { return String(a.value + b.value); }
  friend String operator+(const char* a, const String& b) { return String((a ? a : "") + b.value); }
};
class SerialStub {
public:
  void begin(unsigned long) {}
  int available() { return 0; }
  int read() { return -1; }
  size_t write(uint8_t) { return 1; }
  template<class T> void print(const T&) {}
  template<class T> void println(const T&) {}
  template<class T> void println(const T&, int) {}
  void println() {}
};
extern SerialStub Serial;
class HardwareSerial {
public:
  explicit HardwareSerial(int = 0) {}
  void begin(unsigned long) {}
  void begin(unsigned long, int, int, int) {}
  int available() { return 0; }
  int read() { return -1; }
  size_t write(uint8_t) { return 1; }
};
