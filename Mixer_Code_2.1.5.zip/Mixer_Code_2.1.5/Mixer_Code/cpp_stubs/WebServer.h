#pragma once
#include "Arduino.h"
class WebServer {
public:
  explicit WebServer(int) {}
  template<class F> void on(const char*, F) {}
  void send(int, const char*, const char*) {}
  void begin() {}
  void handleClient() {}
};
