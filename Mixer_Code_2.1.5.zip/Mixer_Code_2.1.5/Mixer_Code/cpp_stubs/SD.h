#pragma once
#include "Arduino.h"
class File {
public:
  explicit operator bool() const { return true; }
  size_t size() const { return 0; }
  template<class T> void println(const T&) {}
  void close() {}
};
class SDClass {
public:
  bool begin(int) { return true; }
  File open(const char*, int) { return File(); }
};
extern SDClass SD;
