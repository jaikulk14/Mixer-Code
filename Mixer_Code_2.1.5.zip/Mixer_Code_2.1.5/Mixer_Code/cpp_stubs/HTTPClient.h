#pragma once
#include "Arduino.h"
#include "WiFiClient.h"
class HTTPClient {
public:
  void setConnectTimeout(int) {}
  void setTimeout(uint16_t) {}
  bool begin(WiFiClient&, const char*) { return true; }
  int GET() { return 200; }
  int POST(const String&) { return 200; }
  int sendRequest(const char*, uint8_t*, size_t) { return 200; }
  String getString() { return String("ok"); }
  void end() {}
};
