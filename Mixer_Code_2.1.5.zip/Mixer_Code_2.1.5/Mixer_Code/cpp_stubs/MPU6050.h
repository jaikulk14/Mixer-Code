#pragma once
#include <stdint.h>
class MPU6050 {
public:
    void initialize() {}
    bool testConnection() { return true; }
    void getMotion6(int16_t*, int16_t*, int16_t*, int16_t*, int16_t*, int16_t*) {}
};
