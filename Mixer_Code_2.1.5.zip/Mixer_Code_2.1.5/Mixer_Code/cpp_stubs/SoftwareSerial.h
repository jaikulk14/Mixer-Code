#pragma once
#include "Arduino.h"
class SoftwareSerial {
public:
  SoftwareSerial(int, int) {}
  void begin(unsigned long) {}
  int available() { return 0; }
  int read() { return -1; }
  size_t write(uint8_t) { return 1; }
  void flush() {}
  void println(const char*) {}
};
