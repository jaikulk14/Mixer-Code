#pragma once
#include "Wire.h"
#define SSD1306_SWITCHCAPVCC 0x2
#define SSD1306_WHITE 1
class Adafruit_SSD1306 {
public:
  Adafruit_SSD1306(int, int, TwoWire*, int) {}
  bool begin(uint8_t, uint8_t, bool=true, bool=true) { return true; }
  void clearDisplay() {}
  void setTextSize(uint8_t) {}
  void setTextColor(uint16_t) {}
  void setCursor(int16_t, int16_t) {}
  template<class T> void print(const T&) {}
  template<class T> void print(const T&, int) {}
  template<class T> void println(const T&) {}
  void display() {}
  void drawRect(int16_t,int16_t,int16_t,int16_t,uint16_t) {}
  void fillRect(int16_t,int16_t,int16_t,int16_t,uint16_t) {}
};
