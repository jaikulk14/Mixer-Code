#pragma once
#include "Arduino.h"
#include "WiFiClient.h"
class PubSubClient {
public:
  explicit PubSubClient(WiFiClient&) {}
  void setServer(const char*, uint16_t) {}
  template<class F> void setCallback(F) {}
  void setSocketTimeout(uint16_t) {}
  bool connect(const char*) { return true; }
  bool connect(const char*, const char*, const char*) { return true; }
  bool subscribe(const char*) { return true; }
  bool publish(const char*, const char*) { return true; }
  bool connected() const { return true; }
  bool loop() { return true; }
};
