#pragma once
#include "Arduino.h"
class IPAddress { public: };
class WiFiClass {
public:
  void mode(int) {}
  void begin(const char*, const char*) {}
  int status() const { return WL_CONNECTED; }
  bool softAP(const char*, const char*) { return true; }
  IPAddress softAPIP() const { return {}; }
  IPAddress localIP() const { return {}; }
  int scanNetworks() { return 0; }
  const char* SSID(int) const { return "stub-network"; }
  int RSSI(int) const { return -42; }
  int scanDelete() { return 0; }
};
extern WiFiClass WiFi;
