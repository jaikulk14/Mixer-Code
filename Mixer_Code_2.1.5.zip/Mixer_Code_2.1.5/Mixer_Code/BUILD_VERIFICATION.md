# Mixer Code 2.1.5 build verification

## Automated checks

- Python unit tests: **113 passed** (`python -m unittest discover -s tests -v`).
- Generated Arduino examples: **24 sketches passed** C++ syntax-only checks using the bundled local API stubs (`python tools/syntax_check_examples.py`).
- Python source compilation: passed (`python -m py_compile main.py iot_studio/*.py`).
- GUI smoke test: passed under a virtual display. Verified the `Mixer Code 2.1.5` window title, nine tabs, populated component picker with 33 entries, and adding an HC-SR04 `DETECTED` rule with no numeric threshold.
- Package contents: 24 `.iotproj` example projects and 24 matching `.ino` sketches.

## New in 2.1.5

- Rebranded the application as **Mixer Code** and added an ASCII `MIXER CODE` wordmark at the top of the desktop UI.
- Expanded the component catalog with analog and digital input modules, including rain, water level, LM35, NTC, FSR, flex, voltage, joystick, IR obstacle, line tracking, vibration, tilt, reed, limit, water leak and digital sound modules.
- Added `DETECTED` and `NOT_DETECTED` conditions to the existing Logic Builder. They do not require a numeric threshold. Existing `TRUE` / `FALSE` digital rules and `ABOVE` / `BELOW` numeric rules remain supported.
- Updated the component catalog refresh on application startup so the available components are visible immediately.

## HC-SR04 presence semantics

For an HC-SR04 distance input, `DETECTED` means a valid echo pulse was received before the configured timeout; `NOT_DETECTED` means no valid echo was received before timeout. It is an echo-presence state, not a calibrated obstacle-distance boundary. A wall or other surface at a greater distance can still produce a valid echo. Use `BELOW <distance>` when the desired behavior depends on a specific distance.

The simple threshold-rule HC-SR04 adapter uses a bounded `pulseIn()` measurement and can block for up to its timeout. The continuous-monitor / independent-task adapter uses a cooperative `micros()` state machine instead.

## Verification limitations

The C++ syntax harness uses lightweight local API stubs. It catches malformed generated C++ and common integration errors, but it does not prove compatibility with every installed Arduino board core or third-party library version. Arduino CLI compilation and physical hardware tests were not performed in this environment. Compile against the exact board core and libraries, check wiring and voltage levels, then test on the target hardware before relying on the sketch.
