/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: ESP32 Bluetooth Classic SPP Demo
 * Board profile: ESP32 Dev Module
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <BluetoothSerial.h>

// Pin map

BluetoothSerial mc_esp32_bt_spp_bt;

void setup() {
  Serial.begin(115200);
  if (!mc_esp32_bt_spp_bt.begin("MixerCoder-ESP32")) Serial.println(F("Bluetooth SPP start failed"));
}

void loop() {
  while (mc_esp32_bt_spp_bt.available()) Serial.write(mc_esp32_bt_spp_bt.read());
  while (Serial.available()) mc_esp32_bt_spp_bt.write(Serial.read());

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
