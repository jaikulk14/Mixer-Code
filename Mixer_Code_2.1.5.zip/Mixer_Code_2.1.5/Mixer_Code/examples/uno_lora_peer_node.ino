/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Arduino Uno LoRa Peer Node
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <LoRa.h>

// Library dependency: LoRa
// Library documentation: https://github.com/sandeepmistry/arduino-LoRa
// Library notes: SX1276/77/78/79 radio driver. Check module frequency, antenna and local radio regulations.

// Pin map

unsigned long mc_lora_radio_last_tx_ms = 0;
volatile bool mc_lora_radio_tx_ready = true;
bool mc_lora_radio_radio_ready = false;

void mc_lora_radio_tx_done_callback() { mc_lora_radio_tx_ready = true; }

void setup() {
  Serial.begin(115200);
  LoRa.setPins(10, 9, 2);
  if (!LoRa.begin(866.000E6)) Serial.println(F("LoRa init failed: check power, wiring, frequency and module")); else { LoRa.onTxDone(mc_lora_radio_tx_done_callback); mc_lora_radio_radio_ready = true; Serial.println(F("LoRa radio ready")); }
}

void loop() {
  if (mc_lora_radio_radio_ready && mc_lora_radio_tx_ready) {
    int mc_lora_radio_packet_size = LoRa.parsePacket();
    if (mc_lora_radio_packet_size) { Serial.print(F("LoRa RX: ")); while (LoRa.available()) Serial.write((uint8_t)LoRa.read()); Serial.print(F(" | RSSI=")); Serial.println(LoRa.packetRssi()); }
    if ((unsigned long)(millis() - mc_lora_radio_last_tx_ms) >= 10000UL) {
      if (LoRa.beginPacket()) { LoRa.print("MIXER_CODE_NODE_A"); mc_lora_radio_tx_ready = false; mc_lora_radio_last_tx_ms = millis(); if (!LoRa.endPacket(true)) mc_lora_radio_tx_ready = true; }
    }
  }

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
