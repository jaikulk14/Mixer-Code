/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: ESP32 IoT Connectivity Demo
 * Board profile: ESP32 Dev Module
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <WebServer.h>
#include <WiFiUdp.h>
#include <HTTPClient.h>
#include <WiFiClient.h>
#include <time.h>
#include <ArduinoOTA.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306
// Library dependency: PubSubClient
// Library documentation: https://github.com/knolleary/pubsubclient
// Library notes: MQTT client. Requires an ESP32/ESP8266 Wi-Fi profile.

// Pin map
// LDR Light Sensor (ldr) signal: 34
// MQ Gas Sensor (mq_gas) signal: 35
// Soil Moisture (soil_moisture) signal: 32
// OLED Dashboard (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// I2C defaults on this profile: SDA=GPIO21, SCL=GPIO22

Adafruit_SSD1306 oled_dashboard_display(128, 64, &Wire, -1);
const uint8_t ldr_light_sensor_pin = 34;
const uint8_t mq_gas_sensor_pin = 35;
const uint8_t soil_moisture_pin = 32;

// SECURITY: credentials below are embedded in source and project JSON. Do not publish this sketch with real secrets.
const char* mc_wifi_sta_ssid = "DemoNetwork";
const char* mc_wifi_sta_password = "demo-password-123";
unsigned long mc_wifi_sta_last_retry_ms = 0;
WiFiClient mc_mqtt_client_net;
PubSubClient mc_mqtt_client_mqtt(mc_mqtt_client_net);
unsigned long mc_mqtt_client_last_connect_ms = 0;
const char* mc_mqtt_client_sub_topic = "mixercoder/example/in";
const char* mc_mqtt_client_pub_topic = "mixercoder/example/out";
WebServer mc_web_server_server(80);
WiFiUDP mc_udp_listener_udp;
WiFiClient mc_http_get_http_client;
unsigned long mc_http_get_last_request_ms = 0;
unsigned long mc_ntp_sync_last_report_ms = 0;
bool mc_ota_update_started = false;

void mc_mqtt_client_callback(char* topic, byte* payload, unsigned int length) {
  Serial.print(F("MQTT [")); Serial.print(topic); Serial.print(F("] "));
  for (unsigned int i = 0; i < length; ++i) Serial.write(payload[i]); Serial.println();
}
bool mc_mqtt_client_publish(const char* message) { return mc_mqtt_client_mqtt.connected() && mc_mqtt_client_mqtt.publish(mc_mqtt_client_pub_topic, message); }
void mc_mqtt_client_tick() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!mc_mqtt_client_mqtt.connected()) {
    if ((unsigned long)(millis() - mc_mqtt_client_last_connect_ms) >= 5000UL) {
      mc_mqtt_client_last_connect_ms = millis();
      if (mc_mqtt_client_mqtt.connect("MixerCoderExample")) {
        if (strlen(mc_mqtt_client_sub_topic)) mc_mqtt_client_mqtt.subscribe(mc_mqtt_client_sub_topic);
        mc_mqtt_client_mqtt.publish(mc_mqtt_client_pub_topic, "Mixer Code online");
      }
    }
  } else {
    mc_mqtt_client_mqtt.loop();
  }
}
void mc_http_get_tick() {
  if (WiFi.status() != WL_CONNECTED) return;
  if ((unsigned long)(millis() - mc_http_get_last_request_ms) < 60000UL) return;
  mc_http_get_last_request_ms = millis();
  HTTPClient http;
  http.setConnectTimeout(3000); http.setTimeout(3000);
  if (http.begin(mc_http_get_http_client, "http://example.com/")) {
    int code = http.GET();
    Serial.print(F("HTTP status: ")); Serial.println(code);
    if (code > 0) Serial.println(http.getString());
    http.end();
  }
}

unsigned long oled_dashboard_last_update_ms = 0;
void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(ldr_light_sensor_pin, INPUT);
  pinMode(mq_gas_sensor_pin, INPUT);
  pinMode(soil_moisture_pin, INPUT);
  if (!oled_dashboard_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  oled_dashboard_display.clearDisplay(); oled_dashboard_display.setTextSize(1); oled_dashboard_display.setTextColor(SSD1306_WHITE);
  oled_dashboard_display.setCursor(0, 0); oled_dashboard_display.println(F("Mixer Code")); oled_dashboard_display.println(F("OLED ready")); oled_dashboard_display.display();
  WiFi.mode(WIFI_STA);
  WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  Serial.println(F("Wi-Fi station connection started (non-blocking)."));
  mc_mqtt_client_mqtt.setServer("broker.hivemq.com", 1883);
  mc_mqtt_client_mqtt.setCallback(mc_mqtt_client_callback);
  mc_mqtt_client_mqtt.setSocketTimeout(2);
  mc_web_server_server.on("/", []() { mc_web_server_server.send(200, "text/plain", "Mixer Code device online"); });
  mc_web_server_server.on("/status", []() { mc_web_server_server.send(200, "application/json", "{\"status\":\"online\"}"); });
  mc_web_server_server.begin(); Serial.println(F("HTTP status server started"));
  mc_udp_listener_udp.begin(4210);
  configTime(19800, 0, "pool.ntp.org", "time.nist.gov");
  ArduinoOTA.setHostname("mixer-coder-demo");
  ArduinoOTA.setPassword("replace-this-ota-password");
}

void loop() {
  int ldr_light_sensor_value = analogRead(ldr_light_sensor_pin);
  int mq_gas_sensor_value = analogRead(mq_gas_sensor_pin);
  int soil_moisture_value = analogRead(soil_moisture_pin);

  if (WiFi.status() == WL_CONNECTED) { /* Connected */ } else if ((unsigned long)(millis() - mc_wifi_sta_last_retry_ms) >= 10000UL) {
    mc_wifi_sta_last_retry_ms = millis(); WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  }
  mc_mqtt_client_tick();
  mc_web_server_server.handleClient();
  int mc_udp_listener_packet_size = mc_udp_listener_udp.parsePacket();
  if (mc_udp_listener_packet_size > 0) { char mc_udp_listener_buffer[256]; int mc_udp_listener_n = mc_udp_listener_udp.read(mc_udp_listener_buffer, sizeof(mc_udp_listener_buffer) - 1); if (mc_udp_listener_n < 0) mc_udp_listener_n = 0; mc_udp_listener_buffer[mc_udp_listener_n] = '\0'; Serial.print(F("UDP: ")); Serial.println(mc_udp_listener_buffer); }
  mc_http_get_tick();
  if ((unsigned long)(millis() - mc_ntp_sync_last_report_ms) >= 60000UL) {
    mc_ntp_sync_last_report_ms = millis(); time_t mc_ntp_sync_now = time(nullptr);
    if (mc_ntp_sync_now > 100000) { char mc_ntp_sync_time_text[32]; struct tm mc_ntp_sync_time_info; localtime_r(&mc_ntp_sync_now, &mc_ntp_sync_time_info); strftime(mc_ntp_sync_time_text, sizeof(mc_ntp_sync_time_text), "%Y-%m-%d %H:%M:%S", &mc_ntp_sync_time_info); Serial.println(mc_ntp_sync_time_text); } else Serial.println(F("NTP time not synchronized yet"));
  }
  if (WiFi.status() == WL_CONNECTED && !mc_ota_update_started) { ArduinoOTA.begin(); mc_ota_update_started = true; Serial.println(F("OTA ready on local network")); }
  if (mc_ota_update_started) ArduinoOTA.handle();

  if ((unsigned long)(millis() - oled_dashboard_last_update_ms) >= 300UL) {
    oled_dashboard_last_update_ms = millis();
    oled_dashboard_display.clearDisplay();
    oled_dashboard_display.setTextSize(1);
    oled_dashboard_display.setCursor(0, 0); oled_dashboard_display.println(F("IOT STATUS"));
    oled_dashboard_display.setCursor(0, 12); oled_dashboard_display.print(F("LDR Light Se"));
    oled_dashboard_display.setCursor(100, 12); oled_dashboard_display.print(ldr_light_sensor_value);
    oled_dashboard_display.drawRect(0, 20, 128, 7, SSD1306_WHITE);
    oled_dashboard_display.fillRect(2, 22, (uint8_t)((long)ldr_light_sensor_value * 124L / 4095L), 3, SSD1306_WHITE);
    oled_dashboard_display.setCursor(0, 29); oled_dashboard_display.print(F("MQ Gas Senso"));
    oled_dashboard_display.setCursor(100, 29); oled_dashboard_display.print(mq_gas_sensor_value);
    oled_dashboard_display.drawRect(0, 37, 128, 7, SSD1306_WHITE);
    oled_dashboard_display.fillRect(2, 39, (uint8_t)((long)mq_gas_sensor_value * 124L / 4095L), 3, SSD1306_WHITE);
    oled_dashboard_display.setCursor(0, 46); oled_dashboard_display.print(F("Soil Moistur"));
    oled_dashboard_display.setCursor(100, 46); oled_dashboard_display.print(soil_moisture_value);
    oled_dashboard_display.drawRect(0, 54, 128, 7, SSD1306_WHITE);
    oled_dashboard_display.fillRect(2, 56, (uint8_t)((long)soil_moisture_value * 124L / 4095L), 3, SSD1306_WHITE);
    oled_dashboard_display.display();
  }

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
