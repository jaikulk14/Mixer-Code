/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Touch Sensor Threshold Only
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

// Pin map
// Touch Sensor (touch_sensor) signal: 2
// LED (led) signal: 3

const uint8_t touch_sensor_pin = 2;
const uint8_t led_pin = 3;

void setup() {
  Serial.begin(115200);
  pinMode(touch_sensor_pin, INPUT);
  pinMode(led_pin, OUTPUT);
  digitalWrite(led_pin, LOW);
}

void loop() {
  bool touch_sensor_state = (digitalRead(touch_sensor_pin) == HIGH);

  // Logic for LED. First matching rule wins.
  if (touch_sensor_state) {
    digitalWrite(led_pin, HIGH);
  }
  else {
    digitalWrite(led_pin, LOW); // Safe default when no rule matches
  }

  delay(20); // Small loop pause; tune for your application.
}
