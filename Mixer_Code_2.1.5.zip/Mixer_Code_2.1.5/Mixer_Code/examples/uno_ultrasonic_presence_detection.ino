/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Ultrasonic Presence Detection
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

// Pin map
// Ultrasonic (hc_sr04) trig: 2
// Ultrasonic (hc_sr04) echo: 3
// Detected LED (led) signal: 4
// No Echo Buzzer (buzzer) signal: 5

const uint8_t ultrasonic_trig_pin = 2;
const uint8_t ultrasonic_echo_pin = 3;
bool ultrasonic_detected = false; // True when a valid ultrasonic echo is received.
const uint8_t detected_led_pin = 4;
const uint8_t no_echo_buzzer_pin = 5;

float readDistanceCm(uint8_t trigPin, uint8_t echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  unsigned long duration = pulseIn(echoPin, HIGH, 30000UL);
  if (duration == 0) return -1.0f; // No echo / out of range
  return (duration * 0.0343f) / 2.0f;
}

void setup() {
  Serial.begin(115200);
  pinMode(ultrasonic_trig_pin, OUTPUT); pinMode(ultrasonic_echo_pin, INPUT);
  digitalWrite(ultrasonic_trig_pin, LOW);
  pinMode(detected_led_pin, OUTPUT);
  digitalWrite(detected_led_pin, LOW);
  pinMode(no_echo_buzzer_pin, OUTPUT);
  digitalWrite(no_echo_buzzer_pin, LOW);
}

void loop() {
  float ultrasonic_distance_cm = readDistanceCm(ultrasonic_trig_pin, ultrasonic_echo_pin);
  ultrasonic_detected = (ultrasonic_distance_cm >= 0.0f);

  // Logic for Detected LED. First matching rule wins.
  if (ultrasonic_detected) {
    digitalWrite(detected_led_pin, HIGH);
  }
  else {
    digitalWrite(detected_led_pin, LOW); // Safe default when no rule matches
  }

  // Logic for No Echo Buzzer. First matching rule wins.
  if (!ultrasonic_detected) {
    digitalWrite(no_echo_buzzer_pin, HIGH);
  }
  else {
    digitalWrite(no_echo_buzzer_pin, LOW); // Safe default when no rule matches
  }

  delay(20); // Small loop pause; tune for your application.
}
