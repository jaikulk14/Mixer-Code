/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: MQ Monitor Plus Threshold Alarm
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

// Pin map
// MQ Gas (mq_gas) signal: A0
// Warning LED (led) signal: 3

const uint8_t mq_gas_pin = A0;
const uint8_t warning_led_pin = 3;

unsigned long mq_gas_monitor_last_ms = 0;
void setup() {
  Serial.begin(115200);
  pinMode(mq_gas_pin, INPUT);
  pinMode(warning_led_pin, OUTPUT);
  digitalWrite(warning_led_pin, LOW);
}

void loop() {
  // Independent cooperative tasks and continuous sensor monitors.
  int mq_gas_value = analogRead(mq_gas_pin);
  if ((unsigned long)(millis() - mq_gas_monitor_last_ms) >= 250UL) {
    mq_gas_monitor_last_ms = millis();
    Serial.print(F("MONITOR,mq_gas,ANALOG,")); Serial.println(mq_gas_value);
  }

  // Logic for Warning LED. First matching rule wins.
  if (mq_gas_value > 700) {
    digitalWrite(warning_led_pin, HIGH);
  }
  else {
    digitalWrite(warning_led_pin, LOW); // Safe default when no rule matches
  }

  // No blocking delay: independent tasks and continuous monitors stay responsive.
}
