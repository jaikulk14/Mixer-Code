/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: MQ Gas Sensor OLED Auto Dashboard
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306

// Pin map
// SSD1306 OLED (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// MQ Gas Sensor 1 (mq_gas) signal: A0
// I2C pins: SDA=A4, SCL=A5

Adafruit_SSD1306 ssd1306_oled_display(128, 64, &Wire, -1);
const uint8_t mq_gas_sensor_1_pin = A0;

unsigned long ssd1306_oled_last_update_ms = 0;
void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(mq_gas_sensor_1_pin, INPUT);
  if (!ssd1306_oled_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  ssd1306_oled_display.clearDisplay(); ssd1306_oled_display.setTextSize(1); ssd1306_oled_display.setTextColor(SSD1306_WHITE);
  ssd1306_oled_display.setCursor(0, 0); ssd1306_oled_display.println(F("Mixer Code")); ssd1306_oled_display.println(F("OLED ready")); ssd1306_oled_display.display();
}

void loop() {
  int mq_gas_sensor_1_value = analogRead(mq_gas_sensor_1_pin);

  // Automatic OLED dashboard: displays the first 1 analog input(s) until a custom layout is saved.
  if ((unsigned long)(millis() - ssd1306_oled_last_update_ms) >= 250UL) {
    ssd1306_oled_last_update_ms = millis();
    ssd1306_oled_display.clearDisplay();
    ssd1306_oled_display.setTextSize(1);
    ssd1306_oled_display.setCursor(0, 0); ssd1306_oled_display.println(F("SENSOR MONITOR"));
    ssd1306_oled_display.setCursor(0, 15); ssd1306_oled_display.println(F("MQ Gas Sensor 1"));
    ssd1306_oled_display.setTextSize(2); ssd1306_oled_display.setCursor(0, 28); ssd1306_oled_display.print(mq_gas_sensor_1_value);
    ssd1306_oled_display.setTextSize(1);
    ssd1306_oled_display.drawRect(0, 53, 128, 9, SSD1306_WHITE);
    ssd1306_oled_display.fillRect(2, 55, (uint8_t)((long)mq_gas_sensor_1_value * 124L / 1023L), 5, SSD1306_WHITE);
    ssd1306_oled_display.display();
  }

  delay(20); // Small loop pause; tune for your application.
}
