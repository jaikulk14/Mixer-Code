/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Uno ESP8266 AT Modem Demo
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <SoftwareSerial.h>

// Pin map

SoftwareSerial mc_esp8266_at_wifi_modem(10, 11);

bool mc_esp8266_at_wifi_sendAT(const char* command, const char* expected, unsigned long timeoutMs) {
  while (mc_esp8266_at_wifi_modem.available()) mc_esp8266_at_wifi_modem.read();
  mc_esp8266_at_wifi_modem.println(command);
  unsigned long started = millis();
  String response;
  while ((unsigned long)(millis() - started) < timeoutMs) { while (mc_esp8266_at_wifi_modem.available()) { char ch = (char)mc_esp8266_at_wifi_modem.read(); response += ch; Serial.write(ch); if (response.indexOf(expected) >= 0) return true; if (response.indexOf("ERROR") >= 0) return false; } }
  return false;
}

void setup() {
  Serial.begin(115200);
  mc_esp8266_at_wifi_modem.begin(9600);
  Serial.println(F("ESP8266 AT modem: checking firmware"));
  if (!mc_esp8266_at_wifi_sendAT("AT", "OK", 2000)) Serial.println(F("No AT response. Check baud, wiring and ESP-AT firmware."));
  mc_esp8266_at_wifi_sendAT("ATE0", "OK", 1000);
  mc_esp8266_at_wifi_sendAT("AT+CWMODE=1", "OK", 2000);
  String mc_esp8266_at_wifi_join = String("AT+CWJAP=\"") + "DemoNetwork" + "\",\"" + "demo-password-123" + "\"";
  if (!mc_esp8266_at_wifi_sendAT(mc_esp8266_at_wifi_join.c_str(), "OK", 20000)) Serial.println(F("Wi-Fi join failed; check credentials and module firmware."));
}

void loop() {
  delay(20); // Small loop pause; tune for your application.
}
