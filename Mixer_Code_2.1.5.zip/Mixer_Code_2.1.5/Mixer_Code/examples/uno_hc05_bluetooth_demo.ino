/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Uno HC-05 Bluetooth UART Demo
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <SoftwareSerial.h>

// Pin map
// Push Button (push_button) signal: 2
// Status LED (led) signal: 5

const uint8_t push_button_pin = 2;
const uint8_t status_led_pin = 5;

SoftwareSerial mc_hc05_bluetooth_serial(10, 11);

void setup() {
  Serial.begin(115200);
  pinMode(push_button_pin, INPUT_PULLUP);
  pinMode(status_led_pin, OUTPUT);
  digitalWrite(status_led_pin, LOW);
  mc_hc05_bluetooth_serial.begin(9600);
}

void loop() {
  bool push_button_state = (digitalRead(push_button_pin) == LOW);

  while (mc_hc05_bluetooth_serial.available()) Serial.write(mc_hc05_bluetooth_serial.read());
  while (Serial.available()) mc_hc05_bluetooth_serial.write(Serial.read());

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
