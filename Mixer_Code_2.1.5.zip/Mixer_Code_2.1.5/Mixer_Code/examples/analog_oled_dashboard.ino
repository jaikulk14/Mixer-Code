/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Analog OLED Sensor Dashboard
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306

// Pin map
// SSD1306 OLED (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// LDR Light (ldr) signal: A0
// Soil Moisture (soil_moisture) signal: A1
// MQ Gas Level (mq_gas) signal: A2
// I2C pins: SDA=A4, SCL=A5

Adafruit_SSD1306 ssd1306_oled_display(128, 64, &Wire, -1);
const uint8_t ldr_light_pin = A0;
const uint8_t soil_moisture_pin = A1;
const uint8_t mq_gas_level_pin = A2;

unsigned long ssd1306_oled_last_update_ms = 0;
void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(ldr_light_pin, INPUT);
  pinMode(soil_moisture_pin, INPUT);
  pinMode(mq_gas_level_pin, INPUT);
  if (!ssd1306_oled_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  ssd1306_oled_display.clearDisplay(); ssd1306_oled_display.setTextSize(1); ssd1306_oled_display.setTextColor(SSD1306_WHITE);
  ssd1306_oled_display.setCursor(0, 0); ssd1306_oled_display.println(F("Mixer Code")); ssd1306_oled_display.println(F("OLED ready")); ssd1306_oled_display.display();
}

void loop() {
  int ldr_light_value = analogRead(ldr_light_pin);
  int soil_moisture_value = analogRead(soil_moisture_pin);
  int mq_gas_level_value = analogRead(mq_gas_level_pin);

  if ((unsigned long)(millis() - ssd1306_oled_last_update_ms) >= 250UL) {
    ssd1306_oled_last_update_ms = millis();
    ssd1306_oled_display.clearDisplay();
    ssd1306_oled_display.setTextSize(1);
    ssd1306_oled_display.setCursor(0, 0); ssd1306_oled_display.println(F("SENSOR MONITOR"));
    ssd1306_oled_display.setCursor(0, 12); ssd1306_oled_display.print(F("LDR Light"));
    ssd1306_oled_display.setCursor(100, 12); ssd1306_oled_display.print(ldr_light_value);
    ssd1306_oled_display.drawRect(0, 20, 128, 7, SSD1306_WHITE);
    ssd1306_oled_display.fillRect(2, 22, (uint8_t)((long)ldr_light_value * 124L / 1023L), 3, SSD1306_WHITE);
    ssd1306_oled_display.setCursor(0, 29); ssd1306_oled_display.print(F("Soil Moistur"));
    ssd1306_oled_display.setCursor(100, 29); ssd1306_oled_display.print(soil_moisture_value);
    ssd1306_oled_display.drawRect(0, 37, 128, 7, SSD1306_WHITE);
    ssd1306_oled_display.fillRect(2, 39, (uint8_t)((long)soil_moisture_value * 124L / 1023L), 3, SSD1306_WHITE);
    ssd1306_oled_display.setCursor(0, 46); ssd1306_oled_display.print(F("MQ Gas Level"));
    ssd1306_oled_display.setCursor(100, 46); ssd1306_oled_display.print(mq_gas_level_value);
    ssd1306_oled_display.drawRect(0, 54, 128, 7, SSD1306_WHITE);
    ssd1306_oled_display.fillRect(2, 56, (uint8_t)((long)mq_gas_level_value * 124L / 1023L), 3, SSD1306_WHITE);
    ssd1306_oled_display.display();
  }

  delay(20); // Small loop pause; tune for your application.
}
