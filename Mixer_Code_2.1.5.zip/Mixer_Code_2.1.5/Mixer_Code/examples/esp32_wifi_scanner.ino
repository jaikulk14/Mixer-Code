/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: ESP32 Wi-Fi Scanner
 * Board profile: ESP32 Dev Module
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <WiFi.h>

// Pin map

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);
  Serial.println(F("Scanning Wi-Fi networks..."));
  int networkCount = WiFi.scanNetworks();
  if (networkCount < 0) Serial.println(F("Wi-Fi scan failed"));
  for (int i = 0; i < networkCount; ++i) { Serial.print(WiFi.SSID(i)); Serial.print(F(" RSSI=")); Serial.print(WiFi.RSSI(i)); Serial.println(F(" dBm")); }
  WiFi.scanDelete();
}

void loop() {
  delay(20); // Small loop pause; tune for your application.
}
