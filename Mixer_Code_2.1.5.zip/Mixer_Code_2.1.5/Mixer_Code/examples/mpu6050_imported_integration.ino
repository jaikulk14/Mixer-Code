/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: MPU6050 Imported Integration
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <MPU6050.h>

// Custom component: MPU6050
// Wiring / notes: Imported from one complete integration sketch. Confirm that the installed MPU6050 library matches initialize(), testConnection() and getMotion6() API. The imported delay(500) blocks other cooperative tasks while waiting.
// Library dependency: MPU6050
// Library notes: Suggested from header name only. Confirm the exact Library Manager package and its API before installing.

// Pin map

// Custom component declarations and helper functions: MPU6050
MPU6050 mpu;

void setup() {
  // Serial is initialized by an imported custom component.
  // Custom component setup: MPU6050
  Serial.begin(9600);
  Wire.begin();
  mpu.initialize();

  if (mpu.testConnection()) {
    Serial.println("MPU6050 connection successful");
  } else {
    Serial.println("MPU6050 connection failed");
  }
}

void loop() {
  // Custom component loop code: MPU6050
  int16_t ax, ay, az;
  int16_t gx, gy, gz;

  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  Serial.print("Accel: ");
  Serial.print("X = "); Serial.print(ax);
  Serial.print(" | Y = "); Serial.print(ay);
  Serial.print(" | Z = "); Serial.println(az);

  Serial.print("Gyro: ");
  Serial.print("X = "); Serial.print(gx);
  Serial.print(" | Y = "); Serial.print(gy);
  Serial.print(" | Z = "); Serial.println(gz);

  delay(500);

  // Imported custom loop code controls its own timing; review delay() calls before combining with tasks.
}
