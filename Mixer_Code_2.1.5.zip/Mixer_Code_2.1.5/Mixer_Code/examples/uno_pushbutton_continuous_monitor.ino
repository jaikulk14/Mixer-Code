/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Push Button Continuous Monitor
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

// Pin map
// Push Button (push_button) signal: 2

const uint8_t push_button_pin = 2;

unsigned long push_button_monitor_last_ms = 0;
void setup() {
  Serial.begin(115200);
  pinMode(push_button_pin, INPUT_PULLUP);
}

void loop() {
  // Independent cooperative tasks and continuous sensor monitors.
  bool push_button_state = (digitalRead(push_button_pin) == LOW);
  if ((unsigned long)(millis() - push_button_monitor_last_ms) >= 100UL) {
    push_button_monitor_last_ms = millis();
    Serial.print(F("MONITOR,push_button,DIGITAL,")); Serial.println(push_button_state ? F("ACTIVE") : F("INACTIVE"));
  }

  // No blocking delay: independent tasks and continuous monitors stay responsive.
}
