/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Uno Bus and SD Card Demo
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <SPI.h>
#include <SD.h>

// Pin map

unsigned long mc_spi_transfer_last_ms = 0;
unsigned long mc_sd_logger_last_log_ms = 0;

uint8_t mc_spi_transfer_transfer(uint8_t value) { SPI.beginTransaction(SPISettings(1000000UL, MSBFIRST, SPI_MODE0)); digitalWrite(10, LOW); uint8_t received = SPI.transfer(value); digitalWrite(10, HIGH); SPI.endTransaction(); return received; }

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Serial.println(F("I2C scan start"));
  for (uint8_t address = 1; address < 127; ++address) { Wire.beginTransmission(address); uint8_t error = Wire.endTransmission(); if (error == 0) { Serial.print(F("I2C device: 0x")); if (address < 16) Serial.print('0'); Serial.println(address, HEX); } }
  Serial.println(F("I2C scan complete"));
  SPI.begin();
  pinMode(10, OUTPUT); digitalWrite(10, HIGH);
  if (!SD.begin(4)) Serial.println(F("SD card initialization failed")); else { File f = SD.open("mixer.csv", FILE_WRITE); if (f) { if (f.size() == 0) f.println(F("uptime_ms")); f.close(); } }
}

void loop() {
  if ((unsigned long)(millis() - mc_spi_transfer_last_ms) >= 1000UL) { mc_spi_transfer_last_ms = millis(); uint8_t response = mc_spi_transfer_transfer(0); Serial.print(F("SPI RX: ")); Serial.println(response); }
  if ((unsigned long)(millis() - mc_sd_logger_last_log_ms) >= 1000UL) {
    mc_sd_logger_last_log_ms = millis(); File f = SD.open("mixer.csv", FILE_WRITE); if (f) { f.println(millis()); f.close(); } else Serial.println(F("SD log open failed"));
  }

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
