/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: ESP8266 Web Status Demo
 * Board profile: ESP8266 NodeMCU / ESP-12E
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <WiFiUdp.h>

// Pin map
// LDR Light Sensor (ldr) signal: A0

const uint8_t ldr_light_sensor_pin = A0;

// SECURITY: credentials below are embedded in source and project JSON. Do not publish this sketch with real secrets.
const char* mc_wifi_sta_ssid = "DemoNetwork";
const char* mc_wifi_sta_password = "demo-password-123";
unsigned long mc_wifi_sta_last_retry_ms = 0;
ESP8266WebServer mc_web_server_server(80);
WiFiUDP mc_udp_listener_udp;

void setup() {
  Serial.begin(115200);
  pinMode(ldr_light_sensor_pin, INPUT);
  WiFi.mode(WIFI_STA);
  WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  Serial.println(F("Wi-Fi station connection started (non-blocking)."));
  mc_web_server_server.on("/", []() { mc_web_server_server.send(200, "text/plain", "Mixer Code device online"); });
  mc_web_server_server.on("/status", []() { mc_web_server_server.send(200, "application/json", "{\"status\":\"online\"}"); });
  mc_web_server_server.begin(); Serial.println(F("HTTP status server started"));
  mc_udp_listener_udp.begin(4210);
}

void loop() {
  int ldr_light_sensor_value = analogRead(ldr_light_sensor_pin);

  if (WiFi.status() == WL_CONNECTED) { /* Connected */ } else if ((unsigned long)(millis() - mc_wifi_sta_last_retry_ms) >= 10000UL) {
    mc_wifi_sta_last_retry_ms = millis(); WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  }
  mc_web_server_server.handleClient();
  int mc_udp_listener_packet_size = mc_udp_listener_udp.parsePacket();
  if (mc_udp_listener_packet_size > 0) { char mc_udp_listener_buffer[256]; int mc_udp_listener_n = mc_udp_listener_udp.read(mc_udp_listener_buffer, sizeof(mc_udp_listener_buffer) - 1); if (mc_udp_listener_n < 0) mc_udp_listener_n = 0; mc_udp_listener_buffer[mc_udp_listener_n] = '\0'; Serial.print(F("UDP: ")); Serial.println(mc_udp_listener_buffer); }

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
