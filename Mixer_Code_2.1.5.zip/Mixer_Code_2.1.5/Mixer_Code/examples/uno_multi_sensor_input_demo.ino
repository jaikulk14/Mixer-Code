/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Multi Sensor Input Demo
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

// Pin map
// Rain Level (rain_sensor_analog) signal: A0
// Water Level (water_level) signal: A1
// IR Obstacle (ir_obstacle) signal: 2
// Vibration (vibration_sensor) signal: 3
// Status LED (led) signal: 4

const uint8_t rain_level_pin = A0;
const uint8_t water_level_pin = A1;
const uint8_t ir_obstacle_pin = 2;
const uint8_t vibration_pin = 3;
const uint8_t status_led_pin = 4;

void setup() {
  Serial.begin(115200);
  pinMode(rain_level_pin, INPUT);
  pinMode(water_level_pin, INPUT);
  pinMode(ir_obstacle_pin, INPUT);
  pinMode(vibration_pin, INPUT);
  pinMode(status_led_pin, OUTPUT);
  digitalWrite(status_led_pin, LOW);
}

void loop() {
  int rain_level_value = analogRead(rain_level_pin);
  int water_level_value = analogRead(water_level_pin);
  bool ir_obstacle_state = (digitalRead(ir_obstacle_pin) == LOW);
  bool vibration_state = (digitalRead(vibration_pin) == LOW);

  // Logic for Status LED. First matching rule wins.
  if (ir_obstacle_state) {
    digitalWrite(status_led_pin, HIGH);
  }
  else {
    digitalWrite(status_led_pin, LOW); // Safe default when no rule matches
  }

  delay(20); // Small loop pause; tune for your application.
}
