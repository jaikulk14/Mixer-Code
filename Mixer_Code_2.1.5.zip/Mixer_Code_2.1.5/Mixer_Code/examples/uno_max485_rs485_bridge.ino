/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Arduino Uno MAX485 RS-485 Bridge
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <SoftwareSerial.h>

// Pin map

SoftwareSerial mc_rs485_half_duplex_serial(8, 9);

void setup() {
  Serial.begin(115200);
  pinMode(4, OUTPUT);
  digitalWrite(4, LOW); // Receive mode
  mc_rs485_half_duplex_serial.begin(9600);
}

void loop() {
  while (mc_rs485_half_duplex_serial.available()) Serial.write(mc_rs485_half_duplex_serial.read());
  if (Serial.available()) { digitalWrite(4, HIGH); while (Serial.available()) mc_rs485_half_duplex_serial.write(Serial.read()); mc_rs485_half_duplex_serial.flush(); digitalWrite(4, LOW); }

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
