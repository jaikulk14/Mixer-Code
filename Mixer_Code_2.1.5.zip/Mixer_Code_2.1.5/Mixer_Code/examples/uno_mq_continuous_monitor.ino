/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: MQ Analog Continuous Monitor
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306

// Pin map
// MQ Gas (mq_gas) signal: A0
// OLED (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// I2C pins: SDA=A4, SCL=A5

Adafruit_SSD1306 oled_display(128, 64, &Wire, -1);
const uint8_t mq_gas_pin = A0;

unsigned long oled_last_update_ms = 0;
unsigned long mq_gas_monitor_last_ms = 0;
void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(mq_gas_pin, INPUT);
  if (!oled_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  oled_display.clearDisplay(); oled_display.setTextSize(1); oled_display.setTextColor(SSD1306_WHITE);
  oled_display.setCursor(0, 0); oled_display.println(F("Mixer Code")); oled_display.println(F("OLED ready")); oled_display.display();
}

void loop() {
  // Independent cooperative tasks and continuous sensor monitors.
  int mq_gas_value = analogRead(mq_gas_pin);
  if ((unsigned long)(millis() - mq_gas_monitor_last_ms) >= 500UL) {
    mq_gas_monitor_last_ms = millis();
    Serial.print(F("MONITOR,mq_gas,ANALOG,")); Serial.println(mq_gas_value);
  }

  // Automatic OLED dashboard: displays the first 1 analog input(s) until a custom layout is saved.
  if ((unsigned long)(millis() - oled_last_update_ms) >= 250UL) {
    oled_last_update_ms = millis();
    oled_display.clearDisplay();
    oled_display.setTextSize(1);
    oled_display.setCursor(0, 0); oled_display.println(F("SENSOR MONITOR"));
    oled_display.setCursor(0, 15); oled_display.println(F("MQ Gas"));
    oled_display.setTextSize(2); oled_display.setCursor(0, 28); oled_display.print(mq_gas_value);
    oled_display.setTextSize(1);
    oled_display.drawRect(0, 53, 128, 9, SSD1306_WHITE);
    oled_display.fillRect(2, 55, (uint8_t)((long)mq_gas_value * 124L / 1023L), 5, SSD1306_WHITE);
    oled_display.display();
  }

  // No blocking delay: independent tasks and continuous monitors stay responsive.
}
