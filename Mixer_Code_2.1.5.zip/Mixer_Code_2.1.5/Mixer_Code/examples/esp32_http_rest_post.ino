/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: ESP32 HTTP REST POST Demo
 * Board profile: ESP32 Dev Module
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClient.h>

// Pin map

// SECURITY: credentials below are embedded in source and project JSON. Do not publish this sketch with real secrets.
const char* mc_wifi_sta_ssid = "LabNetwork";
const char* mc_wifi_sta_password = "demo-wifi-password";
unsigned long mc_wifi_sta_last_retry_ms = 0;
WiFiClient mc_http_get_http_client;
unsigned long mc_http_get_last_request_ms = 0;

void mc_http_get_tick() {
  if (WiFi.status() != WL_CONNECTED) return;
  if ((unsigned long)(millis() - mc_http_get_last_request_ms) < 30000UL) return;
  mc_http_get_last_request_ms = millis();
  HTTPClient http;
  http.setConnectTimeout(3000); http.setTimeout(3000);
  if (http.begin(mc_http_get_http_client, "http://192.168.1.100/api/telemetry")) {
    int code = http.POST(String("{\"device\":\"mixer-coder\",\"value\":42}"));
    Serial.print(F("HTTP status: ")); Serial.println(code);
    if (code > 0) Serial.println(http.getString());
    http.end();
  }
}

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);
  WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  Serial.println(F("Wi-Fi station connection started (non-blocking)."));
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) { /* Connected */ } else if ((unsigned long)(millis() - mc_wifi_sta_last_retry_ms) >= 10000UL) {
    mc_wifi_sta_last_retry_ms = millis(); WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  }
  mc_http_get_tick();

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
