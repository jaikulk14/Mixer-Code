/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: HC-SR04 Continuous Monitor
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306

// Pin map
// Ultrasonic (hc_sr04) trig: 2
// Ultrasonic (hc_sr04) echo: 3
// OLED (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// I2C pins: SDA=A4, SCL=A5

Adafruit_SSD1306 oled_display(128, 64, &Wire, -1);
const uint8_t ultrasonic_trig_pin = 2;
const uint8_t ultrasonic_echo_pin = 3;
bool ultrasonic_detected = false; // True when a valid ultrasonic echo is received.

unsigned long oled_last_update_ms = 0;
float ultrasonic_distance_cm = -1.0f;
uint8_t sensor_monitor_ultrasonic_state = 0; // 0=wait, 1=wait for echo HIGH, 2=wait for echo LOW
unsigned long sensor_monitor_ultrasonic_state_started_us = 0;
unsigned long sensor_monitor_ultrasonic_echo_started_us = 0;
unsigned long sensor_monitor_ultrasonic_last_ping_us = 0;
void tick_sensor_monitor_ultrasonic() {
  unsigned long nowUs = micros();
  if (sensor_monitor_ultrasonic_state == 0) {
    if ((unsigned long)(nowUs - sensor_monitor_ultrasonic_last_ping_us) >= 100UL * 1000UL) {
      digitalWrite(ultrasonic_trig_pin, LOW);
      delayMicroseconds(2);
      digitalWrite(ultrasonic_trig_pin, HIGH);
      delayMicroseconds(10);
      digitalWrite(ultrasonic_trig_pin, LOW);
      sensor_monitor_ultrasonic_state_started_us = micros();
      sensor_monitor_ultrasonic_state = 1;
    }
  } else if (sensor_monitor_ultrasonic_state == 1) {
    if (digitalRead(ultrasonic_echo_pin) == HIGH) { sensor_monitor_ultrasonic_echo_started_us = micros(); sensor_monitor_ultrasonic_state = 2; }
    else if ((unsigned long)(nowUs - sensor_monitor_ultrasonic_state_started_us) > 30000UL) {
      ultrasonic_distance_cm = -1.0f;
      ultrasonic_detected = false;
      Serial.print(F("MONITOR,ultrasonic,DISTANCE_CM,")); Serial.println(-1);
      sensor_monitor_ultrasonic_last_ping_us = nowUs; sensor_monitor_ultrasonic_state = 0;
    }
  } else if (sensor_monitor_ultrasonic_state == 2) {
    if (digitalRead(ultrasonic_echo_pin) == LOW) {
      unsigned long duration = (unsigned long)(micros() - sensor_monitor_ultrasonic_echo_started_us);
      ultrasonic_distance_cm = (duration * 0.0343f) / 2.0f;
      ultrasonic_detected = true;
      Serial.print(F("MONITOR,ultrasonic,DISTANCE_CM,")); Serial.println(ultrasonic_distance_cm, 1);
      sensor_monitor_ultrasonic_last_ping_us = micros(); sensor_monitor_ultrasonic_state = 0;
    } else if ((unsigned long)(nowUs - sensor_monitor_ultrasonic_echo_started_us) > 30000UL) {
      ultrasonic_distance_cm = -1.0f;
      ultrasonic_detected = false;
      Serial.print(F("MONITOR,ultrasonic,DISTANCE_CM,")); Serial.println(-1);
      sensor_monitor_ultrasonic_last_ping_us = nowUs; sensor_monitor_ultrasonic_state = 0;
    }
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(ultrasonic_trig_pin, OUTPUT); pinMode(ultrasonic_echo_pin, INPUT);
  digitalWrite(ultrasonic_trig_pin, LOW);
  if (!oled_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  oled_display.clearDisplay(); oled_display.setTextSize(1); oled_display.setTextColor(SSD1306_WHITE);
  oled_display.setCursor(0, 0); oled_display.println(F("Mixer Code")); oled_display.println(F("OLED ready")); oled_display.display();
}

void loop() {
  // Independent cooperative tasks and continuous sensor monitors.
  tick_sensor_monitor_ultrasonic();

  if ((unsigned long)(millis() - oled_last_update_ms) >= 100UL) {
    oled_last_update_ms = millis();
    oled_display.clearDisplay();
    oled_display.setTextSize(1);
    oled_display.setCursor(0, 0); oled_display.println(F("LIVE SENSOR MONITOR"));
    oled_display.setCursor(0, 13); oled_display.print(F("Ultrasonic: ")); if (ultrasonic_distance_cm < 0) oled_display.print(F("No echo")); else { oled_display.print(ultrasonic_distance_cm, 1); oled_display.print(F(" cm")); }
    oled_display.display();
  }

  // No blocking delay: independent tasks and continuous monitors stay responsive.
}
