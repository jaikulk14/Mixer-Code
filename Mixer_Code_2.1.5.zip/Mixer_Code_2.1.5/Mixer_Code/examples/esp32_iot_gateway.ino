/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: ESP32 IoT Gateway
 * Board profile: ESP32 Dev Module
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <WebServer.h>
#include <WiFiUdp.h>
#include <time.h>
#include <ArduinoOTA.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306
// Library dependency: PubSubClient
// Library documentation: https://github.com/knolleary/pubsubclient
// Library notes: MQTT client. Requires an ESP32/ESP8266 Wi-Fi profile.

// Pin map
// Gateway OLED (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// Room Light (ldr) signal: 34
// MQ Gas Sensor (mq_gas) signal: 35
// I2C defaults on this profile: SDA=GPIO21, SCL=GPIO22

Adafruit_SSD1306 gateway_oled_display(128, 64, &Wire, -1);
const uint8_t room_light_pin = 34;
const uint8_t mq_gas_sensor_pin = 35;

// SECURITY: credentials below are embedded in source and project JSON. Do not publish this sketch with real secrets.
const char* mc_wifi_sta_ssid = "LabNetwork";
const char* mc_wifi_sta_password = "demo-wifi-password";
unsigned long mc_wifi_sta_last_retry_ms = 0;
WiFiClient mc_mqtt_client_net;
PubSubClient mc_mqtt_client_mqtt(mc_mqtt_client_net);
unsigned long mc_mqtt_client_last_connect_ms = 0;
const char* mc_mqtt_client_sub_topic = "mixercode/demo/in";
const char* mc_mqtt_client_pub_topic = "mixercode/demo/out";
WebServer mc_web_server_server(80);
WiFiUDP mc_udp_listener_udp;
unsigned long mc_ntp_sync_last_report_ms = 0;
bool mc_ota_update_started = false;

void mc_mqtt_client_callback(char* topic, byte* payload, unsigned int length) {
  Serial.print(F("MQTT [")); Serial.print(topic); Serial.print(F("] "));
  for (unsigned int i = 0; i < length; ++i) Serial.write(payload[i]); Serial.println();
}
bool mc_mqtt_client_publish(const char* message) { return mc_mqtt_client_mqtt.connected() && mc_mqtt_client_mqtt.publish(mc_mqtt_client_pub_topic, message); }
void mc_mqtt_client_tick() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!mc_mqtt_client_mqtt.connected()) {
    if ((unsigned long)(millis() - mc_mqtt_client_last_connect_ms) >= 5000UL) {
      mc_mqtt_client_last_connect_ms = millis();
      if (mc_mqtt_client_mqtt.connect("MixerCodeGatewayDemo")) {
        if (strlen(mc_mqtt_client_sub_topic)) mc_mqtt_client_mqtt.subscribe(mc_mqtt_client_sub_topic);
        mc_mqtt_client_mqtt.publish(mc_mqtt_client_pub_topic, "Mixer Code online");
      }
    }
  } else {
    mc_mqtt_client_mqtt.loop();
  }
}

unsigned long gateway_oled_last_update_ms = 0;
void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(room_light_pin, INPUT);
  pinMode(mq_gas_sensor_pin, INPUT);
  if (!gateway_oled_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  gateway_oled_display.clearDisplay(); gateway_oled_display.setTextSize(1); gateway_oled_display.setTextColor(SSD1306_WHITE);
  gateway_oled_display.setCursor(0, 0); gateway_oled_display.println(F("Mixer Code")); gateway_oled_display.println(F("OLED ready")); gateway_oled_display.display();
  WiFi.mode(WIFI_STA);
  WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  Serial.println(F("Wi-Fi station connection started (non-blocking)."));
  mc_mqtt_client_mqtt.setServer("broker.hivemq.com", 1883);
  mc_mqtt_client_mqtt.setCallback(mc_mqtt_client_callback);
  mc_mqtt_client_mqtt.setSocketTimeout(2);
  mc_web_server_server.on("/", []() { mc_web_server_server.send(200, "text/plain", "Mixer Code device online"); });
  mc_web_server_server.on("/status", []() { mc_web_server_server.send(200, "application/json", "{\"status\":\"online\"}"); });
  mc_web_server_server.begin(); Serial.println(F("HTTP status server started"));
  mc_udp_listener_udp.begin(4210);
  configTime(19800, 0, "pool.ntp.org", "time.nist.gov");
  ArduinoOTA.setHostname("mixer-coder-gateway");
  ArduinoOTA.setPassword("demo-ota-password-change");
}

void loop() {
  int room_light_value = analogRead(room_light_pin);
  int mq_gas_sensor_value = analogRead(mq_gas_sensor_pin);

  if (WiFi.status() == WL_CONNECTED) { /* Connected */ } else if ((unsigned long)(millis() - mc_wifi_sta_last_retry_ms) >= 10000UL) {
    mc_wifi_sta_last_retry_ms = millis(); WiFi.begin(mc_wifi_sta_ssid, mc_wifi_sta_password);
  }
  mc_mqtt_client_tick();
  mc_web_server_server.handleClient();
  int mc_udp_listener_packet_size = mc_udp_listener_udp.parsePacket();
  if (mc_udp_listener_packet_size > 0) { char mc_udp_listener_buffer[256]; int mc_udp_listener_n = mc_udp_listener_udp.read(mc_udp_listener_buffer, sizeof(mc_udp_listener_buffer) - 1); if (mc_udp_listener_n < 0) mc_udp_listener_n = 0; mc_udp_listener_buffer[mc_udp_listener_n] = '\0'; Serial.print(F("UDP: ")); Serial.println(mc_udp_listener_buffer); }
  if ((unsigned long)(millis() - mc_ntp_sync_last_report_ms) >= 60000UL) {
    mc_ntp_sync_last_report_ms = millis(); time_t mc_ntp_sync_now = time(nullptr);
    if (mc_ntp_sync_now > 100000) { char mc_ntp_sync_time_text[32]; struct tm mc_ntp_sync_time_info; localtime_r(&mc_ntp_sync_now, &mc_ntp_sync_time_info); strftime(mc_ntp_sync_time_text, sizeof(mc_ntp_sync_time_text), "%Y-%m-%d %H:%M:%S", &mc_ntp_sync_time_info); Serial.println(mc_ntp_sync_time_text); } else Serial.println(F("NTP time not synchronized yet"));
  }
  if (WiFi.status() == WL_CONNECTED && !mc_ota_update_started) { ArduinoOTA.begin(); mc_ota_update_started = true; Serial.println(F("OTA ready on local network")); }
  if (mc_ota_update_started) ArduinoOTA.handle();

  // Automatic OLED dashboard: displays the first 2 analog input(s) until a custom layout is saved.
  if ((unsigned long)(millis() - gateway_oled_last_update_ms) >= 250UL) {
    gateway_oled_last_update_ms = millis();
    gateway_oled_display.clearDisplay();
    gateway_oled_display.setTextSize(1);
    gateway_oled_display.setCursor(0, 0); gateway_oled_display.println(F("SENSOR MONITOR"));
    gateway_oled_display.setCursor(0, 20); gateway_oled_display.println(F("Room Light"));
    gateway_oled_display.setCursor(0, 36); gateway_oled_display.print(room_light_value);
    gateway_oled_display.setCursor(66, 20); gateway_oled_display.println(F("MQ Gas Sen"));
    gateway_oled_display.setCursor(66, 36); gateway_oled_display.print(mq_gas_sensor_value);
    gateway_oled_display.display();
  }

  // Communication handlers are polled continuously; keep custom work non-blocking.
  delay(1); // Yield briefly to background network/USB tasks.
}
