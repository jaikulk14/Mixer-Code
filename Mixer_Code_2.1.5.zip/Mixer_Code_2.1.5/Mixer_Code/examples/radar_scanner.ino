/*
 * Mixer Code generated sketch
 * Release: 2.1.5
 * Project: Ultrasonic Radar Scanner
 * Board profile: Arduino Uno R3
 * Generated deterministically from the project model.
 * Review wiring, voltage levels and module polarity before powering hardware.
 */

#if defined(ARDUINO_ARCH_ESP32)
#include <ESP32Servo.h> // Install ESP32Servo for ESP32 boards.
#else
#include <Servo.h>
#endif
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Library dependency: Adafruit GFX Library
// Library documentation: https://github.com/adafruit/Adafruit-GFX-Library
// Library dependency: Adafruit SSD1306
// Library documentation: https://github.com/adafruit/Adafruit_SSD1306

// Pin map
// Radar Servo (servo) signal: 9
// Radar Ultrasonic (hc_sr04) trig: 2
// Radar Ultrasonic (hc_sr04) echo: 3
// Radar OLED Display (ssd1306_oled) uses I2C: board-default SDA/SCL pins
// I2C pins: SDA=A4, SCL=A5

Servo radar_servo_servo;
Adafruit_SSD1306 radar_oled_display_display(128, 64, &Wire, -1);
const uint8_t radar_servo_pin = 9;
const uint8_t radar_ultrasonic_trig_pin = 2;
const uint8_t radar_ultrasonic_echo_pin = 3;
bool radar_ultrasonic_detected = false; // True when a valid ultrasonic echo is received.

unsigned long radar_oled_display_last_update_ms = 0;
unsigned long servo_sweep_radar_servo_last_ms = 0;
int servo_sweep_radar_servo_angle = 0;
int servo_sweep_radar_servo_direction = 1;
float radar_ultrasonic_distance_cm = -1.0f;
uint8_t ultrasonic_monitor_radar_ultrasonic_state = 0; // 0=wait, 1=wait for echo HIGH, 2=wait for echo LOW
unsigned long ultrasonic_monitor_radar_ultrasonic_state_started_us = 0;
unsigned long ultrasonic_monitor_radar_ultrasonic_echo_started_us = 0;
unsigned long ultrasonic_monitor_radar_ultrasonic_last_ping_us = 0;
int ultrasonic_monitor_radar_ultrasonic_angle_at_ping = 0;

void tick_servo_sweep_radar_servo() {
  unsigned long now = millis();
  if ((unsigned long)(now - servo_sweep_radar_servo_last_ms) >= 20UL) {
    servo_sweep_radar_servo_last_ms = now;
    servo_sweep_radar_servo_angle += servo_sweep_radar_servo_direction * 2;
    if (servo_sweep_radar_servo_angle >= 180) { servo_sweep_radar_servo_angle = 180; servo_sweep_radar_servo_direction = -1; }
    else if (servo_sweep_radar_servo_angle <= 0) { servo_sweep_radar_servo_angle = 0; servo_sweep_radar_servo_direction = 1; }
    radar_servo_servo.write(servo_sweep_radar_servo_angle);
  }
}

void tick_ultrasonic_monitor_radar_ultrasonic() {
  unsigned long nowUs = micros();
  if (ultrasonic_monitor_radar_ultrasonic_state == 0) {
    if ((unsigned long)(nowUs - ultrasonic_monitor_radar_ultrasonic_last_ping_us) >= 60UL * 1000UL) {
      ultrasonic_monitor_radar_ultrasonic_angle_at_ping = servo_sweep_radar_servo_angle;
      digitalWrite(radar_ultrasonic_trig_pin, LOW);
      delayMicroseconds(2);
      digitalWrite(radar_ultrasonic_trig_pin, HIGH);
      delayMicroseconds(10);
      digitalWrite(radar_ultrasonic_trig_pin, LOW);
      ultrasonic_monitor_radar_ultrasonic_state_started_us = micros();
      ultrasonic_monitor_radar_ultrasonic_state = 1;
    }
  } else if (ultrasonic_monitor_radar_ultrasonic_state == 1) {
    if (digitalRead(radar_ultrasonic_echo_pin) == HIGH) { ultrasonic_monitor_radar_ultrasonic_echo_started_us = micros(); ultrasonic_monitor_radar_ultrasonic_state = 2; }
    else if ((unsigned long)(nowUs - ultrasonic_monitor_radar_ultrasonic_state_started_us) > 30000UL) { radar_ultrasonic_distance_cm = -1.0f; radar_ultrasonic_detected = false; Serial.print(F("RADAR,")); Serial.print(ultrasonic_monitor_radar_ultrasonic_angle_at_ping); Serial.println(F(",-1")); ultrasonic_monitor_radar_ultrasonic_last_ping_us = nowUs; ultrasonic_monitor_radar_ultrasonic_state = 0; }
  } else if (ultrasonic_monitor_radar_ultrasonic_state == 2) {
    if (digitalRead(radar_ultrasonic_echo_pin) == LOW) {
      unsigned long duration = (unsigned long)(micros() - ultrasonic_monitor_radar_ultrasonic_echo_started_us);
      radar_ultrasonic_distance_cm = (duration * 0.0343f) / 2.0f;
      radar_ultrasonic_detected = true;
      Serial.print(F("RADAR,")); Serial.print(ultrasonic_monitor_radar_ultrasonic_angle_at_ping); Serial.print(','); Serial.println(radar_ultrasonic_distance_cm, 1);
      ultrasonic_monitor_radar_ultrasonic_last_ping_us = micros(); ultrasonic_monitor_radar_ultrasonic_state = 0;
    } else if ((unsigned long)(nowUs - ultrasonic_monitor_radar_ultrasonic_echo_started_us) > 30000UL) { radar_ultrasonic_distance_cm = -1.0f; radar_ultrasonic_detected = false; Serial.print(F("RADAR,")); Serial.print(ultrasonic_monitor_radar_ultrasonic_angle_at_ping); Serial.println(F(",-1")); ultrasonic_monitor_radar_ultrasonic_last_ping_us = nowUs; ultrasonic_monitor_radar_ultrasonic_state = 0; }
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  radar_servo_servo.attach(radar_servo_pin);
  radar_servo_servo.write(0);
  pinMode(radar_ultrasonic_trig_pin, OUTPUT); pinMode(radar_ultrasonic_echo_pin, INPUT);
  digitalWrite(radar_ultrasonic_trig_pin, LOW);
  if (!radar_oled_display_display.begin(SSD1306_SWITCHCAPVCC, 0x3C, true, false)) { Serial.println(F("SSD1306 allocation failed")); }
  radar_oled_display_display.clearDisplay(); radar_oled_display_display.setTextSize(1); radar_oled_display_display.setTextColor(SSD1306_WHITE);
  radar_oled_display_display.setCursor(0, 0); radar_oled_display_display.println(F("Mixer Code")); radar_oled_display_display.println(F("OLED ready")); radar_oled_display_display.display();
}

void loop() {
  // Independent cooperative tasks and continuous sensor monitors.
  tick_servo_sweep_radar_servo();
  tick_ultrasonic_monitor_radar_ultrasonic();

  if ((unsigned long)(millis() - radar_oled_display_last_update_ms) >= 150UL) {
    radar_oled_display_last_update_ms = millis();
    radar_oled_display_display.clearDisplay();
    radar_oled_display_display.setTextSize(1);
    radar_oled_display_display.setCursor(0, 0); radar_oled_display_display.println(F("MIXER CODE RADAR"));
    radar_oled_display_display.setCursor(0, 16); radar_oled_display_display.print(F("Distance: ")); if (radar_ultrasonic_distance_cm < 0) radar_oled_display_display.println(F("No echo")); else { radar_oled_display_display.print(radar_ultrasonic_distance_cm, 1); radar_oled_display_display.println(F(" cm")); }
    radar_oled_display_display.setCursor(0, 53); radar_oled_display_display.print(F("Angle: ")); radar_oled_display_display.println(servo_sweep_radar_servo_angle);
    radar_oled_display_display.display();
  }

  // No blocking delay: independent tasks and continuous monitors stay responsive.
}
