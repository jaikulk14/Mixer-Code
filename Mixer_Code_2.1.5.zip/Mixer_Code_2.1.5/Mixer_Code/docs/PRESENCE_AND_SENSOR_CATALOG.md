# Presence rules and expanded sensor catalog

## Value-free rule conditions

The Logic Builder accepts `DETECTED` and `NOT_DETECTED` for digital inputs and HC-SR04 distance inputs. These are categorical state/event conditions and do not require a numeric threshold. The existing `TRUE` / `FALSE` digital conditions and `ABOVE` / `BELOW <number>` analog/distance conditions remain available.

Examples:

```text
WHEN Ultrasonic DETECTED THEN LED GLOW
WHEN Ultrasonic NOT DETECTED THEN Buzzer BEEP
WHEN IR Obstacle DETECTED THEN LED ON
WHEN Rain Sensor (Digital) NOT DETECTED THEN Relay DEACTIVATE
WHEN MQ Gas Sensor ABOVE 700 THEN Buzzer BEEP
```

For HC-SR04, `DETECTED` means the sensor received a valid echo pulse before its timeout. `NOT_DETECTED` means no valid echo was received before the timeout. No distance comparison is performed. This does not guarantee that a particular obstacle is present: a wall or other surface can generate an echo, while a soft, angled or distant object may not. If the application needs a defined detection zone, use the existing `BELOW <centimetres>` condition instead.

The basic rule-only ultrasonic adapter uses `pulseIn()` with a 30 ms timeout, so the loop can pause for up to about 30 ms on a no-echo measurement. The continuous sensor monitor and independent radar task use non-blocking cooperative state machines. Keep that distinction in mind when combining rule-only sonar with timing-sensitive tasks.

## Expanded generic sensor profiles

The added sensor profiles reuse existing digital-input or analog-input adapters. They do not add vendor-specific calibration or measurement conversion. Analog modules report raw ADC counts; digital modules report the configured active/inactive state.

### Analog input profiles

- Rain Sensor (Analog)
- Water Level Sensor
- LM35 Temperature Sensor (raw ADC only)
- NTC Thermistor Module (raw ADC only)
- Force Sensitive Resistor (FSR)
- Flex Sensor
- Voltage Sensor Module (raw ADC only)
- Joystick Axis (X or Y)

### Digital detection profiles

- IR Obstacle Detection Module
- IR Line Tracking Sensor
- SW-420 Vibration Sensor
- Tilt / Ball Switch
- Magnetic Reed Switch
- Mechanical Limit Switch
- Rain Sensor (Digital)
- Water Leak Detection Module
- Sound Sensor (Digital)

Module output polarity varies by manufacturer and board. Use **Change active level** in the Components tab when the module asserts the opposite electrical level. Pull-up switch profiles use `INPUT_PULLUP`; wire the switch contact between the signal pin and GND. Check the selected board's available analog channels and pin voltage limits before wiring.
