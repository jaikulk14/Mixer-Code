# Connectivity and Protocol Guide

This guide describes the generated adapters in Mixer Code 2.1.5 and their boundaries.

## Select by board

- **Uno / classic Nano**: USB Serial, one SoftwareSerial UART adapter, external HC-05/HC-06, external HM-10, ESP8266 AT modem setup, I2C scan, SPI transaction, SD logger and SX127x LoRa.
- **Original ESP32 Dev Module**: native Wi-Fi Station/AP/scan, MQTT, HTTP REST, UDP, Web server, NTP, ArduinoOTA, Bluetooth Classic SPP, hardware UART, I2C, SPI, SD and LoRa. Native BLE GATT services are not included in this release.
- **ESP8266 NodeMCU / ESP-12E**: native Wi-Fi Station/AP/scan, MQTT, HTTP REST, UDP, web server, NTP, external UART Bluetooth modules, I2C, SPI and SD. No native Bluetooth is generated.

## Serial and Bluetooth wiring

| Profile | MCU RX | MCU TX | Notes |
|---|---|---|---|
| MAX485 RS-485 | Transceiver RO | Transceiver DI | DE and /RE tied to the configured MCU direction pin. |
| HC-05 / HC-06 | Module TX | Module RX | Bluetooth Classic serial. Check RX voltage level. |
| HM-10 | Module TX | Module RX | BLE UART service; module firmware differs across clones. |
| ESP8266 AT on Uno/Nano | ESP8266 TX | ESP8266 RX | 3.3V supply and logic-level protection are required. |
| ESP32 UART profile | configurable RX (default GPIO16) | configurable TX (default GPIO17) | Uses UART2 in this release. |

Only one UART / SoftwareSerial module profile is allowed per project in this release. For multiple simultaneous serial devices, use a dedicated UART board, another hardware UART implementation, or an external UART multiplexer and custom adapter.

## Wi-Fi modes

- **Station**: board joins a router. Required by MQTT, HTTP REST, NTP and OTA.
- **Access Point**: board creates a local network. Web server and UDP can run in AP mode. MQTT, REST, NTP and OTA in this generator require station mode.
- **Wi-Fi Scanner**: one-shot synchronous scan at startup. It may interrupt an active station connection. Use it in a scanner-only project.
- **ESP8266 AT modem**: an Uno/Nano sends AT commands over SoftwareSerial to an ESP8266 with ESP-AT firmware. The adapter checks the modem and attempts to join the requested AP. It is not wired into the native ESP32/ESP8266 HTTP/MQTT adapters.

## Messaging profiles

- MQTT uses PubSubClient, a callback, one subscription topic and an example publish. A helper function is generated for publishing from your project logic. Anonymous access is supported when both username and password are empty. If a password is provided, username is required.
- HTTP REST sends periodic GET / POST / PUT / DELETE requests. The adapter passes an explicit `WiFiClient` to `HTTPClient.begin(client, url)`, required by current ESP8266 cores and supported by current ESP32 cores. GET is used without a request body. POST uses the String payload overload. PUT and DELETE use `sendRequest()` with a byte buffer. The generated starter is plain HTTP only.
- UDP listens on one local port and prints each received datagram.
- The web server exposes `/` and `/status` with simple status responses.
- NTP uses the UTC offset and daylight offset values configured in the profile.

## Buses, storage and long-range radio

- The I2C scanner uses the board default SDA/SCL pins and reserves them during validation.
- SPI byte transfer, SD logger and LoRa share the board SPI bus pins. Their chip-select pins must be distinct from other project pins.
- LoRa uses the Sandeep Mistry Arduino-LoRa library and an SX127x-family module. Transmission uses the asynchronous mode and DIO0 TX-done callback so the main loop is not held until packet completion. It is raw LoRa, not LoRaWAN. It is unencrypted and does not enforce regional duty-cycle rules. DIO0 must be connected to a suitable interrupt-capable pin.

## Security checklist before upload

1. Replace all demo Wi-Fi, MQTT and OTA credentials.
2. Do not publish generated sketches or `.iotproj` files containing real secrets.
3. Do not use public MQTT brokers for private information.
4. Add TLS certificate validation before using credentials over untrusted networks.
5. Do not expose a plain HTTP status server or OTA workflow directly to the public internet.
6. Confirm local radio band, channel, output power and duty-cycle restrictions before transmitting with LoRa.
7. Verify supply voltage, current and logic levels for every radio module.

## Documentation used for API design

The code generation is based on the vendors' documented Arduino APIs. Check their current documentation and versions when updating the installed board core or libraries:

- Espressif Arduino Wi-Fi API: https://docs.espressif.com/projects/arduino-esp32/en/latest/api/wifi.html
- Espressif Arduino Bluetooth Classic API: https://docs.espressif.com/projects/arduino-esp32/en/latest/api/bluetooth.html
- Espressif Arduino BLE API and examples: https://docs.espressif.com/projects/arduino-esp32/en/latest/api/ble.html
- Arduino SPI API: https://docs.arduino.cc/language-reference/en/functions/communication/SPI/
- PubSubClient: https://github.com/knolleary/pubsubclient
- Arduino-LoRa: https://github.com/sandeepmistry/arduino-LoRa
- ESP8266 Arduino Core: https://github.com/esp8266/Arduino
