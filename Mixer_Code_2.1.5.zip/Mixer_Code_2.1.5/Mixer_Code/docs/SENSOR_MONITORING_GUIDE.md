# Sensor Monitoring Modes (Mixer Code 2.1.5)

The **Sensor Monitor** tab controls whether a sensor uses event/threshold logic, continuous telemetry, or both. The setting is per sensor and is stored in the `.iotproj` file.

## Choose a mode

| Mode | What it does | Threshold rules for that sensor |
|---|---|---|
| Threshold rules only | Uses the existing `WHEN / THEN` rule system. Does not emit periodic monitor data. | Allowed |
| Continuous monitor only | Samples the sensor on an interval and emits every reading to Serial. No threshold is required. | Not allowed |
| Continuous + threshold rules | Emits periodic readings and still evaluates the sensor's `WHEN / THEN` rules. | Allowed |

A sensor with no saved mode uses **Threshold rules only**, preserving behavior for projects created before 2.1.3. Choose **Both** when you want an always-updating dashboard and a threshold-triggered alarm from the same sensor.

## Telemetry format

Serial runs at 115200 baud. Each row uses the following format:

```text
MONITOR,<component_id>,<measurement_type>,<value>
```

Examples:

```text
MONITOR,mq_gas,ANALOG,642
MONITOR,touch_sensor,DIGITAL,ACTIVE
MONITOR,ultrasonic,DISTANCE_CM,37.4
```

Analog sensors report raw ADC values, not calibrated units. A digital input reports `ACTIVE` or `INACTIVE` based on the component's configured active polarity.

## HC-SR04 behavior

Continuous HC-SR04 monitoring uses a cooperative `micros()` state machine. It does not use `pulseIn()`, so the sketch can continue to run other short non-blocking tasks while waiting for the Echo pulse. The measurement interval must be at least 60 ms. A missing or timed-out echo is reported as `-1`.

Do not configure the legacy **Continuous ultrasonic monitor** task and the new **Sensor Monitor** feature for the same HC-SR04 at the same time. Use one monitor path per ultrasonic component. The legacy radar task remains available for projects that pair servo angle with sonar distance.

## Display behavior

- If an analog sensor is selected and an SSD1306 OLED exists, the automatic OLED dashboard displays its analog reading unless a saved OLED Designer layout takes precedence.
- For continuous digital or distance monitoring, an OLED or LCD with no saved OLED Designer layout displays a live sensor list (up to four entries on SSD1306 or two entries on LCD 16x2).
- A saved OLED Designer layout has priority. The automatic analog-only dashboard also takes priority when analog sensors are present and no custom layout was saved. The continuous values still appear on Serial even when a display layout does not include them.
- Mechanical push buttons are reported as raw active/inactive states; no debounce filter is added automatically, so a noisy switch can show contact bounce.

## Practical advice

- Start with 250 ms for analog/digital sensors. Increase the interval if Serial output is too frequent.
- Use at least 60 ms for HC-SR04. A faster ping rate can produce unreliable readings due to previous echoes.
- Keep custom loop code and synchronous network requests short. Cooperative monitor routines are not OS threads and cannot run in parallel with blocking code.
- If another module or custom snippet also writes to `Serial`, its messages may interleave with monitor records. Use a separate hardware UART or a structured message multiplexer when required.
- Compile with the actual target board core and libraries before uploading. Stub-based syntax tests do not validate electrical behavior or actual sensor readings.
