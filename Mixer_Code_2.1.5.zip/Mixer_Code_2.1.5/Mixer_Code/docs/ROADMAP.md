# Mixer Code roadmap

## Completed in 2.1.2

- Retained the component catalog, structured logic, OLED Designer, automatic OLED dashboards, custom component editor, offline custom library, URL code scanner and library dependency manager.
- Retained independent non-blocking servo sweep and ultrasonic measurement tasks for radar projects.
- Added a board profile for ESP8266 NodeMCU / ESP-12E.
- Added UART bridge, MAX485 RS-485 half-duplex bridge, HC-05/HC-06 Bluetooth Classic UART, HM-10 BLE UART, and original-ESP32 Bluetooth Classic SPP adapters.
- Added ESP32/ESP8266 Wi-Fi station, access point and network scanner profiles.
- Added an ESP8266 AT modem starter adapter for Uno/Nano.
- Added MQTT, HTTP REST GET/POST/PUT/DELETE, UDP listener, web status server, NTP and ESP32 ArduinoOTA profiles.
- Added I2C scanner, SPI byte-transfer test, SD CSV logger and SX127x LoRa sender/receiver.
- Added project migration and persistent connectivity-profile settings.
- Added board/pin conflict validation for UART, I2C, SPI and LoRa DIO0 constraints.
- Added a connectivity guide and 16 paired example projects/sketches covering OLED dashboards, radar, Serial, Bluetooth, Wi-Fi, MQTT, REST, UDP, web server, NTP, OTA, I2C, SPI, SD, LoRa and RS-485.
- Added 76 Python unit tests and a C++ syntax-stub harness for bundled sketches.

## Next engineering milestones

1. Full Arduino CLI compile integration with actual board cores, pinned library versions and actionable compiler diagnostics.
2. Upload and Serial Monitor integration with explicit port / board confirmation.
3. Native ESP32 BLE GATT support with a version-pinned Arduino-ESP32 API adapter.
4. Ethernet W5500, RS-485 / Modbus RTU and CAN bus profiles with hardware-specific pin and transceiver validation.
5. Typed custom adapters so saved user components expose named readings and actions to the WHEN / THEN logic builder.
6. More sensors and drivers with testable library metadata, including DHT, DS18B20, MPU6050, MAX30102 and HX711.
7. Network security improvements: HTTPS certificate configuration, MQTT TLS, secret storage outside project JSON and safer OTA deployment.
8. General task graph with execution-time warnings and non-blocking network drivers.

## Design guardrails

- Keep code generation deterministic and testable.
- Never imply that a board has native radio hardware if it requires an external module.
- Reserve hardware bus pins and reject conflicts before generating a sketch.
- Do not claim a stub compile is a physical hardware test or a real board-core build.
- Keep user-pasted C++ clearly marked and untrusted until reviewed and compiled.
- Prefer non-blocking schedules where independent activities must run together.


## Completed in 2.1.3

- Added a per-sensor monitoring selector: threshold only, continuous only, or continuous plus threshold rules.
- Added interval-based analog and digital telemetry with stable `MONITOR,<id>,<kind>,<value>` serial records.
- Added a non-blocking HC-SR04 echo state machine for continuous distance readings without `pulseIn()`.
- Added automatic live monitor rows on SSD1306 OLED and LCD when no explicit OLED designer layout takes precedence.
- Added project schema v6 migration and regression tests.


## Completed in 2.1.5

- Added a one-paste integration importer for complete Arduino sketches and README/documentation text.
- Extracts `#include` lines, global objects/declarations/helper functions, `setup()` body and `loop()` body while removing lifecycle wrappers and obvious Markdown prose.
- Handles repeated sketch copies, HTML entities, escaped Markdown punctuation, and separate fenced setup/loop blocks when no individual block is complete.
- Shows an extraction preview and parser warnings before loading code into the custom component editor.
- Reuses the same extraction engine for online documentation code blocks.
- Preserves the imported `Serial.begin(...)` baud, keeps custom include order, and avoids adding an unnecessary generated loop delay when the imported code already owns loop timing.
- Added an MPU6050 imported-integration example and regression coverage for the full import path.
