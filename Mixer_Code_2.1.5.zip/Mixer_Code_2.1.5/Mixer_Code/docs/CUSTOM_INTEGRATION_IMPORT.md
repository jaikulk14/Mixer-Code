# Import a complete Arduino integration

Mixer Code 2.1.5 adds a **Import full sketch / README…** action in the Custom Components tab. This replaces the old requirement to manually split a copied example into four text boxes.

## Workflow

1. Open **Custom Components**.
2. Select **Import full sketch / README…**.
3. Paste the complete `.ino` sketch or the relevant README/documentation text. The importer works offline; no network request is made by this action.
4. Choose **Analyze complete code**.
5. Review the extracted result and warnings.
6. Choose **Use extracted sections**. The result is loaded into the regular custom component editor.
7. Enter or adjust the component name, notes and source URL, then select **Save to project** or **Save to offline library**.

## What it extracts

| Source content | Destination |
|---|---|
| `#include` directives | Includes |
| Global object declarations, constants, macros and helper functions | Globals / functions |
| Statements inside the first complete `void setup()` | Setup body |
| Statements inside the first complete `void loop()` | Loop body |

The outer `void setup() { ... }` and `void loop() { ... }` wrappers are removed. The generated project already owns its lifecycle functions, so retaining the wrappers would create duplicate definitions.

The importer decodes common HTML entities and Markdown-escaped punctuation, recognizes fenced C++ examples, removes obvious README headings/tables/prose, and de-duplicates repeated code candidates. If setup and loop appear in separate code fences and no one block has both, the blocks can be combined. If a README contains several distinct complete sketches, Mixer Code chooses the strongest complete match and warns that other examples were not imported. Paste the specific example you intend to use when several sketches are present.

## Example: MPU6050

Input can be a full sketch like:

```cpp
#include <Wire.h>
#include <MPU6050.h>

MPU6050 mpu;

void setup() {
  Serial.begin(9600);
  Wire.begin();
  mpu.initialize();
}

void loop() {
  int16_t ax, ay, az;
  int16_t gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  Serial.println(ax);
  delay(500);
}
```

Mixer Code extracts the two includes, `MPU6050 mpu;`, the three setup statements, and the loop body. It does not paste the README wiring table or explanatory paragraphs into C++.

The imported loop's `delay(500)` is preserved because it is part of the source integration, but the importer warns that blocking delays can stall independent tasks, telemetry and communications. Review and refactor the delay if your project needs cooperative multitasking.

## Safety and limits

- This is a structural source parser, not a complete C++ parser, static analyzer or security sandbox.
- The parser does not run code, execute build scripts, install libraries, infer every module pin, or prove that the selected library API matches the sketch.
- A `Serial.begin(...)` found at top level in the imported setup is preserved and takes precedence over Mixer Code's default Serial baud. Match the Serial Monitor baud to the sketch.
- Library suggestions are inferred from header filenames. Arduino Library Manager package names do not always match header names. Confirm the package before installing it.
- Only the first complete setup and first complete loop bodies are used. Duplicate wrappers are removed from globals and reported as a warning.
- Always inspect the preview, generated sketch, library version and wiring. Compile against the actual target board core and test on hardware before uploading.
